# PROJECT ECHO Launcher — production source 0.8.0

This package is for building on Windows via GitHub Actions; no local CMD is required.

## Included
- Launcher WPF, version 0.8.0 (game launch, ZombieBuddy, Xmx, Steam Workshop link, news images).
- Signed schema 2 local-mod updater targeting `project-echo-schema2-production`; files are pinned to a commit SHA.
- Separate dedicated self-updater (no WPF), with backup/rollback and ECDSA-signed EXE manifest.
- Fixed server address 26.137.250.18:16261.

## Security and prerequisites
- Only a public ECDSA verification key is in this ZIP; NEVER upload the private signing key to a public repository or release.
- The first production release is a CI artifact, NOT automatically published or installed.
- Future launcher releases require an owner-signed `launcher.json` and `launcher.sig` in `updates/launcher-production/` on the production branch, plus GitHub Release asset `ProjectEchoLauncher.exe`.
- Production modpack is initially copied from the previously tested 336-file staging pack; subsequent builds must update only the production branch.
- This code has NOT been compiled/tested on Windows yet. Check game launching, signed updates, and ZombieBuddy on a real Windows PC before public release.
