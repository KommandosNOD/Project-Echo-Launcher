using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using System.Text.RegularExpressions;
using System.Diagnostics;
using System.Net;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace PZLauncher;

public sealed class NewsEntry : INotifyPropertyChanged
{
    public string Category { get; set; } = "НОВОСТИ";
    public string Date { get; set; } = "";
    public string Title { get; set; } = "";
    public string Text { get; set; } = "";
    public string ImagePath { get; set; } = "";

    private ImageSource? _imageSource;
    public ImageSource? ImageSource
    {
        get => _imageSource;
        set
        {
            if (ReferenceEquals(_imageSource, value)) return;
            _imageSource = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ImageSource)));
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ImageVisibility)));
        }
    }
    public Visibility ImageVisibility => ImageSource is null ? Visibility.Collapsed : Visibility.Visible;
    public event PropertyChangedEventHandler? PropertyChanged;
}

public partial class MainWindow : Window
{
    private const string SiteUrl = "https://no-signal-pz.komanndosnod.workers.dev";
    private readonly PatchUpdateService _updater = new();
    private readonly GameClientService _gameClient = new();
    private readonly ServerAddressService _addressService = new();
    private readonly HttpClient _newsClient = new() { Timeout = TimeSpan.FromSeconds(12) };
    private readonly LocalSettings _settings;
    private readonly ObservableCollection<NewsEntry> _news = new();
    private readonly CancellationTokenSource _newsImageCancellation = new();
    private readonly SemaphoreSlim _newsImageConcurrency = new(3, 3);
    private UpdatePlan? _plan;
    private string? _workshopUrl;
    private string? _workshopCollectionId;
    private bool _busy;
    private bool _lastPatchCheckSucceeded;

    public MainWindow()
    {
        InitializeComponent();
        // Always show the ACTUAL executable assembly version, never a typed-in release string.
        var currentVersion = System.Reflection.Assembly.GetEntryAssembly()?.GetName().Version;
        var displayVersion = currentVersion is null ? "unknown" :
            $"{currentVersion.Major}.{currentVersion.Minor}.{currentVersion.Build}";
        LauncherVersionText.Text = "v" + displayVersion;
#if ECHO_RELEASE_CANDIDATE
        Title = $"PROJECT ECHO v{displayVersion} — PRODUCTION RC (ТЕСТ, НЕ ДЛЯ ИГРЫ)";
        PlayButton.IsEnabled = false;
#elif ECHO_STAGING_CLIENT
        Title = $"PROJECT ECHO v{displayVersion} — GITHUB STAGING CLIENT (НЕ ДЛЯ ИГРЫ)";
        PlayButton.IsEnabled = false;
#elif ECHO_TEST_CLIENT
        Title = $"PROJECT ECHO v{displayVersion} — ТЕСТОВЫЙ КЛИЕНТ (НЕ ПРОДАКШЕН)";
        PlayButton.IsEnabled = false;
#endif
        InitializeSettingsSyncUi();
        // Fixed, signed patch channel. A stale saved address never overrides it.
        // RC is pinned to GitHub TEST; production uses the Worker stable endpoint.
        _settings = ManifestSource.Migrate(SettingsStore.Load());
        ManifestUrlBox.Text = _settings.ManifestUrl;
        HostBox.Text = ServerAddressService.FixedHost;
        PortBox.Text = ServerAddressService.FixedPort.ToString();
        AutoInstallBox.IsChecked = _settings.AutoInstall;
        AutoIpBox.IsChecked = false;
        AccountUserBox.Text = _settings.AccountUsername;
        RememberPasswordBox.IsChecked = _settings.RememberPassword;
        if (_settings.RememberPassword)
        {
            try { AccountPasswordBox.Password = CredentialStore.Load() ?? ""; }
            catch { ConnectionHintText.Text = "Сохранённый пароль недоступен: введи его заново."; }
        }
        // Show the discovered game installation automatically on first launch.
        // A valid user override remains supported for unusual Steam installations.
        var detectedGame = GameClientService.DetectGameFolder(_settings.GameFolder);
        GameFolderBox.Text = detectedGame ?? _settings.GameFolder;
        if (detectedGame is not null) _settings.GameFolder = detectedGame;
        NewsList.ItemsSource = _news;
        UpdateAutoIpControls();
        Loaded += MainWindow_Loaded;
        Closed += (_, _) =>
        {
            _newsImageCancellation.Cancel();
            _updater.Dispose(); _addressService.Dispose(); _newsClient.Dispose(); _gameClient.Dispose();
        };
    }

    private void SetBusy(bool busy)
    {
        _busy = busy;
        CheckButton.IsEnabled = !busy;
        InstallButton.IsEnabled = !busy && _plan is { Changed.Count: > 0 };
#if ECHO_TEST_CLIENT || ECHO_RELEASE_CANDIDATE
        PlayButton.IsEnabled = false;
#else
        PlayButton.IsEnabled = !busy;
#endif
        Mouse.OverrideCursor = busy ? Cursors.Wait : null;
    }

    private void SaveSettings()
    {
        _settings.ManifestUrl = ManifestSource.Normalize(ManifestUrlBox.Text);
        ManifestUrlBox.Text = _settings.ManifestUrl;
        _settings.HostOverride = ServerAddressService.FixedHost;
        _settings.AutoInstall = AutoInstallBox.IsChecked == true;
        _settings.AutoResolveServer = false;
        _settings.PortOverride = ServerAddressService.FixedPort;
        _settings.GameFolder = GameFolderBox.Text.Trim();
        _settings.AccountUsername = AccountUserBox.Text.Trim();
        _settings.RememberPassword = RememberPasswordBox.IsChecked == true;
        SettingsStore.Save(_settings);
        if (_settings.RememberPassword) CredentialStore.Save(AccountPasswordBox.Password);
        else CredentialStore.Delete();
    }
    private void Save_Click(object sender, RoutedEventArgs e)
    {
        try { SaveSettings(); _plan = null; _lastPatchCheckSucceeded = false; InstallButton.IsEnabled = false; StatusText.Text = "Настройки сохранены"; }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Ошибка сохранения"); }
    }
    private void DetectGameFolder_Click(object sender, RoutedEventArgs e)
    {
        // Force rediscovery; do not accidentally reuse an old manual path.
        var detected = GameClientService.DetectGameFolder();
        if (detected is null)
        {
            MessageBox.Show("Project Zomboid не найдена в библиотеках Steam. " +
                "Можно вставить путь к папке игры вручную (папка с ProjectZomboid64.json).",
                "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Information);
            return;
        }
        GameFolderBox.Text = detected;
        _settings.GameFolder = detected;
        SettingsStore.Save(_settings);
        StatusText.Text = "Папка Project Zomboid определена";
    }

    private void Home_Click(object sender, RoutedEventArgs e) { HomeView.Visibility=Visibility.Visible; SettingsView.Visibility=Visibility.Collapsed; }
    private void Settings_Click(object sender, RoutedEventArgs e) { HomeView.Visibility=Visibility.Collapsed; SettingsView.Visibility=Visibility.Visible; }

    private async void MainWindow_Loaded(object sender, RoutedEventArgs e)
    {
        _ = CheckSelfUpdateAtStartupAsync();
        _ = LoadNewsAsync();
        _ = RefreshModpackRevisionAsync();
        if (_settings.AutoInstall && !string.IsNullOrWhiteSpace(_settings.ManifestUrl)) await CheckForUpdatesAsync(true);
        await RefreshServerAsync();
    }

    private async Task LoadNewsAsync()
    {
        try
        {
            using var response = await _newsClient.GetAsync(SiteUrl + "/data/news.json");
            response.EnsureSuccessStatusCode();
            using var json = JsonDocument.Parse(await response.Content.ReadAsByteArrayAsync());
            var items = json.RootElement.GetProperty("items");
            if (items.ValueKind != JsonValueKind.Array) throw new InvalidDataException("Неверный формат новостей");
            _news.Clear();
            foreach (var item in items.EnumerateArray().Take(12))
            {
                string get(string field) => item.TryGetProperty(field, out var v) && v.ValueKind == JsonValueKind.String ? (v.GetString() ?? "") : "";
                var entry = new NewsEntry
                {
                    Category = get("category"), Date = get("date"),
                    Title = get("title"), Text = get("text"), ImagePath = get("image")
                };
                _news.Add(entry);
                if (!string.IsNullOrWhiteSpace(entry.ImagePath))
                    _ = LoadNewsImageAsync(entry, _newsImageCancellation.Token);
            }
            NewsStatusText.Text = $"{_news.Count} ПУБЛИКАЦИИ";
        }
        catch (Exception ex)
        {
            NewsStatusText.Text = "НЕТ СВЯЗИ";
            _news.Clear();
            _news.Add(new NewsEntry { Category = "ОФЛАЙН", Title = "Лента новостей недоступна", Text = "Не удалось получить новости: " + ex.Message });
        }
        try
        {
            using var response = await _newsClient.GetAsync(SiteUrl + "/data/community.json");
            response.EnsureSuccessStatusCode();
            using var doc = JsonDocument.Parse(await response.Content.ReadAsByteArrayAsync());
            var value = doc.RootElement.GetProperty("workshopCollectionUrl").GetString() ?? "";
            // Accept only a genuine Steam Community collection URL with a numeric Workshop ID.
            // The URL comes from the existing site config, so changes to the collection ID
            // do not require rebuilding the launcher.
            if (Uri.TryCreate(value, UriKind.Absolute, out var url)
                && url.Scheme == Uri.UriSchemeHttps
                && url.Host.Equals("steamcommunity.com", StringComparison.OrdinalIgnoreCase)
                && url.AbsolutePath == "/sharedfiles/filedetails/")
            {
                var id = Regex.Match(url.Query, @"(?:^\?|&)id=(?<id>[0-9]{5,20})(?:&|$)",
                    RegexOptions.CultureInvariant);
                if (id.Success)
                {
                    _workshopUrl = value;
                    _workshopCollectionId = id.Groups["id"].Value;
                    WorkshopButton.IsEnabled = true;
                }
            }
        }
        catch { /* Workshop link is optional until owner sets the collection URL. */ }
    }
    // Only fetch images that were published to our own /assets/news/ folder.
    // External URLs and traversal are intentionally ignored, so news.json
    // cannot turn the launcher into an arbitrary URL fetcher.
    private static bool TryGetNewsImageUrl(string? path, out Uri? url)
    {
        url = null;
        if (string.IsNullOrWhiteSpace(path) || path.Length > 180) return false;
        if (!Regex.IsMatch(path, @"^/assets/news/[a-zA-Z0-9][a-zA-Z0-9._-]{0,119}\.(png|jpg|jpeg|webp)$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant))
            return false;
        if (path.Contains("..", StringComparison.Ordinal)) return false;
        return Uri.TryCreate(SiteUrl.TrimEnd('/') + path, UriKind.Absolute, out url)
            && url.Scheme == Uri.UriSchemeHttps;
    }

    private async Task LoadNewsImageAsync(NewsEntry entry, CancellationToken ct)
    {
        if (!TryGetNewsImageUrl(entry.ImagePath, out var uri) || uri is null) return;
        bool entered = false;
        try
        {
            await _newsImageConcurrency.WaitAsync(ct);
            entered = true;
            using var response = await _newsClient.GetAsync(uri, HttpCompletionOption.ResponseHeadersRead, ct);
            response.EnsureSuccessStatusCode();
            const int maxBytes = 2 * 1024 * 1024 + 1024;
            if (response.Content.Headers.ContentLength is long length && length > maxBytes) return;
            await using var input = await response.Content.ReadAsStreamAsync(ct);
            using var output = new MemoryStream();
            var buffer = new byte[16 * 1024];
            int n;
            while ((n = await input.ReadAsync(buffer, ct)) > 0)
            {
                if (output.Length + n > maxBytes) return;
                output.Write(buffer, 0, n);
            }
            if (output.Length == 0 || ct.IsCancellationRequested) return;
            output.Position = 0;
            var bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.CacheOption = BitmapCacheOption.OnLoad;
            bitmap.DecodePixelWidth = 1000;
            bitmap.StreamSource = output;
            bitmap.EndInit();
            // Guard against unusually tall or malformed images in addition to the byte limit.
            if (bitmap.PixelWidth <= 0 || bitmap.PixelHeight <= 0 || bitmap.PixelHeight > 6000) return;
            bitmap.Freeze();
            if (!ct.IsCancellationRequested) entry.ImageSource = bitmap;
        }
        catch (OperationCanceledException) { /* Window closed. */ }
        catch (Exception ex)
        {
            // Image failure must not hide the article; keep a bounded diagnostics log.
            try
            {
                var folder = Path.Combine(SettingsStore.StateRoot, "logs");
                Directory.CreateDirectory(folder);
                var log = Path.Combine(folder, "news-images.log");
                if (File.Exists(log) && new FileInfo(log).Length > 64 * 1024) File.WriteAllText(log, "");
                File.AppendAllText(log, $"{DateTimeOffset.UtcNow:O} | {Path.GetFileName(uri.AbsolutePath)} | {ex.GetType().Name}: {ex.Message}\n");
            }
            catch { /* Diagnostics should never block news rendering. */ }
        }
        finally { if (entered) _newsImageConcurrency.Release(); }
    }

    private void Workshop_Click(object sender, RoutedEventArgs e)
    {
        if (_workshopUrl is null || _workshopCollectionId is null) return;

        // Steam's internal browser opens the Workshop collection directly in the Steam client.
        // Do not send an untrusted URL into a custom URI scheme: only the validated numeric ID.
        var steamLink = "steam://url/CommunityFilePage/" + _workshopCollectionId;
        try
        {
            Process.Start(new ProcessStartInfo(steamLink) { UseShellExecute = true });
        }
        catch (Exception)
        {
            // Steam may be uninstalled or its URL handler may be missing. Open the exact
            // previously validated HTTPS collection URL as a safe fallback.
            try { Process.Start(new ProcessStartInfo(_workshopUrl) { UseShellExecute = true }); }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось открыть коллекцию Steam Workshop: " + ex.Message,
                    "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }

    private async void Check_Click(object sender, RoutedEventArgs e) => await CheckForUpdatesAsync(false);
    private async Task<bool> CheckForUpdatesAsync(bool automatic)
    {
        if (_busy) return false;
        SetBusy(true); UpdateProgress.Value=0; StatusText.Text="Проверка подписанных обновлений…";
        try
        {
            SaveSettings();
            _plan = await _updater.CheckAsync(ManifestUrlBox.Text);
            _lastPatchCheckSucceeded = true;
            var changed = _plan.Changed;
            StatusText.Text = changed.Count == 0 ? $"Клиент актуален: {_plan.Manifest.Version}." : $"Доступен патч {_plan.Manifest.Version}: {changed.Count} файл(ов).";
            DetailsText.Text = _plan.Manifest.Notes;
            UpdateProgress.Value = changed.Count == 0 ? 100 : 0;
            if (automatic && _settings.AutoInstall && changed.Count > 0)
            {
                StatusText.Text = "Устанавливаем подписанные патчи…";
                await _updater.InstallAsync(_plan, new Progress<double>(v => UpdateProgress.Value = v));
                StatusText.Text = $"Обновления {_plan.Manifest.Version} установлены.";
                _plan = null;
            }
            return true;
        }
        catch (Exception ex)
        {
            _lastPatchCheckSucceeded = false; _plan = null;
            StatusText.Text = "Проверка патчей не пройдена"; DetailsText.Text = ex.Message;
            return false;
        }
        finally { SetBusy(false); }
    }
    private async void Install_Click(object sender, RoutedEventArgs e)
    {
        if (_busy || _plan is null || _plan.Changed.Count == 0) return;
        SetBusy(true);
        try
        {
            StatusText.Text = "Загрузка и проверка SHA-256…";
            await _updater.InstallAsync(_plan, new Progress<double>(v => UpdateProgress.Value = v));
            StatusText.Text = $"Патчи {_plan.Manifest.Version} установлены."; DetailsText.Text = "Игровые и Workshop-файлы не изменены."; _plan = null;
        }
        catch (Exception ex) { StatusText.Text = "Установка прервана"; DetailsText.Text = ex.Message; _lastPatchCheckSucceeded = false; }
        finally { SetBusy(false); }
    }
    private void OpenFolder_Click(object sender, RoutedEventArgs e)
    {
        Directory.CreateDirectory(PatchUpdateService.ManagedRoot);
        Process.Start(new ProcessStartInfo("explorer.exe", "\"" + PatchUpdateService.ManagedRoot + "\"") { UseShellExecute = true });
    }
    private void UpdateAutoIpControls()
    {
        AutoIpBox.IsChecked = false;
        HostBox.Text = ServerAddressService.FixedHost;
        PortBox.Text = ServerAddressService.FixedPort.ToString();
        HostBox.IsReadOnly = true;
        PortBox.IsReadOnly = true;
        ServerInfoText.Text = "Адрес: 26.137.250.18:16261 · доступность сервера не проверяется";
        ConnectionHintText.Text = "СЕРВЕР: 26.137.250.18:16261";
    }
    private void AutoIpBox_Changed(object sender, RoutedEventArgs e)
    {
        if (HostBox is null || PortBox is null || ServerInfoText is null) return;
        UpdateAutoIpControls();
    }
    private async void RefreshIp_Click(object sender, RoutedEventArgs e) => await RefreshServerAsync();
    private Task<bool> RefreshServerAsync()
    {
        UpdateAutoIpControls();
        return Task.FromResult(true);
    }
    private bool TryServer(out string address)
    {
        address = ServerAddressService.FixedHost + ":" + ServerAddressService.FixedPort;
        return true;
    }
    // Only read the signed revision; NEVER scan or count locally installed Workshop mods.
    // Steam/Project Zomboid will validate Workshop requirements when joining the server.
    private async Task RefreshModpackRevisionAsync()
    {
        try
        {
            using var sync = new ModpackSyncService();
            var document = await sync.FetchAsync();
            WorkshopHealthText.Text = $"Ревизия: {document.Revision}";
        }
        catch
        {
            // Revision is optional UI metadata: its availability must not block the launcher.
            WorkshopHealthText.Text = "Ревизия недоступна";
        }
    }

    private async Task StartZombieBuddyAsync()
    {
#if ECHO_RELEASE_CANDIDATE
        MessageBox.Show("Установка ZombieBuddy отключена в изолированной RC-сборке. Кнопка включится в финальном клиенте.", "PROJECT ECHO RC");
        await Task.CompletedTask;
        return;
#else
        try
        {
            var path = await _gameClient.DownloadZombieBuddyInstallerAsync();
            var sha = GameClientService.FileSha256(path);
            var prompt = MessageBox.Show("Загружен официальный установщик ZombieBuddy (GitHub).\nSHA-256: " + sha + "\n\nОткрыть? Выбери Install -> Both -> проверь предпросмотр и подтверди изменения.", "PROJECT ECHO", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (prompt == MessageBoxResult.Yes) Process.Start(new ProcessStartInfo(path) { UseShellExecute = true });
        }
        catch (Exception ex)
        {
            var message = ex.Message + "\n\nОткрыть официальный релиз ZombieBuddyInstaller v4.2 в браузере?";
            if (MessageBox.Show(message, "Ошибка ZombieBuddy", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
                Process.Start(new ProcessStartInfo("https://github.com/zed-0xff/ZombieBuddy/releases/tag/windows_installer_4.2") { UseShellExecute = true });
        }
#endif
    }

    private async void ZombieBuddy_Click(object sender, RoutedEventArgs e) => await StartZombieBuddyAsync();

    private void SetMemory_Click(object sender, RoutedEventArgs e)
    {
#if ECHO_RELEASE_CANDIDATE
        MessageBox.Show("Изменение -Xmx отключено в изолированной RC-сборке. Рабочий файл игры не тронут.", "PROJECT ECHO RC");
        return;
#else
        try
        {
            var folder = GameClientService.DetectGameFolder(GameFolderBox.Text);
            if (folder is null) throw new DirectoryNotFoundException("Сначала укажи папку игры.");
            if (MessageBox.Show("Изменить ТОЛЬКО -Xmx на 8192m в ProjectZomboid64.json?\n\nРекомендуется не менее 16 ГБ физической ОЗУ. Будет создана резервная копия JSON. PZ должна быть закрыта.", "PROJECT ECHO", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
            var backup = GameClientService.SetMemory8Gb(folder);
            MessageBox.Show("Значение -Xmx8192m установлено.\nРезервная копия: " + backup, "PROJECT ECHO");
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Ошибка настройки памяти"); }
#endif
    }

    private async void Play_Click(object sender, RoutedEventArgs e)
    {
#if ECHO_RELEASE_CANDIDATE
        MessageBox.Show("Production RC: игровой запуск отключён до окончательной проверки каналов и подписей.", "PROJECT ECHO RC");
        return;
#endif
        if (_busy) return;
        try { SaveSettings(); }
        catch (Exception ex) { MessageBox.Show("Не удалось сохранить профиль: " + ex.Message, "PROJECT ECHO"); return; }
        // Always check the latest signed release before handing control to Steam.
        if (!await CheckForUpdatesAsync(true))
        {
            MessageBox.Show("Проверка подписи обновлений не прошла. Запуск отменён.", "PROJECT ECHO"); return;
        }
        if (_plan is { Changed.Count: > 0 })
        {
            MessageBox.Show("Есть ещё не установленные патчи. Установи их в Настройках перед запуском.", "PROJECT ECHO");
            Settings_Click(sender, e); return;
        }
        // No redundant Workshop scan here. Steam/PZ checks mod compatibility on join.
        string? gameFolder;
        try { gameFolder = GameClientService.DetectGameFolder(GameFolderBox.Text); }
        catch (Exception ex)
        {
            MessageBox.Show("Не найдена папка игры: " + ex.Message, "PROJECT ECHO");
            Settings_Click(sender, e);
            return;
        }
        if (gameFolder is null)
        {
            MessageBox.Show("Укажи папку Project Zomboid в настройках.", "PROJECT ECHO");
            Settings_Click(sender, e);
            return;
        }
        if (!GameClientService.HasZombieBuddy(gameFolder))
        {
            MessageBox.Show("ZombieBuddy не найден в папке игры. Подготовь клиент перед запуском.", "PROJECT ECHO");
            return;
        }
        if (!ConfirmAndApplyEchoSettings()) return;
        if (!await RefreshServerAsync()) return;
        if (!TryServer(out var address)) return;
        try
        {
            // Passwords are NEVER passed in URI, command-line args or Cloudflare API.
            Process.Start(new ProcessStartInfo($"steam://run/108600/+connect%20{address}/") { UseShellExecute = true });
            StatusText.Text = "Запуск PZ через Steam: " + address;
            DetailsText.Text = "Игра может запросить логин и пароль. Если переход не сработает — используй Избранное в PZ.";
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Не удалось открыть Steam"); }
    }
    private async void LaunchGame_Click(object sender, RoutedEventArgs e)
    {
#if ECHO_RELEASE_CANDIDATE
        MessageBox.Show("Production RC: запуск игры отключён, чтобы не менять рабочую установку.", "PROJECT ECHO RC");
        return;
#endif
        // PROJECT_ECHO_STEP14_DIRECT_PLAY: check OWNER-signed updates even on direct game launch.
        if (_busy) return;
        if (!await CheckForUpdatesAsync(true))
        {
            MessageBox.Show("Не удалось проверить подписанные патчи. Запуск отменён.", "PROJECT ECHO"); return;
        }
        if (_plan is { Changed.Count: > 0 })
        {
            MessageBox.Show("Установи ожидающие обновления патчей перед запуском.", "PROJECT ECHO");
            Settings_Click(sender, e); return;
        }
        if (!ConfirmAndApplyEchoSettings()) return;
        try { Process.Start(new ProcessStartInfo("steam://rungameid/108600") { UseShellExecute = true }); }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Не удалось открыть игру"); }
    }
    private async void CopyAddress_Click(object sender, RoutedEventArgs e)
    {
        if (!await RefreshServerAsync()) return;
        if (TryServer(out var address)) Clipboard.SetText(address);
    }
}
