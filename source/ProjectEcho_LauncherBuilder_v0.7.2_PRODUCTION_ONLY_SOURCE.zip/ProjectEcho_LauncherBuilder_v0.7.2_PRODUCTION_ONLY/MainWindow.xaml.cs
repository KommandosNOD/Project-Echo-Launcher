using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using Microsoft.Win32;
using ProjectEcho.Builder.Models;
using ProjectEcho.Builder.Services;

namespace ProjectEcho.Builder;

/// <summary>Owner UI: only working production channels, with no staging/test actions.</summary>
public partial class MainWindow : Window
{
    public ObservableCollection<ManagedMod> Mods { get; } = new();
    public ObservableCollection<ProductionModDiffRow> ProductionModDiffRows { get; } = new();
    private readonly ModInventoryService _inventory = new();
    private readonly BuilderSettings _settings;
    private readonly DispatcherTimer _debouncer;
    private InventoryResult? _latest;
    private FileSystemWatcher? _watcher;
    private bool _busy;

    public MainWindow()
    {
        InitializeComponent();
        DataContext = this;
        _settings = SettingsService.Load();
        ModsRootBox.Text = _settings.ModsRoot;
        ProjectRootBox.Text = _settings.ProjectRoot;
        OutputRootBox.Text = _settings.OutputRoot;
        AutoScanCheck.IsChecked = _settings.AutoRescan;
        AutoSourceZipBox.Text = _settings.ProductionSourceZipPath;
        ProdExePathBox.Text = _settings.ProductionExePath;
        ProdExeVersionBox.Text = _settings.ProductionExeVersion;
        ProdCandidatePathBox.Text = _settings.ProductionExeCandidatePath;
        ModProdCandidateBox.Text = _settings.ProductionModsCandidatePath;
        _debouncer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(3) };
        _debouncer.Tick += async (_, _) => { _debouncer.Stop(); if (!_busy && _settings.AutoRescan) await ScanAsync(); };
    }

    private async void Window_Loaded(object sender, RoutedEventArgs e)
    {
        Tabs.SelectionChanged += Tabs_SelectionChanged; // Only after _settings is ready.
        try
        {
            await ScanAsync();
            StartWatcher();
            SetStatus("Production Builder готов");
        }
        catch (Exception ex)
        {
            Trace("Запуск Builder: " + ex);
            MessageBox.Show(this, ex.Message, "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    private void Window_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        _autoBuildCancellation?.Cancel();
        _watcher?.Dispose();
        _debouncer.Stop();
    }

    private void Trace(string message)
    {
        if (!Dispatcher.CheckAccess()) { Dispatcher.BeginInvoke(() => Trace(message)); return; }
        LogBox.AppendText($"[{DateTime.Now:HH:mm:ss}] {message}\r\n");
        if (LogBox.Text.Length > 500000) LogBox.Text = LogBox.Text[^300000..];
        LogBox.ScrollToEnd();
    }

    private void SetStatus(string message)
    {
        FooterText.Text = "Статус: " + message;
    }

    private void SaveAll()
    {
        if (string.IsNullOrWhiteSpace(ModsRootBox.Text) || string.IsNullOrWhiteSpace(ProjectRootBox.Text) ||
            string.IsNullOrWhiteSpace(OutputRootBox.Text))
            throw new InvalidDataException("Все три папки должны быть заданы в настройках.");
        var modsRoot = Path.GetFullPath(Environment.ExpandEnvironmentVariables(ModsRootBox.Text.Trim().Trim('"')));
        var projectRoot = Path.GetFullPath(Environment.ExpandEnvironmentVariables(ProjectRootBox.Text.Trim().Trim('"')));
        var outputRoot = Path.GetFullPath(Environment.ExpandEnvironmentVariables(OutputRootBox.Text.Trim().Trim('"')));
        if (outputRoot.StartsWith(modsRoot.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar,
              StringComparison.OrdinalIgnoreCase) || outputRoot.Equals(modsRoot, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Папка результатов не должна быть внутри папки модов.");
        _settings.ModsRoot = modsRoot;
        _settings.ProjectRoot = projectRoot;
        _settings.OutputRoot = outputRoot;
        _settings.ProductionExePath = ProdExePathBox.Text.Trim();
        _settings.ProductionExeVersion = ProdExeVersionBox.Text.Trim();
        _settings.ProductionExeCandidatePath = ProdCandidatePathBox.Text.Trim();
        _settings.ProductionSourceZipPath = AutoSourceZipBox.Text.Trim();
        _settings.ProductionModsCandidatePath = ModProdCandidateBox.Text.Trim();
        _settings.AutoRescan = AutoScanCheck.IsChecked == true;
        if (_latest is not null)
        {
            _settings.ExcludedAutoFolders = Mods.Where(m => !m.IsSelected)
                .Select(m => m.Name).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        }
        SettingsService.Save(_settings);
    }

    private async Task ScanAsync()
    {
        if (_busy) return;
        _busy = true;
        try
        {
            SaveAll();
            SetStatus("Проверяем SHA-256 локальных модов…");
            var result = await _inventory.ScanAsync(_settings, Trace);
            _latest = result;
            Mods.Clear();
            foreach (var item in result.Mods) Mods.Add(item);
            int chosen = result.Mods.Count(m => m.IsSelected && m.FileCount > 0);
            ModSelectionSummary.Text = $"Выбрано {chosen} из {result.Mods.Count} папок. Игровых файлов после фильтра: {result.Files.Count}. default.txt: " +
                (result.Files.Any(f => f.Path == "mods/default.txt") ? "ЕСТЬ" : "ОТСУТСТВУЕТ");
            SetStatus("Готово: клиентский modpack проиндексирован");
        }
        catch (Exception ex)
        {
            Trace("Сканирование модов: " + ex);
            ModSelectionSummary.Text = "Не удалось проверить папку модов: " + ex.Message;
            SetStatus("Проверь настройки папок");
        }
        finally { _busy = false; }
    }

    private void StartWatcher()
    {
        _watcher?.Dispose();
        if (!Directory.Exists(_settings.ModsRoot)) return;
        _watcher = new FileSystemWatcher(_settings.ModsRoot)
        {
            IncludeSubdirectories = true, NotifyFilter = NotifyFilters.FileName | NotifyFilters.DirectoryName | NotifyFilters.LastWrite,
            EnableRaisingEvents = true
        };
        FileSystemEventHandler changed = (_, _) => Dispatcher.BeginInvoke(() => { _debouncer.Stop(); _debouncer.Start(); });
        RenamedEventHandler renamed = (_, _) => Dispatcher.BeginInvoke(() => { _debouncer.Stop(); _debouncer.Start(); });
        _watcher.Changed += changed;
        _watcher.Created += changed;
        _watcher.Deleted += changed;
        _watcher.Renamed += renamed;
    }

    private async void SaveSettings_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            SaveAll();
            await ScanAsync();
            StartWatcher();
            SetStatus("Настройки сохранены");
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Настройки", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private void ChooseMods_Click(object sender, RoutedEventArgs e) => ChooseFolder(ModsRootBox);
    private void ChooseProject_Click(object sender, RoutedEventArgs e) => ChooseFolder(ProjectRootBox);
    private void ChooseOutput_Click(object sender, RoutedEventArgs e) => ChooseFolder(OutputRootBox);
    private void ChooseFolder(TextBox target)
    {
        var dialog = new OpenFolderDialog { Title = "PROJECT ECHO — выбрать папку" };
        if (dialog.ShowDialog(this) == true) target.Text = dialog.FolderName;
    }

    private async void AddExtraFolder_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            SaveAll();
            var folder = PathSafety.CheckFolderName(ExtraFolderName.Text.Trim());
            if (ProductionPayloadFilter.IgnoreDirectory(folder))
                throw new InvalidDataException("Служебную/резервную папку нельзя добавить как мод.");
            if (!_settings.AdditionalFolders.Contains(folder, StringComparer.OrdinalIgnoreCase))
                _settings.AdditionalFolders.Add(folder);
            _settings.ExcludedAutoFolders.RemoveAll(x => string.Equals(x, folder, StringComparison.OrdinalIgnoreCase));
            SettingsService.Save(_settings);
            ExtraFolderName.Text = "";
            await ScanAsync();
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Добавление папки", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private async void RemoveExtraFolder_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            SaveAll();
            var folder = PathSafety.CheckFolderName(ExtraFolderName.Text.Trim());
            _settings.AdditionalFolders.RemoveAll(x => string.Equals(x, folder, StringComparison.OrdinalIgnoreCase));
            _settings.ExcludedAutoFolders.RemoveAll(x => string.Equals(x, folder, StringComparison.OrdinalIgnoreCase));
            SettingsService.Save(_settings);
            ExtraFolderName.Text = "";
            await ScanAsync();
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Удаление дополнительной папки", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private void ClearLog_Click(object sender, RoutedEventArgs e) => LogBox.Clear();

    private void ProdExeVersionBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (ReleaseCheckProgress is not null) ResetReleaseChecklist();
    }

    private bool ReleaseChecklistComplete() =>
        ReleaseCheckProgress.IsChecked == true && ReleaseCheckStatus.IsChecked == true &&
        ReleaseCheckPlayers.IsChecked == true && ReleaseCheckNews.IsChecked == true &&
        ReleaseCheckMinidoracat.IsChecked == true && ReleaseCheckUpdates.IsChecked == true;

    private void ResetReleaseChecklist()
    {
        ReleaseCheckProgress.IsChecked = false;
        ReleaseCheckStatus.IsChecked = false;
        ReleaseCheckPlayers.IsChecked = false;
        ReleaseCheckNews.IsChecked = false;
        ReleaseCheckMinidoracat.IsChecked = false;
        ReleaseCheckUpdates.IsChecked = false;
    }
}
