using System.IO;
using System.Windows;
using ProjectEcho.Builder.Services;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder;

public partial class MainWindow
{
    private readonly GitHubProductionModsService _productionMods = new();
    private readonly ProductionModDiffService _productionModDiff = new();

    private async void ModProdCompare_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        _busy = true;
        try
        {
            SaveAll();
            ModProdDiffStatus.Text = "Проверяем подпись production-манифеста и локальные файлы...";
            var result = await _productionModDiff.CompareAsync(_settings, CancellationToken.None);
            ProductionModDiffRows.Clear();
            foreach (var row in result.Rows) ProductionModDiffRows.Add(row);
            ModProdDiffStatus.Text = $"Эталон {result.Revision} · новых {result.Added}, изменённых {result.Modified}, не в пакете {result.Missing}, совпадают {result.Unchanged}.";
            ModProdDefaultStatus.Text = "default.txt включён · SHA-256: " + result.DefaultSha256;
            SetStatus("Сравнение production модов завершено");
        }
        catch (Exception ex)
        {
            ModProdDiffStatus.Text = "СРАВНЕНИЕ НЕ ПРОЙДЕНО: " + ex.Message;
            Trace("MODS PRODUCTION COMPARE: " + ex);
            MessageBox.Show(this, ex.Message, "Моды production: сравнение", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { _busy = false; }
    }

    private async void ModProdRefresh_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        await ScanAsync();
        ModProdDiffStatus.Text = "Локальные моды пересканированы. Для нового сравнения нажми «Проверить изменения».";
    }

    private async void ModProdPrepare_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        _busy = true;
        try
        {
            SaveAll();
            ModProdCandidateStatus.Text = "Создаём полный снимок из текущих локальных файлов и подписываем...";
            var result = await _productionMods.PrepareAsync(_settings, Trace, CancellationToken.None);
            ModProdCandidateBox.Text = result.Folder;
            _settings.ProductionModsCandidatePath = result.Folder;
            SettingsService.Save(_settings);
            var check = await _productionMods.PreflightAsync(result.Folder, _settings, CancellationToken.None);
            ModProdCandidateStatus.Text = $"ПОДПИСАНО ECDSA: версия {check.Version}; {check.Count} файлов; {check.Bytes:N0} байт.";
            ModProdDefaultStatus.Text = "default.txt находится в обязательном подписанном manifest.json (mods/default.txt).";
            SetStatus("Подписанный production-модпак готов. Не опубликован.");
        }
        catch (Exception ex)
        {
            ModProdCandidateStatus.Text = "ОШИБКА: " + ex.Message;
            Trace("MODS PRODUCTION PREPARE: " + ex);
            MessageBox.Show(this, ex.Message, "Моды production: подготовка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { _busy = false; }
    }

    private async void ModProdVerify_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        _busy = true;
        try
        {
            SaveAll();
            var check = await _productionMods.PreflightAsync(ModProdCandidateBox.Text, _settings, CancellationToken.None);
            ModProdCandidateStatus.Text = $"ПРОВЕРЕНО ECDSA + SHA-256: {check.Count} файлов; {check.Bytes:N0} байт; ревизия {check.Version}.";
            SetStatus("Production-модпак проверен; публикации не было");
        }
        catch (Exception ex)
        {
            ModProdCandidateStatus.Text = "ПРОВЕРКА НЕ ПРОЙДЕНА: " + ex.Message;
            Trace("MODS PRODUCTION VERIFY: " + ex);
            MessageBox.Show(this, ex.Message, "Моды production: проверка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { _busy = false; }
    }

    private async void ModProdPublish_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        if (ModProdConfirmBox.Text.Trim() != "RELEASE-PROD-MODS")
        {
            MessageBox.Show(this, "Введи RELEASE-PROD-MODS для публикации рабочего модпака.",
                "Подтверждение", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (MessageBox.Show(this,
            "ВНИМАНИЕ! РАБОЧАЯ ПУБЛИКАЦИЯ ДЛЯ ИГРОКОВ.\n\n" +
            "Builder запишет новый подписанный снимок модов в production-ветку GitHub. " +
            "При проверке обновлений игроки начнут получать изменения, включая default.txt. " +
            "Удаление устаревших файлов у игроков НЕ выполняется.\n\n" +
            "Ты проверил выбор модов и сравнение с текущим production?",
            "PROJECT ECHO — МОДЫ PRODUCTION", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            return;
        _busy = true;
        try
        {
            SaveAll();
            var diff = await _productionModDiff.CompareAsync(_settings, CancellationToken.None);
            // The verified remote channel is also checked again by the publisher.
            if (diff.Missing > 0 && MessageBox.Show(this,
                $"В НОВОМ ПАКЕТЕ НЕ БУДЕТ {diff.Missing} файлов предыдущего релиза.\n\n" +
                "У игроков ничего автоматически не удалится, но при новой установке этих файлов не будет. Продолжить?",
                "Проверка исключённых файлов", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
            var check = await _productionMods.PreflightAsync(ModProdCandidateBox.Text, _settings, CancellationToken.None);
            ModProdPublishStatus.Text = "Публикуем подписанный модпак, проверяя Git blobs и коммит...";
            var published = await _productionMods.PublishProductionAsync(check.Folder, _settings, Trace, CancellationToken.None);
            ModProdPublishStatus.Text = $"ОПУБЛИКОВАНО: {published.Files} файлов, {published.Bytes:N0} байт; SHA коммита {published.Commit}\n{published.Url}";
            ModProdConfirmBox.Clear();
            SetStatus("Production-моды опубликованы, клиентам доступна новая ревизия");
        }
        catch (Exception ex)
        {
            ModProdPublishStatus.Text = "ОШИБКА ПУБЛИКАЦИИ: " + ex.Message;
            Trace("MODS PRODUCTION PUBLISH: " + ex);
            MessageBox.Show(this, ex.Message + "\n\nПроверь журнал и GitHub перед повтором.",
                "Моды production", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { _busy = false; }
    }
}
