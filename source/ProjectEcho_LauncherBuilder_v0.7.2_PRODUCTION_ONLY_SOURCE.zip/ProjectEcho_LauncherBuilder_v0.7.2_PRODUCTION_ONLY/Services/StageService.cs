using System.IO;
using System.Security.Cryptography;
using System.Text.Json;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder.Services;

/// <summary>
/// Private temporary area for one COMPLETE production candidate.
/// Does not publish, change game files or issue deletions.
/// The production owner service signs and verifies this snapshot before publishing.
/// </summary>
internal sealed class StageService
{
    public async Task<string> StageAsync(InventoryResult inventory, BuilderSettings settings,
        Action<string>? log, CancellationToken ct, bool fullSnapshot = false)
    {
        if (!fullSnapshot)
            throw new InvalidOperationException("Builder Production Only разрешает лишь полные снимки для рабочего канала.");
        var selected = inventory.Mods.Where(m => m.IsSelected && m.FileCount > 0)
            .Select(m => m.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
        if (selected.Count == 0) throw new InvalidDataException("Не выбраны игровые моды.");
        var chosen = inventory.Files.Where(f => f.Path == "mods/default.txt" ||
                (f.Path.StartsWith("mods/", StringComparison.Ordinal) &&
                 selected.Contains(f.Path.Split('/')[1])))
            .OrderBy(f => f.Path, StringComparer.OrdinalIgnoreCase).ToList();
        if (!chosen.Any(f => f.Path == "mods/default.txt"))
            throw new FileNotFoundException("Нужен Zomboid\\mods\\default.txt для подписанного пакета.");
        if (chosen.Any(f => ProductionPayloadFilter.IgnorePatchPath(f.Path)))
            throw new InvalidDataException("В полном снимке найден запрещённый служебный файл.");
        var stamp = DateTimeOffset.UtcNow.ToString("yyyyMMdd-HHmmss-fff");
        var draft = Path.Combine(Path.GetFullPath(settings.OutputRoot), "drafts", stamp);
        var intermediate = draft + ".incomplete";
        if (Directory.Exists(draft) || Directory.Exists(intermediate))
            throw new IOException("Каталог кандидата уже существует. Повтори подготовку.");
        Directory.CreateDirectory(intermediate);
        try
        {
            foreach (var file in chosen)
            {
                ct.ThrowIfCancellationRequested();
                var destination = PathSafety.SafeTarget(Path.Combine(intermediate, "files"), file.Path);
                Directory.CreateDirectory(Path.GetDirectoryName(destination)!);
                await using (var input = new FileStream(file.FullPath, FileMode.Open, FileAccess.Read,
                    FileShare.Read, 1024 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan))
                await using (var output = new FileStream(destination, FileMode.CreateNew, FileAccess.Write,
                    FileShare.None, 1024 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan))
                {
                    await input.CopyToAsync(output, ct);
                }
                await using var verify = File.OpenRead(destination);
                var sha = Convert.ToHexString(await SHA256.HashDataAsync(verify, ct)).ToLowerInvariant();
                if (new FileInfo(destination).Length != file.Size ||
                    !sha.Equals(file.Sha256, StringComparison.OrdinalIgnoreCase))
                    throw new CryptographicException("Файл изменился во время формирования: " + file.Path);
                log?.Invoke("Пакет: " + file.Path);
            }
            var manifest = new OwnerManifest
            {
                Version = stamp,
                Files = chosen.Select(f => new ManifestFile
                {
                    Path = f.Path, Size = f.Size, Sha256 = f.Sha256, Url = "files/" + f.Path
                }).ToList(),
                Retired = new List<ManifestFile>() // Never issue client-side deletions.
            };
            await File.WriteAllTextAsync(Path.Combine(intermediate, "manifest.json"),
                JsonSerializer.Serialize(manifest, new JsonSerializerOptions { WriteIndented = true }), ct);
            Directory.Move(intermediate, draft);
            return draft;
        }
        catch
        {
            try { if (Directory.Exists(intermediate)) Directory.Delete(intermediate, recursive: true); }
            catch { /* Preserve the original exception; inspect the temporary folder manually. */ }
            throw;
        }
    }
}
