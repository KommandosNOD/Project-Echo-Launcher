using System.IO;
using System.Security.Cryptography;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder.Services;

internal sealed class ModInventoryService
{
    public Task<InventoryResult> ScanAsync(BuilderSettings settings, Action<string>? log, CancellationToken ct = default) =>
        Task.Run(() => Scan(settings, log, ct), ct);

    private static InventoryResult Scan(BuilderSettings settings, Action<string>? log, CancellationToken ct)
    {
        var root = Path.GetFullPath(settings.ModsRoot);
        if (!Directory.Exists(root)) throw new DirectoryNotFoundException("Не найдена папка модов: " + root);
        PathSafety.CheckDirectory(root);
        var extras = new HashSet<string>(settings.AdditionalFolders.Select(PathSafety.CheckFolderName), StringComparer.OrdinalIgnoreCase);
        var excluded = new HashSet<string>(settings.ExcludedAutoFolders, StringComparer.OrdinalIgnoreCase);
        var dirs = Directory.EnumerateDirectories(root).OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();
        var selectedDirs = dirs.Where(d => !ProductionPayloadFilter.IgnoreDirectory(Path.GetFileName(d)) &&
            (Path.GetFileName(d).StartsWith("ProjectEcho", StringComparison.OrdinalIgnoreCase) ||
             extras.Contains(Path.GetFileName(d)))).ToList();
        var mods = new List<ManagedMod>();
        var files = new List<ManagedFile>();
        var allPaths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var dir in selectedDirs)
        {
            ct.ThrowIfCancellationRequested();
            PathSafety.CheckDirectory(dir);
            string name = PathSafety.CheckFolderName(Path.GetFileName(dir));
            bool auto = name.StartsWith("ProjectEcho", StringComparison.OrdinalIgnoreCase);
            bool isSelected = !excluded.Contains(name);
            log?.Invoke("СКАН: " + name);
            var mod = new ManagedMod { Name = name, Automatic = auto, IsSelected = isSelected };
            var local = Walk(root, dir, ct).ToList();
            foreach (var f in local)
            {
                if (!allPaths.Add(f.Path)) throw new InvalidDataException("Дубликат имени с другим регистром: " + f.Path);
                mod.FileCount++;
                mod.Bytes += f.Size;
                files.Add(f);
            }
            mod.Status = local.Count == 0 ? "ПУСТО" : auto ? "Автообнаружение" : "Добавлен вручную";
            mods.Add(mod);
        }
        foreach (var extra in extras)
            if (!mods.Any(m => string.Equals(m.Name, extra, StringComparison.OrdinalIgnoreCase)))
                mods.Add(new ManagedMod { Name = extra, Automatic = false, IsSelected = false, Status = "ПАПКА НЕ НАЙДЕНА" });
        var defaultPath = Path.Combine(root, "default.txt");
        if (File.Exists(defaultPath))
        {
            PathSafety.CheckFile(defaultPath);
            var f = HashFile("mods/default.txt", defaultPath, ct);
            if (!allPaths.Add(f.Path)) throw new InvalidDataException("Повторяющийся файл default.txt");
            files.Add(f);
            log?.Invoke("default.txt: найден, SHA-256 рассчитан");
        }
        else log?.Invoke("ВНИМАНИЕ: default.txt не найден — публикация должна быть заблокирована.");
        return new InventoryResult(files, mods, root);
    }

    private static IEnumerable<ManagedFile> Walk(string modsRoot, string modDir, CancellationToken ct)
    {
        var pending = new Stack<string>();
        pending.Push(modDir);
        while (pending.Count > 0)
        {
            ct.ThrowIfCancellationRequested();
            var current = pending.Pop();
            PathSafety.CheckDirectory(current);
            foreach (var childDir in Directory.EnumerateDirectories(current))
            {
                if (PathSafety.IgnoreDirectory(Path.GetFileName(childDir)) ||
                    ProductionPayloadFilter.IgnoreDirectory(Path.GetFileName(childDir))) continue;
                PathSafety.CheckDirectory(childDir);
                pending.Push(childDir);
            }
            foreach (var file in Directory.EnumerateFiles(current))
            {
                ct.ThrowIfCancellationRequested();
                if (PathSafety.IgnoreFile(Path.GetFileName(file)) ||
                    ProductionPayloadFilter.IgnoreFile(Path.GetFileName(file))) continue;
                PathSafety.CheckFile(file);
                var patchPath = "mods/" + Path.GetRelativePath(modsRoot, file).Replace('\\', '/');
                PathSafety.ValidatePatchPath(patchPath);
                yield return HashFile(patchPath, file, ct);
            }
        }
    }

    private static ManagedFile HashFile(string path, string absolute, CancellationToken ct)
    {
        using var stream = new FileStream(absolute, FileMode.Open, FileAccess.Read, FileShare.Read, 1024 * 1024, FileOptions.SequentialScan);
        using var sha = SHA256.Create();
        var hash = sha.ComputeHash(stream);
        ct.ThrowIfCancellationRequested();
        return new ManagedFile(path, absolute, stream.Length, Convert.ToHexString(hash).ToLowerInvariant());
    }
}
