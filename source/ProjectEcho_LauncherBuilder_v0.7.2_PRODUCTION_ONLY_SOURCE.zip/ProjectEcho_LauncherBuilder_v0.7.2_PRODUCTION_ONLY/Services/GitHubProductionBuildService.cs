using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder.Services;

/// <summary>
/// Builds the reviewed production client in GitHub Actions. Does not publish Releases,
/// touch production update manifests or upload private signing keys.
/// Only an explicitly selected public source ZIP is sent to GitHub.
/// </summary>
internal sealed class GitHubProductionBuildService
{
    private const string Repo = "KommandosNOD/Project-Echo-Launcher";
    private const string Workflow = "build-project-echo-auto.yml";
    private const string SourcePath = "source/auto/PROJECT_ECHO_Production_Source.zip";
    private const int MaxZipBytes = 8 * 1024 * 1024;
    internal sealed record Result(string ExePath, string Version, string Sha256, long RunId, string RunUrl);
    private sealed record CliResult(int ExitCode, string Output, string Error);

    private static async Task<CliResult> CliAsync(string workDir, string[] arguments, CancellationToken ct)
    {
        var psi = new ProcessStartInfo("gh")
        {
            WorkingDirectory = workDir, UseShellExecute = false, RedirectStandardOutput = true,
            RedirectStandardError = true, CreateNoWindow = true
        };
        foreach (var arg in arguments) psi.ArgumentList.Add(arg);
        using var process = new Process { StartInfo = psi };
        try { if (!process.Start()) throw new IOException("Не удалось запустить gh.exe."); }
        catch (Win32Exception e) { throw new InvalidOperationException("Нужен установленный GitHub CLI и авторизация gh auth login.", e); }
        using var reg = ct.Register(() => { try { if (!process.HasExited) process.Kill(entireProcessTree: true); } catch { } });
        var output = process.StandardOutput.ReadToEndAsync(ct);
        var error = process.StandardError.ReadToEndAsync(ct);
        await Task.WhenAll(output, error, process.WaitForExitAsync(ct));
        return new CliResult(process.ExitCode, output.Result.Trim(), error.Result.Trim());
    }

    private static async Task<string> MustAsync(string folder, CancellationToken ct, params string[] args)
    {
        var res = await CliAsync(folder, args, ct);
        if (res.ExitCode != 0)
            throw new IOException("GitHub CLI: " + (res.Error.Length > 1800 ? res.Error[..1800] : res.Error));
        return res.Output;
    }

    private static async Task OwnerCheckAsync(string folder, CancellationToken ct)
    {
        var login = await MustAsync(folder, ct, "api", "user", "--jq", ".login");
        if (login != "KommandosNOD") throw new UnauthorizedAccessException("GitHub CLI должен быть авторизован как KommandosNOD.");
        var canPush = await MustAsync(folder, ct, "api", "repos/" + Repo, "--jq", ".permissions.push");
        if (canPush != "true") throw new UnauthorizedAccessException("Нет права загружать исходники в GitHub.");
    }

    internal static string CheckSourceZip(string zipPath, string requestedVersion)
    {
        if (!Regex.IsMatch(requestedVersion, @"^\d+\.\d+\.\d+$"))
            throw new InvalidDataException("Версия должна иметь формат 0.8.2.");
        var path = Path.GetFullPath(zipPath.Trim().Trim('"'));
        if (!File.Exists(path) || (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
            throw new FileNotFoundException("ZIP отсутствует или является ссылкой.", path);
        if (new FileInfo(path).Length is < 1000 or > MaxZipBytes)
            throw new InvalidDataException("Архив исходников должен иметь размер от 1 КиБ до 8 МиБ.");
        using var zip = ZipFile.OpenRead(path);
        if (zip.Entries.Count is < 10 or > 4000) throw new InvalidDataException("Неожиданное число файлов в исходниках.");
        ZipArchiveEntry? launcher = null;
        bool updater = false;
        long sum = 0;
        foreach (var entry in zip.Entries)
        {
            var name = entry.FullName.Replace('\\', '/');
            var segments = name.Split('/');
            if (name.StartsWith('/') || name.Contains(':') || segments.Any(s => s == ".." || s == "."))
                throw new InvalidDataException("В архиве обнаружен небезопасный путь: " + name);
            if (segments.Any(s => new[] { "secrets", ".git", ".github", "obj", "bin", "node_modules" }
                   .Contains(s, StringComparer.OrdinalIgnoreCase)) ||
                (name.EndsWith(".pem", StringComparison.OrdinalIgnoreCase) &&
                    !name.Equals("launcher/TrustedReleasePublicKey.pem", StringComparison.OrdinalIgnoreCase)) ||
                name.EndsWith(".p8", StringComparison.OrdinalIgnoreCase) ||
                name.EndsWith(".snk", StringComparison.OrdinalIgnoreCase) ||
                name.EndsWith(".kdbx", StringComparison.OrdinalIgnoreCase) ||
                name.EndsWith(".pfx", StringComparison.OrdinalIgnoreCase) ||
                name.EndsWith(".p12", StringComparison.OrdinalIgnoreCase) ||
                name.EndsWith(".key", StringComparison.OrdinalIgnoreCase) ||
                name.EndsWith(".env", StringComparison.OrdinalIgnoreCase) ||
                name.EndsWith("release-private.pem", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Нельзя загружать служебные или секретные файлы: " + name);
            sum += entry.Length;
            if (sum > 75L * 1024 * 1024) throw new InvalidDataException("Слишком большой распакованный архив.");
            if (name == "launcher/PZLauncher.csproj") launcher = entry;
            if (name == "updater/ProjectEchoUpdater.csproj") updater = true;
        }
        if (launcher is null || !updater)
            throw new InvalidDataException("ZIP должен содержать launcher/PZLauncher.csproj и updater/ProjectEchoUpdater.csproj.");
        using var reader = new StreamReader(launcher.Open(), Encoding.UTF8);
        var project = XDocument.Parse(reader.ReadToEnd());
        var prop = project.Descendants().FirstOrDefault(x => x.Name.LocalName == "Version")?.Value.Trim();
        if (prop != requestedVersion) throw new InvalidDataException("Версия в исходниках " + prop + " не совпадает с " + requestedVersion);
        var allDefines = string.Join(";", project.Descendants().Where(x => x.Name.LocalName == "DefineConstants").Select(x => x.Value));
        if (!allDefines.Contains("ECHO_PRODUCTION_CLIENT", StringComparison.Ordinal))
            throw new InvalidDataException("Это не исходники production-клиента: нет ECHO_PRODUCTION_CLIENT.");
        return path;
    }

    /// <summary>Creates the workflow on main once; refuses to overwrite an existing workflow.</summary>
    internal async Task InstallWorkflowAsync(string yamlText, BuilderSettings settings, CancellationToken ct)
    {
        var root = Path.GetFullPath(settings.OutputRoot);
        Directory.CreateDirectory(root);
        await OwnerCheckAsync(root, ct);
        var endpoint = "repos/" + Repo + "/contents/.github/workflows/" + Workflow;
        var existing = await CliAsync(root, new[] { "api", endpoint, "--jq", ".sha" }, ct);
        if (existing.ExitCode == 0) throw new InvalidOperationException("Workflow уже установлен. Ничего перезаписывать не будем.");
        if (!existing.Error.Contains("404", StringComparison.Ordinal)) throw new IOException(existing.Error);
        var payload = Path.Combine(root, ".workflow-upload-" + Guid.NewGuid().ToString("N") + ".json");
        try
        {
            await File.WriteAllTextAsync(payload, JsonSerializer.Serialize(new
            {
                message = "ci: add manual owner-only build workflow for PROJECT ECHO",
                branch = "main", content = Convert.ToBase64String(Encoding.UTF8.GetBytes(yamlText))
            }), ct);
            await MustAsync(root, ct, "api", "--method", "PUT", endpoint, "--input", payload, "--jq", ".commit.sha");
        }
        finally { try { File.Delete(payload); } catch { } }
    }

    internal async Task<Result> BuildAsync(string zipPath, string requestedVersion, BuilderSettings settings,
        Action<string> progress, CancellationToken ct)
    {
        var localSource = CheckSourceZip(zipPath, requestedVersion);
        var root = Path.Combine(Path.GetFullPath(settings.OutputRoot), "github-launcher-builds");
        Directory.CreateDirectory(root);
        await OwnerCheckAsync(root, ct);
        await MustAsync(root, ct, "api", "repos/" + Repo + "/contents/.github/workflows/" + Workflow, "--jq", ".sha");
        var endpoint = "repos/" + Repo + "/contents/" + SourcePath;
        var old = await CliAsync(root, new[] { "api", endpoint, "--jq", ".sha" }, ct);
        if (old.ExitCode != 0 && !old.Error.Contains("404", StringComparison.Ordinal))
            throw new IOException("Не удалось проверить исходники в GitHub: " + old.Error);
        var payload = Path.Combine(root, ".source-upload-" + Guid.NewGuid().ToString("N") + ".json");
        try
        {
            var upload = new Dictionary<string, object?>
            {
                ["message"] = "build: stage reviewed PROJECT ECHO production source v" + requestedVersion,
                ["branch"] = "main",
                ["content"] = Convert.ToBase64String(await File.ReadAllBytesAsync(localSource, ct))
            };
            if (old.ExitCode == 0) upload["sha"] = old.Output;
            await File.WriteAllTextAsync(payload, JsonSerializer.Serialize(upload), ct);
            progress("Загружаем ZIP исходников в GitHub, без приватного ECDSA-ключа...");
            var response = await MustAsync(root, ct, "api", "--method", "PUT", endpoint, "--input", payload);
            using var doc = JsonDocument.Parse(response);
            var commit = doc.RootElement.GetProperty("commit").GetProperty("sha").GetString();
            if (commit is null || !Regex.IsMatch(commit, "^[a-f0-9]{40}$"))
                throw new InvalidDataException("GitHub не подтвердил SHA коммита исходников.");
            progress("Исходники загружены. GitHub commit: " + commit[..10]);

            await MustAsync(root, ct, "workflow", "run", Workflow, "--repo", Repo,
                "--ref", "main", "-f", "version=" + requestedVersion, "-f", "commit=" + commit);
            progress("Windows-сборка запущена. Ожидаем результат GitHub Actions...");
            var title = "PROJECT ECHO v" + requestedVersion + " (" + commit + ")";
            long runId = 0;
            for (var tries = 0; tries < 36; tries++)
            {
                ct.ThrowIfCancellationRequested();
                await Task.Delay(TimeSpan.FromSeconds(5), ct);
                var runList = await MustAsync(root, ct, "run", "list", "--repo", Repo, "--workflow", Workflow,
                    "--limit", "40", "--json", "databaseId,displayTitle,status,conclusion");
                using var runs = JsonDocument.Parse(runList);
                var match = runs.RootElement.EnumerateArray().FirstOrDefault(x => x.GetProperty("displayTitle").GetString() == title);
                if (match.ValueKind != JsonValueKind.Undefined)
                {
                    runId = match.GetProperty("databaseId").GetInt64();
                    break;
                }
            }
            if (runId <= 0) throw new TimeoutException("GitHub не показал запущенную сборку. Проверь Actions: " + title);
            var runUrl = "https://github.com/" + Repo + "/actions/runs/" + runId;
            progress("GitHub Actions: " + runUrl);
            string status = "";
            string conclusion = "";
            for (var tries = 0; tries < 240; tries++)
            {
                ct.ThrowIfCancellationRequested();
                var json = await MustAsync(root, ct, "run", "view", runId.ToString(), "--repo", Repo,
                    "--json", "status,conclusion");
                using var run = JsonDocument.Parse(json);
                status = run.RootElement.GetProperty("status").GetString() ?? "";
                conclusion = run.RootElement.GetProperty("conclusion").GetString() ?? "";
                if (status == "completed") break;
                await Task.Delay(TimeSpan.FromSeconds(5), ct);
            }
            if (status != "completed") throw new TimeoutException("GitHub Actions работает дольше 20 минут: " + runUrl);
            if (conclusion != "success") throw new IOException("Сборка завершилась: " + conclusion + ". Открой журнал: " + runUrl);
            var artifact = "PROJECT-ECHO-Launcher-" + requestedVersion + "-RC";
            var dest = Path.Combine(root, "v" + requestedVersion + "-run-" + runId);
            if (Directory.Exists(dest)) throw new IOException("Результат такой сборки уже существует: " + dest);
            Directory.CreateDirectory(dest);
            progress("Сборка успешна. Скачиваем подписываемый EXE...");
            await MustAsync(root, ct, "run", "download", runId.ToString(), "--repo", Repo,
                "--name", artifact, "--dir", dest);
            var exe = Path.Combine(dest, "ProjectEchoLauncher.exe");
            var sums = Path.Combine(dest, "SHA256SUMS.txt");
            if (!File.Exists(exe) || !File.Exists(sums)) throw new IOException("В артефакте нет EXE или SHA256SUMS.txt.");
            var content = (await File.ReadAllTextAsync(sums, ct)).Trim();
            var expected = content.Split(' ', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault()?.ToLowerInvariant();
            if (expected is null || !Regex.IsMatch(expected, "^[a-f0-9]{64}$") || !content.EndsWith("ProjectEchoLauncher.exe", StringComparison.Ordinal))
                throw new InvalidDataException("Некорректный SHA256SUMS.txt в артефакте.");
            await using var stream = File.OpenRead(exe);
            var actual = Convert.ToHexString(await SHA256.HashDataAsync(stream, ct)).ToLowerInvariant();
            if (actual != expected) throw new CryptographicException("Скачанный EXE не совпадает по SHA-256 с GitHub Actions!");
            var fileVersion = FileVersionInfo.GetVersionInfo(exe);
            if ($"{fileVersion.FileMajorPart}.{fileVersion.FileMinorPart}.{fileVersion.FileBuildPart}" != requestedVersion)
                throw new InvalidDataException("EXE содержит другую версию, публикация заблокирована.");
            progress("SHA-256 и версия EXE совпадают. Готов кандидат для локальной ECDSA-подписи.");
            return new Result(exe, requestedVersion, actual, runId, runUrl);
        }
        finally { try { File.Delete(payload); } catch { } }
    }
}
