using System.IO;

namespace ProjectEcho.Builder.Services;

/// <summary>
/// Production allow-list by purpose: keep actual game payload (.jar, .pack, .obj,
/// .tiles, .lua, .json etc.) while ignoring known editor/build/backup artifacts.
/// The SAME rules are used by diff, prepare and publish preflight.
/// </summary>
internal static class ProductionPayloadFilter
{
    private static readonly HashSet<string> ExcludedExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".bak", ".old", ".java", ".orig", ".tmp", ".temp", ".swp", ".swo",
        ".cs", ".csproj", ".sln", ".slnx", ".pdb"
    };

    private static readonly HashSet<string> ExcludedFolders = new(StringComparer.OrdinalIgnoreCase)
    {
        ".git", ".svn", ".vs", ".vscode", ".idea", "__pycache__",
        "backup", "backups", "old", "archive", "archives", "archived",
        "src", "source", "sources", "test", "tests", "smoketest", "bin", "obj",
        "temp", "tmp", "_old", "_backup", "_backups"
    };

    internal static bool IgnoreDirectory(string name)
    {
        if (ExcludedFolders.Contains(name)) return true;
        var n = name.ToLowerInvariant();
        // Examples: PE_MenuLabelsRU_backup_v12_20261021 / Backup_20261020.
        return n.StartsWith("backup_") || n.StartsWith("backup-") ||
               n.StartsWith("backup ") || n.StartsWith("backups_") ||
               n.StartsWith("old_") || n.StartsWith("archive_") ||
               n.EndsWith("_backup") || n.EndsWith("-backup") ||
               n.Contains("_backup_") || n.Contains("-backup-") ||
               n.Contains("_backups_") || n.Contains("_smoketest_");
    }

    internal static bool IgnoreFile(string name)
    {
        if (name.EndsWith("~", StringComparison.Ordinal)) return true;
        if (name.StartsWith("~$", StringComparison.Ordinal)) return true;
        // .jar remains allowed: Minidoracat is a separate installer, while
        // 3D/compatibility runtime JARs inside ProjectEcho mods ARE needed.
        return ExcludedExtensions.Contains(Path.GetExtension(name));
    }

    internal static bool IgnorePatchPath(string path)
    {
        var parts = path.Replace('\\', '/').Split('/');
        // Path is mods/<name>/... ; a root default.txt is always kept.
        if (parts.Length == 2 && parts[0] == "mods" && parts[1] == "default.txt") return false;
        for (int i = 1; i < parts.Length - 1; i++)
            if (IgnoreDirectory(parts[i])) return true;
        return IgnoreFile(parts[^1]);
    }
}
