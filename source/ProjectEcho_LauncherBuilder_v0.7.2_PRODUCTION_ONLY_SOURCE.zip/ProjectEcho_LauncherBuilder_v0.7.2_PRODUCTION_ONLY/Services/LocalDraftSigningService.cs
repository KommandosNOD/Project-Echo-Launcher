using System.IO;
using System.Security.Cryptography;
using System.Text.Json;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder.Services;

/// <summary>
/// Owner-side ECDSA signer for private production candidates. Uses existing key in place.
/// Never copies the key to the output and never publishes a release.
/// </summary>
internal sealed class LocalDraftSigningService
{
    private const long MaxFileBytes = 512L * 1024 * 1024;
    private const long MaxTotalBytes = 8L * 1024 * 1024 * 1024;
    private const int MaxManifestBytes = 4 * 1024 * 1024;

    internal sealed record DraftDetails(string Folder, int FileCount, long Bytes, string Version);

    private static string NormalizeDraft(string folder, string outputRoot)
    {
        var draft = Path.GetFullPath(Environment.ExpandEnvironmentVariables(folder.Trim().Trim('"')));
        var parent = Path.GetFullPath(Path.Combine(outputRoot, "drafts"));
        var prefix = parent.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        if (!draft.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Для подписи выбирай только папку из настроенного каталога OutputRoot/drafts.");
        PathSafety.CheckDirectory(parent);
        PathSafety.CheckDirectory(draft);
        return draft;
    }

    private static async Task<(byte[] Data, DraftDetails Details)> ValidateAsync(
        string folder, string outputRoot, CancellationToken ct)
    {
        var root = NormalizeDraft(folder, outputRoot);
        var manifestPath = Path.Combine(root, "manifest.json");
        if (!File.Exists(manifestPath)) throw new FileNotFoundException("В черновике нет manifest.json", manifestPath);
        CheckRegularFile(manifestPath);
        var info = new FileInfo(manifestPath);
        if (info.Length <= 0 || info.Length > MaxManifestBytes)
            throw new InvalidDataException("Неверный размер manifest.json.");
        var bytes = await File.ReadAllBytesAsync(manifestPath, ct);
        var document = JsonSerializer.Deserialize<OwnerManifest>(bytes)
            ?? throw new InvalidDataException("manifest.json пустой или некорректный.");
        if (document.Schema != 2 || document.Kind != "PROJECT_ECHO_LOCAL_MODS" ||
            document.Channel != "stable" || string.IsNullOrWhiteSpace(document.Version) ||
            document.Retired is null || document.Retired.Count != 0 ||
            document.Files is null || document.Files.Count < 2 || document.Files.Count > 16000 ||
            !document.Files.Any(x => x.Path == "mods/default.txt"))
            throw new InvalidDataException("Пакет не соответствует безопасному production schema=2.");
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        long total = 0;
        var fileRoot = Path.Combine(root, "files");
        if (!Directory.Exists(fileRoot)) throw new DirectoryNotFoundException("В черновике нет папки files.");
        PathSafety.CheckDirectory(fileRoot);
        foreach (var file in document.Files)
        {
            ct.ThrowIfCancellationRequested();
            if (file is null || !seen.Add(PathSafety.ValidatePatchPath(file.Path)))
                throw new InvalidDataException("Повторяющийся или небезопасный путь в манифесте.");
            if (!string.Equals(file.Url, "files/" + file.Path, StringComparison.Ordinal) ||
                file.Size < 0 || file.Size > MaxFileBytes ||
                file.Sha256.Length != 64 || !file.Sha256.All(Uri.IsHexDigit))
                throw new InvalidDataException("Неверные данные файла: " + file.Path);
            if (ProductionPayloadFilter.IgnorePatchPath(file.Path))
                throw new InvalidDataException("В кандидате есть служебный/резервный файл: " + file.Path);
            var absolute = PathSafety.SafeTarget(fileRoot, file.Path);
            if (!File.Exists(absolute)) throw new FileNotFoundException("Нет файла черновика: " + file.Path, absolute);
            CheckRegularFile(absolute);
            CheckParentDirectories(fileRoot, file.Path);
            if (new FileInfo(absolute).Length != file.Size)
                throw new IOException("Размер файла изменился с момента создания черновика: " + file.Path);
            total = checked(total + file.Size);
            if (total > MaxTotalBytes) throw new InvalidDataException("Пакет превышает 8 ГБ.");
            await using var stream = new FileStream(absolute, FileMode.Open, FileAccess.Read, FileShare.Read,
                1024 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan);
            var actual = Convert.ToHexString(await SHA256.HashDataAsync(stream, ct));
            if (!actual.Equals(file.Sha256, StringComparison.OrdinalIgnoreCase))
                throw new CryptographicException("SHA-256 не совпал. Пересканируй моды и создай новый черновик: " + file.Path);
        }
        return (bytes, new DraftDetails(root, document.Files.Count, total, document.Version));
    }

    private static void CheckRegularFile(string path)
    {
        if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
            throw new InvalidDataException("Символическая ссылка запрещена: " + path);
    }

    private static void CheckParentDirectories(string root, string relative)
    {
        var parts = relative.Split('/');
        var current = root;
        foreach (var part in parts.SkipLast(1))
        {
            current = Path.Combine(current, part);
            PathSafety.CheckDirectory(current);
        }
    }

    private static string KeyPath(string projectRoot) =>
        Path.Combine(Path.GetFullPath(projectRoot), "secrets", "release-private.pem");

    private static string PublicPath(string projectRoot) =>
        Path.Combine(Path.GetFullPath(projectRoot), "launcher", "TrustedReleasePublicKey.pem");

    public async Task<DraftDetails> SignAsync(string draftPath, BuilderSettings settings, CancellationToken ct)
    {
        var (bytes, details) = await ValidateAsync(draftPath, settings.OutputRoot, ct);
        var privatePath = KeyPath(settings.ProjectRoot);
        var publicPath = PublicPath(settings.ProjectRoot);
        if (!File.Exists(privatePath))
            throw new FileNotFoundException("Не найден ОРИГИНАЛЬНЫЙ ключ secrets/release-private.pem. Новый ключ создавать нельзя.", privatePath);
        if (!File.Exists(publicPath))
            throw new FileNotFoundException("Не найден публичный ключ launcher/TrustedReleasePublicKey.pem.", publicPath);
        CheckRegularFile(privatePath);
        CheckRegularFile(publicPath);
        using var signingKey = ECDsa.Create();
        signingKey.ImportFromPem(await File.ReadAllTextAsync(privatePath, ct));
        using var verificationKey = ECDsa.Create();
        verificationKey.ImportFromPem(await File.ReadAllTextAsync(publicPath, ct));
        if (!signingKey.ExportSubjectPublicKeyInfo().AsSpan().SequenceEqual(verificationKey.ExportSubjectPublicKeyInfo()))
            throw new CryptographicException("Приватный ключ не соответствует публичному ключу клиента. Подпись отменена.");
        var signature = signingKey.SignData(bytes, HashAlgorithmName.SHA256, DSASignatureFormat.Rfc3279DerSequence);
        if (!verificationKey.VerifyData(bytes, signature, HashAlgorithmName.SHA256, DSASignatureFormat.Rfc3279DerSequence))
            throw new CryptographicException("Самопроверка подписи не прошла.");
        var finalPath = Path.Combine(details.Folder, "manifest.sig");
        if (File.Exists(finalPath)) CheckRegularFile(finalPath);
        var temp = Path.Combine(details.Folder, ".manifest-" + Guid.NewGuid().ToString("N") + ".tmp");
        try
        {
            await File.WriteAllBytesAsync(temp, signature, ct);
            File.Move(temp, finalPath, true);
        }
        finally { if (File.Exists(temp)) File.Delete(temp); }
        return details;
    }

    public async Task<DraftDetails> VerifySignedAsync(string draftPath, BuilderSettings settings, CancellationToken ct)
    {
        var (bytes, details) = await ValidateAsync(draftPath, settings.OutputRoot, ct);
        var sigPath = Path.Combine(details.Folder, "manifest.sig");
        if (!File.Exists(sigPath)) throw new FileNotFoundException("Сначала создай подписанный production-пакет.", sigPath);
        CheckRegularFile(sigPath);
        if (new FileInfo(sigPath).Length is < 16 or > 256)
            throw new InvalidDataException("Некорректный размер подписи.");
        using var key = ECDsa.Create();
        key.ImportFromPem(await File.ReadAllTextAsync(PublicPath(settings.ProjectRoot), ct));
        if (!key.VerifyData(bytes, await File.ReadAllBytesAsync(sigPath, ct),
            HashAlgorithmName.SHA256, DSASignatureFormat.Rfc3279DerSequence))
            throw new CryptographicException("Манифест или подпись изменены после подписания.");
        return details;
    }
}
