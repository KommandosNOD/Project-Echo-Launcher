using System;
using System.IO;
using System.Windows;
using Microsoft.Win32;
using ProjectEcho.Builder.Services;

namespace ProjectEcho.Builder;

public partial class MainWindow
{
    private readonly GitHubProductionBuildService _gitHubAutoBuild = new();
    private CancellationTokenSource? _autoBuildCancellation;

    private void AutoChooseSource_Click(object sender, RoutedEventArgs e)
    {
        var dialog = new OpenFileDialog
        {
            Title = "Выбери ZIP исходников PROJECT ECHO (не EXE и не ZIP из Artifacts)",
            Filter = "Исходники (*.zip)|*.zip", CheckFileExists = true
        };
        if (dialog.ShowDialog(this) == true)
        {
            AutoSourceZipBox.Text = dialog.FileName;
            _settings.ProductionSourceZipPath = dialog.FileName;
            SettingsService.Save(_settings);
        }
    }

    private async void AutoInstallWorkflow_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        if (MessageBox.Show(this,
            "Добавить в MAIN репозитория KommandosNOD/Project-Echo-Launcher ОДИН файл GitHub Actions для сборки Windows?\n\n" +
            "Новые версии лаунчера, сайт, игровые моды и production-манифест останутся без изменений.\n" +
            "Это однократная настройка. GitHub CLI должен быть авторизован как KommandosNOD.",
            "PROJECT ECHO — GitHub сборка", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;
        _busy = true;
        try
        {
            SaveAll();
            AutoBuildStatus.Text = "Подключаем GitHub Actions...";
            using var embedded = typeof(MainWindow).Assembly.GetManifestResourceStream("ProjectEchoAutoBuildWorkflow")
                ?? throw new FileNotFoundException("Workflow не встроен в Builder.");
            using var textReader = new StreamReader(embedded);
            var yaml = await textReader.ReadToEndAsync();
            await _gitHubAutoBuild.InstallWorkflowAsync(yaml, _settings, CancellationToken.None);
            AutoBuildStatus.Text = "Workflow установлен. Теперь выбери ZIP исходников и собери кандидат.";
            Trace("GitHub Actions: безопасный workflow установлен в main. Публикации не было.");
            SetStatus("GitHub Actions подключён");
        }
        catch (InvalidOperationException ex) when (ex.Message.Contains("уже установлен", StringComparison.OrdinalIgnoreCase))
        {
            AutoBuildStatus.Text = "Workflow уже есть в GitHub. Можно запускать сборку.";
        }
        catch (Exception ex)
        {
            AutoBuildStatus.Text = "Не удалось установить workflow: " + ex.Message;
            Trace("GITHUB AUTO INIT: " + ex);
            MessageBox.Show(this, ex.Message, "GitHub Actions", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { _busy = false; }
    }

    private async void AutoBuildAndSign_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        _busy = true;
        _autoBuildCancellation = new CancellationTokenSource();
        try
        {
            SaveAll();
            var path = AutoSourceZipBox.Text.Trim();
            var version = ProdExeVersionBox.Text.Trim();
            GitHubProductionBuildService.CheckSourceZip(path, version);
            if (MessageBox.Show(this,
                "Отправить только выбранный ZIP в ПУБЛИЧНЫЙ GitHub-репозиторий, собрать Windows-кандидат v" + version +
                " и подписать результат локальным ECDSA-ключом?\n\n" +
                "Релиз игрокам НЕ публикуется. Ключи, сайт и моды не загружаются.",
                "PROJECT ECHO — собрать клиент", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
                return;
            _settings.ProductionSourceZipPath = path;
            _settings.ProductionExeVersion = version;
            SettingsService.Save(_settings);
            SetStatus("GitHub Windows: проверка и сборка...");
            void Progress(string message)
            {
                Dispatcher.BeginInvoke(() =>
                {
                    AutoBuildStatus.Text = message;
                    Trace("GITHUB BUILD: " + message);
                });
            }
            var result = await _gitHubAutoBuild.BuildAsync(path, version, _settings,
                Progress, _autoBuildCancellation.Token);
            ResetReleaseChecklist();
            ProdExePathBox.Text = result.ExePath;
            _settings.ProductionExePath = result.ExePath;
            SettingsService.Save(_settings);
            AutoBuildStatus.Text = "Сборка GitHub успешна. Локальная ECDSA-подпись...";
            var signed = await _productionCandidates.CreateAsync(result.ExePath, version, _settings,
                _autoBuildCancellation.Token);
            await _productionCandidates.VerifyAsync(signed.Directory, _settings, _autoBuildCancellation.Token);
            ProdCandidatePathBox.Text = signed.Directory;
            _settings.ProductionExeCandidatePath = signed.Directory;
            SettingsService.Save(_settings);
            ProdExeStatus.Text = $"ПРОВЕРЕНО ECDSA + SHA-256: v{signed.Version}; {signed.Bytes:N0} байт; {signed.Sha256}";
            AutoBuildStatus.Text = "ГОТОВО: собран Windows EXE v" + version + ", SHA-256 проверен, кандидат подписан.\n" +
                                   result.RunUrl + "\nПроверь EXE на Windows перед публикацией.";
            SetStatus("GitHub EXE собран и подписан: v" + version + " — ещё НЕ опубликован");
        }
        catch (OperationCanceledException)
        {
            AutoBuildStatus.Text = "Ожидание отменено. Удалённая сборка GitHub могла продолжить работу. Production НЕ опубликован.";
            SetStatus("Ожидание GitHub Actions отменено");
        }
        catch (Exception ex)
        {
            AutoBuildStatus.Text = "Сборка/подпись не завершена: " + ex.Message;
            Trace("ОШИБКА GITHUB BUILD: " + ex);
            MessageBox.Show(this, ex.Message + "\n\nПроверь журнал и GitHub Actions. Production не публиковался.",
                "PROJECT ECHO — GitHub сборка", MessageBoxButton.OK, MessageBoxImage.Error);
            SetStatus("GitHub EXE: проверка или сборка не завершена");
        }
        finally
        {
            _autoBuildCancellation?.Dispose();
            _autoBuildCancellation = null;
            _busy = false;
        }
    }

    private void AutoCancelBuild_Click(object sender, RoutedEventArgs e)
    {
        _autoBuildCancellation?.Cancel();
        if (_autoBuildCancellation is not null)
            AutoBuildStatus.Text = "Отменяем ожидание. GitHub Actions может продолжить сборку — публикации не будет.";
    }
}
