using System;
using System.IO;
using System.Windows;
using Microsoft.Win32;
using ProjectEcho.Builder.Services;

namespace ProjectEcho.Builder;

public partial class MainWindow
{
    private readonly ProductionExeCandidateService _productionCandidates=new();
    private readonly ProductionExeReleaseService _productionPublisher=new();
    private void ProdChooseExe_Click(object sender,RoutedEventArgs e)
    {
        var dialog=new OpenFileDialog { Title="Выбери готовый production EXE из GitHub Actions",
            Filter="ProjectEchoLauncher.exe|ProjectEchoLauncher.exe",CheckFileExists=true };
        if(dialog.ShowDialog(this)==true) { ProdExePathBox.Text=dialog.FileName; ResetReleaseChecklist(); }
    }
    private async void ProdCreateCandidate_Click(object sender,RoutedEventArgs e)
    {
        if(_busy)return;
        _busy=true;
        try
        {
            SaveAll();
            _settings.ProductionExePath=ProdExePathBox.Text.Trim();
            _settings.ProductionExeVersion=ProdExeVersionBox.Text.Trim();
            ProdExeStatus.Text="Проверяем EXE, подписываем ECDSA...";
            var r=await _productionCandidates.CreateAsync(_settings.ProductionExePath,_settings.ProductionExeVersion,_settings,CancellationToken.None);
            ProdCandidatePathBox.Text=r.Directory;
            _settings.ProductionExeCandidatePath=r.Directory;
            SettingsService.Save(_settings);
            ProdExeStatus.Text=$"ПОДПИСАНО: v{r.Version}, {r.Bytes:N0} байт; SHA-256 {r.Sha256}";
            Trace("Подписан production EXE v"+r.Version+". GitHub не изменён.");
            SetStatus("Кандидат production EXE подписан локально");
        }
        catch(Exception ex){ProdExeStatus.Text="Ошибка: "+ex.Message;Trace("PROD EXE: "+ex);MessageBox.Show(this,ex.Message,"Production EXE",MessageBoxButton.OK,MessageBoxImage.Error);}
        finally{_busy=false;}
    }
    private async void ProdVerifyCandidate_Click(object sender,RoutedEventArgs e)
    {
        if(_busy)return;
        _busy=true;
        try
        {
            SaveAll();
            var r=await _productionCandidates.VerifyAsync(ProdCandidatePathBox.Text,_settings,CancellationToken.None);
            _settings.ProductionExeCandidatePath=r.Directory;
            SettingsService.Save(_settings);
            ProdExeStatus.Text=$"ПРОВЕРЕНО ECDSA + SHA-256: v{r.Version}; {r.Bytes:N0} байт; {r.Sha256}";
            SetStatus("Production EXE проверен, GitHub без изменений");
        }
        catch(Exception ex){ProdExeStatus.Text="Ошибка: "+ex.Message;MessageBox.Show(this,ex.Message,"Проверка production EXE",MessageBoxButton.OK,MessageBoxImage.Error);}
        finally{_busy=false;}
    }
    private async void ProdPublish_Click(object sender,RoutedEventArgs e)
    {
        if(_busy)return;
        if (!ReleaseChecklistComplete())
        {
            MessageBox.Show(this,"Перед публикацией проверь EXE на Windows и отметь ВСЕ пункты контроля релиза.",
                "Контроль production EXE",MessageBoxButton.OK,MessageBoxImage.Warning);
            return;
        }
        if(ProdPublishConfirmationBox.Text.Trim()!="RELEASE-PROD-EXE")
        {MessageBox.Show(this,"Для публикации рабочего EXE введи RELEASE-PROD-EXE.","Подтверждение",MessageBoxButton.OK,MessageBoxImage.Warning);return;}
        if(MessageBox.Show(this,"ПУБЛИКАЦИЯ ДЛЯ ИГРОКОВ!\n\nБудет создан GitHub Release и подписанный production-канал. Клиенты со старой версией начнут предлагать обновление.\n\nТы проверил этот EXE на Windows?","PROJECT ECHO — рабочий выпуск",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
        _busy=true;
        try
        {
            SaveAll();
            ProdPublishStatus.Text="Публикация GitHub Release и подписанного EXE-канала...";
            SetStatus("PRODUCTION: публикация EXE...");
            var r=await _productionPublisher.PublishAsync(ProdCandidatePathBox.Text,_settings,Trace,CancellationToken.None);
            ProdPublishStatus.Text=$"ОПУБЛИКОВАНО: {r.Tag}\n{r.ReleaseUrl}\n{r.ManifestUrl}";
            ProdPublishConfirmationBox.Clear();
            ResetReleaseChecklist();
            SetStatus("Production EXE опубликован: "+r.Tag);
        }
        catch(Exception ex)
        {
            ProdPublishStatus.Text="Публикация не завершена. Подробности в журнале: "+ex.Message;
            Trace("ОШИБКА PRODUCTION EXE: "+ex);
            MessageBox.Show(this,"Остановлено: "+ex.Message+"\n\nНе повторяй публикацию без проверки GitHub Release и журнала Builder.","Production EXE",MessageBoxButton.OK,MessageBoxImage.Error);
            SetStatus("Ошибка публикации production EXE");
        }
        finally{_busy=false;}
    }
}
