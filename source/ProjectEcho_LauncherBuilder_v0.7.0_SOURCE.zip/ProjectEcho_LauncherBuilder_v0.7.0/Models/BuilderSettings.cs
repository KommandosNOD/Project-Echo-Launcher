using System.IO;
using System.Text.Json.Serialization;

namespace ProjectEcho.Builder.Models;

public sealed class BuilderSettings
{
    public string ModsRoot { get; set; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Zomboid", "mods");
    public string ProjectRoot { get; set; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "pzportal2");
    public string OutputRoot { get; set; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "ProjectEchoBuilderOutput");
    public string ClientVersion { get; set; } = "0.4.0";
    public string StagingClientSourceRoot { get; set; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory), "PROJECT_ECHO_STAGING_CLIENT_v0.3.0");
    public string StagingLauncherVersion { get; set; } = "0.4.4";
    public string LastLauncherCandidatePath { get; set; } = "";
    public string ProductionExePath { get; set; } = "";
    public string ProductionSourceZipPath { get; set; } = "";
    public string ProductionExeVersion { get; set; } = "0.8.1";
    public string ProductionExeCandidatePath { get; set; } = "";
    public List<string> AdditionalFolders { get; set; } = new();
    public List<string> ExcludedAutoFolders { get; set; } = new();
    public bool AutoRescan { get; set; } = true;
    public string LastDraftPath { get; set; } = "";
    public string LastStagingCandidatePath { get; set; } = "";
    // The last successfully signed local TEST manifest is the diff baseline for subsequent tests.
    public string LastSignedTestDraftPath { get; set; } = "";
}

public sealed record ManagedFile(string Path, string FullPath, long Size, string Sha256);

public sealed class ManagedMod : System.ComponentModel.INotifyPropertyChanged
{
    private bool _selected;
    public string Name { get; init; } = "";
    public bool Automatic { get; init; }
    public int FileCount { get; set; }
    public long Bytes { get; set; }
    public string Status { get; set; } = "";
    public bool IsSelected
    {
        get => _selected;
        set
        {
            if (value == _selected) return;
            _selected = value;
            PropertyChanged?.Invoke(this, new System.ComponentModel.PropertyChangedEventArgs(nameof(IsSelected)));
        }
    }
    public event System.ComponentModel.PropertyChangedEventHandler? PropertyChanged;
}

public sealed record InventoryResult(List<ManagedFile> Files, List<ManagedMod> Mods, string ModsRoot);

public sealed record FileChange(string Path, string Type, long Size, string Sha256);

public sealed class OwnerManifest
{
    [JsonPropertyName("schema")] public int Schema { get; set; } = 2;
    [JsonPropertyName("kind")] public string Kind { get; set; } = "PROJECT_ECHO_LOCAL_MODS";
    [JsonPropertyName("channel")] public string Channel { get; set; } = "stable";
    [JsonPropertyName("version")] public string Version { get; set; } = "";
    [JsonPropertyName("createdUtc")] public DateTimeOffset CreatedUtc { get; set; } = DateTimeOffset.UtcNow;
    [JsonPropertyName("files")] public List<ManifestFile> Files { get; set; } = new();
    [JsonPropertyName("retired")] public List<ManifestFile> Retired { get; set; } = new();
}

public sealed class ManifestFile
{
    [JsonPropertyName("path")] public string Path { get; set; } = "";
    [JsonPropertyName("size")] public long Size { get; set; }
    [JsonPropertyName("sha256")] public string Sha256 { get; set; } = "";
    [JsonPropertyName("url")] public string Url { get; set; } = "";
}
