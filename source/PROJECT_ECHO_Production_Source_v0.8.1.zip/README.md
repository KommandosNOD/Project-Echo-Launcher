# PROJECT ECHO Launcher v0.8.1 — Windows production source

Версия 0.8.1 использует тот же подписанный GitHub-модпак и выделенный updater, что 0.8.0.
Изменения: корректный заголовок окна из версии сборки; уточнено сообщение об ошибке production-GitHub.

**GitHub Actions:** положить zip в source/PROJECT_ECHO_Production_Source_v0.8.1.zip и в
.github/workflows/build-project-echo.yml заменить имя исходного ZIP v0.8.0 на v0.8.1,
имя артефакта на PROJECT-ECHO-Production-0.8.1-RC.

**Важное:** первая сборка v0.8.1 является кандидатом. Сначала проверить EXE на Windows;
только затем подписывать его через Launcher Builder EXE PRODUCTION и публиковать.

Ни приватный ECDSA-ключ, ни пароль GitHub в ZIP не включены.
