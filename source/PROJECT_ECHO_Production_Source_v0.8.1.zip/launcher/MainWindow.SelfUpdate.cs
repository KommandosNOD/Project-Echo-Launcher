// PROJECT_ECHO_SELFUPDATE_STEP17
using System;
using System.Threading.Tasks;
using System.Windows;

namespace PZLauncher;

public partial class MainWindow
{
#if ECHO_RELEASE_CANDIDATE
    // Do not fetch production/latest or replace an RC executable before the
    // owner-signed production launcher channel has been released.
    private Task CheckSelfUpdateAtStartupAsync() => Task.CompletedTask;
#else
    private async Task CheckSelfUpdateAtStartupAsync()
    {
        try
        {
            using var autoUpdater = new LauncherSelfUpdateService();
            var update = await autoUpdater.CheckAsync();
            if (update is null || !IsLoaded) return;

            StatusText.Text = $"Новая версия лаунчера {update.Tag}: загрузка…";
            var progress = new Progress<double>(value =>
            {
                if (IsLoaded) StatusText.Text = $"Загрузка лаунчера {update.Tag}: {value:0}%";
            });
            var prepared = await autoUpdater.DownloadVerifiedAsync(update, progress);
            if (!IsLoaded) return;
            StatusText.Text = $"Лаунчер {update.Tag} загружен и проверен (SHA-256).";
            var answer = MessageBox.Show(this,
                $"Доступна новая версия PROJECT ECHO Launcher {update.Tag}.\n\n" +
                "Обновление уже загружено с GitHub и проверено по SHA-256.\n" +
                "Перезапустить лаунчер и установить обновление сейчас?\n\n" +
                "Игра, моды и сохранения не изменятся.",
                "PROJECT ECHO — обновление лаунчера", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (answer != MessageBoxResult.Yes) return;

            await LauncherSelfUpdateService.StartInstallerAsync(prepared);
            Application.Current.Shutdown();
        }
        catch (Exception ex)
        {
            if (IsLoaded) StatusText.Text = "EXE-обновление не выполнено: " + ex.Message;
            // GitHub availability must NEVER prevent play or signed mod patch verification.
            try
            {
#if ECHO_STAGING_CLIENT
                var logDir = System.IO.Path.Combine(SettingsStore.StateRoot, "launcher-selfupdate");
#else
                var logDir = System.IO.Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "PZCommunityLauncher", "launcher-selfupdate");
#endif
                System.IO.Directory.CreateDirectory(logDir);
                System.IO.File.WriteAllText(System.IO.Path.Combine(logDir, "check-error.log"), ex.ToString());
            }
            catch { }
        }
    }
#endif
}
