using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Threading;
using Microsoft.Win32;
using ProjectEcho.Builder.Models;
using ProjectEcho.Builder.Services;

namespace ProjectEcho.Builder;

public partial class MainWindow : Window
{
    public ObservableCollection<ManagedMod> Mods { get; } = new();
    public ObservableCollection<FileChange> Changes { get; } = new();
    public ObservableCollection<StagingDiffRow> StagingDiffRows { get; } = new();
    public ObservableCollection<ProductionModDiffRow> ProductionModDiffRows { get; } = new();
    private readonly ModInventoryService _inventory = new();
    private readonly StageService _stage = new();
    private readonly SmokeTestService _smoke = new();
    private readonly GitHubStagingService _stagingGithub = new();
    private readonly GitHubStagingDiffService _stagingDiff = new();
    private readonly ClientBuildService _clientBuild = new();
    private readonly LauncherCandidateService _launcherCandidate = new();
    private readonly LauncherGitHubReleaseService _launcherRelease = new();
    private readonly LocalDraftSigningService _draftSigner = new();
    private readonly LocalDraftServer _localServer;
    private readonly DispatcherTimer _debouncer;
    private readonly BuilderSettings _settings;
    private InventoryResult? _latest;
    private FileSystemWatcher? _watcher;
    private bool _busy;
    private bool _dirty;

    public MainWindow()
    {
        InitializeComponent();
        DataContext = this;
        _settings = SettingsService.Load();
        _localServer = new LocalDraftServer(Trace);
        DraftPathBox.Text = _settings.LastDraftPath;
        StagingCandidateBox.Text = _settings.LastStagingCandidatePath;
        UpdateBaselineLabel();
        ModsRootBox.Text = _settings.ModsRoot;
        ProjectRootBox.Text = _settings.ProjectRoot;
        OutputRootBox.Text = _settings.OutputRoot;
        ClientVersionBox.Text = _settings.ClientVersion;
        StagingClientSourceBox.Text = _settings.StagingClientSourceRoot;
        StagingLauncherVersionBox.Text = _settings.StagingLauncherVersion;
        LauncherCandidateBox.Text = _settings.LastLauncherCandidatePath;
        ProdExePathBox.Text = _settings.ProductionExePath;
        AutoSourceZipBox.Text = _settings.ProductionSourceZipPath;
        ProdExeVersionBox.Text = _settings.ProductionExeVersion;
        ProdCandidatePathBox.Text = _settings.ProductionExeCandidatePath;
        ModProdCandidateBox.Text = _settings.ProductionModsCandidatePath;
        AutoScanCheck.IsChecked = _settings.AutoRescan;
        _debouncer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(2) };
        _debouncer.Tick += async (_, _) =>
        {
            _debouncer.Stop();
            if (_busy) { _dirty = true; return; }
            if (_settings.AutoRescan) await ScanAsync();
        };
    }

    private async void Window_Loaded(object sender, RoutedEventArgs e)
    {
        StartupDiagnostics.Write("Window.Loaded — beginning initial scan");
        try
        {
            try { StartWatcher(); }
            catch (Exception ex)
            {
                // The Windows file watcher is optional: scanning remains usable without it.
                StartupDiagnostics.Write("FileSystemWatcher could not start", ex);
                Trace("ВНИМАНИЕ: автоматическое наблюдение недоступно: " + ex.Message);
            }
            await ScanAsync();
            StartupDiagnostics.Write("Window.Loaded — initial scan completed");
        }
        catch (Exception ex)
        {
            StartupDiagnostics.Write("Window.Loaded failed", ex);
            SetStatus("Ошибка при запуске сканирования");
            Trace("ОШИБКА ПРИ ЗАПУСКЕ: " + ex);
            MessageBox.Show(this, "Ошибка начального сканирования: " + ex.Message +
                "\n\nЖурнал: " + StartupDiagnostics.LogPath, "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void Window_Closing(object? sender, System.ComponentModel.CancelEventArgs e)
    {
        _autoBuildCancellation?.Cancel();
        _watcher?.Dispose();
        _localServer.Dispose();
        _debouncer.Stop();
    }

    private void Trace(string text)
    {
        if (!Dispatcher.CheckAccess()) { Dispatcher.BeginInvoke(() => Trace(text)); return; }
        LogBox.AppendText($"[{DateTime.Now:HH:mm:ss}] {text}\r\n");
        if (LogBox.Text.Length > 500000) LogBox.Text = LogBox.Text[^300000..];
        LogBox.ScrollToEnd();
    }

    private void UpdateBaselineLabel()
    {
        BaselineText.Text = string.IsNullOrWhiteSpace(_settings.LastSignedTestDraftPath)
            ? "Эталон: старый манифест сайта (если доступен). Сначала подпиши локальный пакет."
            : "Эталон: последний подписанный локальный тест — " + Path.GetFileName(_settings.LastSignedTestDraftPath);
    }

    private void SetStatus(string title)
    {
        StatusText.Text = title;
        FooterText.Text = "Статус: " + title;
    }

    private void ReadInputs()
    {
        if (string.IsNullOrWhiteSpace(ModsRootBox.Text) || string.IsNullOrWhiteSpace(ProjectRootBox.Text) ||
            string.IsNullOrWhiteSpace(OutputRootBox.Text))
            throw new InvalidDataException("Пути в настройках не должны быть пустыми.");
        _settings.ModsRoot = Path.GetFullPath(Environment.ExpandEnvironmentVariables(ModsRootBox.Text.Trim().Trim('"')));
        _settings.ProjectRoot = Path.GetFullPath(Environment.ExpandEnvironmentVariables(ProjectRootBox.Text.Trim().Trim('"')));
        _settings.OutputRoot = Path.GetFullPath(Environment.ExpandEnvironmentVariables(OutputRootBox.Text.Trim().Trim('"')));
        _settings.ClientVersion = ClientVersionBox.Text.Trim();
        _settings.StagingClientSourceRoot = StagingClientSourceBox.Text.Trim();
        _settings.StagingLauncherVersion = StagingLauncherVersionBox.Text.Trim();
        var mods = _settings.ModsRoot.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        var output = _settings.OutputRoot.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        if (output.StartsWith(mods, StringComparison.OrdinalIgnoreCase) ||
            output.Equals(mods, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Папка результатов не должна находиться внутри папки mods.");
        _settings.AutoRescan = AutoScanCheck.IsChecked == true;
    }

    private void SaveSelections()
    {
        if (_latest is null) return;
        // The auto-discovered folders may be excluded explicitly, but additions are selected by default.
        _settings.ExcludedAutoFolders = Mods.Where(m => m.Automatic && !m.IsSelected).Select(m => m.Name).ToList();
        // Allow disabling explicitly added non-prefixed mod folders, too.
        foreach (var item in Mods.Where(m => !m.Automatic && m.Status != "ПАПКА НЕ НАЙДЕНА"))
        {
            if (!item.IsSelected && !_settings.ExcludedAutoFolders.Contains(item.Name, StringComparer.OrdinalIgnoreCase))
                _settings.ExcludedAutoFolders.Add(item.Name);
        }
    }

    private void SaveAll()
    {
        SaveSelections();
        ReadInputs();
        SettingsService.Save(_settings);
    }

    private async Task ScanAsync()
    {
        if (_busy) { _dirty = true; return; }
        _busy = true;
        try
        {
            SaveAll();
            SetStatus("Сканирование SHA-256...");
            Trace("Проверка источника: " + _settings.ModsRoot);
            var result = await _inventory.ScanAsync(_settings, Trace);
            _latest = result;
            Mods.Clear();
            foreach (var mod in result.Mods) Mods.Add(mod);
            var preview = _stage.GetChanges(result, _settings);
            PopulateChanges(preview);
            var active = result.Mods.Count(m => m.IsSelected);
            SummaryText.Text = $"Выбрано модов: {active} / обнаружено: {result.Mods.Count}. Файлов: {result.Files.Count}. Новых/изменённых: {preview.Changed.Count}, отсутствуют в выбранном пакете: {preview.Retired.Count}.";
            ChangedText.Text = $"Изменения по сравнению с эталоном: {preview.Changed.Count} новых/изменённых, {preview.Retired.Count} не вошедших в пакет. Эталон: {preview.ReferenceLabel}.";
            SetStatus("Сканирование завершено");
            Trace($"Обнаружено {result.Mods.Count} локальных папок, {result.Files.Count} файлов. Новых/изменённых: {preview.Changed.Count}");
        }
        catch (Exception ex)
        {
            SetStatus("Ошибка проверки");
            Trace("ОШИБКА: " + ex.Message);
            MessageBox.Show(this, ex.Message, "PROJECT ECHO: ошибка сканирования", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        finally
        {
            _busy = false;
            if (_dirty) { _dirty = false; _debouncer.Stop(); _debouncer.Start(); }
        }
    }

    private void PopulateChanges(StageService.ChangeSummary result)
    {
        Changes.Clear();
        foreach (var item in result.Changed) Changes.Add(item);
        foreach (var item in result.Retired) Changes.Add(item);
    }

    private async void Refresh_Click(object sender, RoutedEventArgs e) => await ScanAsync();

    private void SaveSelection_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            ModsGrid.CommitEdit(System.Windows.Controls.DataGridEditingUnit.Cell, true);
            ModsGrid.CommitEdit(System.Windows.Controls.DataGridEditingUnit.Row, true);
            SaveAll();
            if (_latest != null)
            {
                var preview = _stage.GetChanges(_latest, _settings);
                PopulateChanges(preview);
                ChangedText.Text = $"Новых/изменённых: {preview.Changed.Count}, не вошедших в пакет: {preview.Retired.Count}. Сравнение: {preview.ReferenceLabel}.";
            }
            Trace("Выбор локальных модов сохранён.");
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Не удалось сохранить", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private async void AddFolder_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            SaveAll();
            var name = PathSafety.CheckFolderName(ExtraFolderName.Text.Trim());
            var path = Path.Combine(_settings.ModsRoot, name);
            if (!Directory.Exists(path)) throw new DirectoryNotFoundException("Нет папки: " + path);
            if (!_settings.AdditionalFolders.Contains(name, StringComparer.OrdinalIgnoreCase))
                _settings.AdditionalFolders.Add(name);
            SettingsService.Save(_settings);
            ExtraFolderName.Clear();
            Trace("Добавлена выбранная папка: " + name);
            await ScanAsync();
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Добавление мода", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private async void Stage_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        _busy = true;
        try
        {
            ModsGrid.CommitEdit(System.Windows.Controls.DataGridEditingUnit.Cell, true);
            ModsGrid.CommitEdit(System.Windows.Controls.DataGridEditingUnit.Row, true);
            SaveAll();
            SetStatus("Повторное сканирование перед подготовкой пакета...");
            // Never use stale hashes from before an edit in the mod source.
            var latest = await _inventory.ScanAsync(_settings, Trace);
            var changes = _stage.GetChanges(latest, _settings);
            PopulateChanges(changes);
            if (changes.Retired.Count > 0)
            {
                var review = new RetiredReviewDialog(changes.Retired) { Owner = this };
                if (review.ShowDialog() != true) { SetStatus("Подготовка отменена"); return; }
                Trace($"Проверены {changes.Retired.Count} кандидатов из старого манифеста. В черновик операции удаления не добавляются.");
            }
            SetStatus("Создание неподписанного пакета...");
            var folder = await _stage.StageAsync(latest, _settings, Trace, CancellationToken.None);
            _latest = latest;
            _settings.LastDraftPath = folder;
            DraftPathBox.Text = folder;
            SettingsService.Save(_settings);
            Trace("ЧЕРНОВИК ГОТОВ: " + folder);
            SetStatus("Черновик готов — НЕ публиковать");
            MessageBox.Show(this, "Подготовлен безопасный ЧЕРНОВИК обновления:\n" + folder +
                "\n\nВ нём все выбранные моды и default.txt. Это НЕ подписанный релиз; пока нельзя выкладывать для игроков.",
                "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { SetStatus("Ошибка подготовки пакета"); Trace("ОШИБКА: " + ex); MessageBox.Show(this, ex.Message, "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Error); }
        finally { _busy = false; if (_dirty) { _dirty = false; _debouncer.Stop(); _debouncer.Start(); } }
    }

    private async void CreateSmokeTest_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        if (_localServer.IsRunning)
        {
            MessageBox.Show(this, "Останови тестовый сервер перед подготовкой следующего пакета.",
                "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        _busy = true;
        try
        {
            ModsGrid.CommitEdit(System.Windows.Controls.DataGridEditingUnit.Cell, true);
            ModsGrid.CommitEdit(System.Windows.Controls.DataGridEditingUnit.Row, true);
            SaveAll();
            SetStatus("Создаётся изолированный источник: новый мод + изменённый default.txt...");
            var result = await _smoke.CreateAsync(_settings, Trace, CancellationToken.None);
            _settings.LastDraftPath = result.DraftPath;
            DraftPathBox.Text = result.DraftPath;
            SettingsService.Save(_settings);
            Trace("ИЗОЛИРОВАННЫЙ ТЕСТОВЫЙ ИСТОЧНИК: " + result.SourcePath);
            Trace("ТЕСТОВЫЕ ИЗМЕНЕНИЯ: " + string.Join(", ", result.ChangedPaths));
            SetStatus("Черновик с новым модом и default.txt подготовлен");
            MessageBox.Show(this,
                "Создан черновик с НОВЫМ тестовым модом и изменённым default.txt.\n\n" +
                "Файлы оригинальных модов не менялись. Скопирован: " + result.BaseMod + "\n" +
                "Тестовый источник: " + result.SourcePath + "\n" +
                "Черновик: " + result.DraftPath + "\n\n" +
                "Дальше: «Подписать для теста» → «Запустить сервер» → открыть TEST-лаунчер.\n" +
                "Используй ТОЛЬКО отдельный ProjectEchoLauncher_TEST.exe!",
                "PROJECT ECHO — тест новых файлов", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            SetStatus("Не удалось создать тестовый пакет");
            Trace("ОШИБКА ТЕСТА: " + ex);
            MessageBox.Show(this, ex.Message, "PROJECT ECHO — тестовый пакет", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { _busy = false; }
    }

    private async void ResetBaseline_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        if (MessageBox.Show(this,
            "Сбросить эталон локальных тестов и вернуться к сравнению со старым манифестом сайта?\n\n" +
            "Файлы и подписанные черновики удалены НЕ будут.",
            "PROJECT ECHO — сброс эталона", MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
            return;
        _settings.LastSignedTestDraftPath = "";
        SaveAll();
        UpdateBaselineLabel();
        await ScanAsync();
    }

    private void ChooseDraft_Click(object sender, RoutedEventArgs e) => ChooseFolder(DraftPathBox);

    private async void SignDraft_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        if (_localServer.IsRunning)
        {
            MessageBox.Show(this, "Останови тестовый сервер перед переподписью черновика.",
                "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        _busy = true;
        try
        {
            SaveAll();
            SetStatus("Проверка всех файлов черновика и ECDSA-подпись...");
            var result = await _draftSigner.SignAsync(DraftPathBox.Text, _settings, CancellationToken.None);
            _settings.LastDraftPath = result.Folder;
            _settings.LastSignedTestDraftPath = result.Folder;
            SettingsService.Save(_settings);
            UpdateBaselineLabel();
            SetStatus("Тестовый черновик подписан");
            Trace($"ПОДПИСАН ЛОКАЛЬНЫЙ ЧЕРНОВИК: {result.FileCount} файлов, {result.Bytes} байт, версия {result.Version}");
            MessageBox.Show(this, "Подпись manifest.sig создана и проверена.\n\n" +
                $"Файлов: {result.FileCount}; байт: {result.Bytes}\n" +
                "Теперь запусти сервер на вкладке «ЛОКАЛЬНЫЙ ТЕСТ».\n\n" +
                "ВАЖНО: НЕ публикуй этот тестовый пакет в интернет.",
                "PROJECT ECHO — ЛОКАЛЬНАЯ ПОДПИСЬ", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            SetStatus("Ошибка подписи");
            Trace("ПОДПИСЬ ОТМЕНЕНА: " + ex.Message);
            MessageBox.Show(this, ex.Message, "Не удалось подписать тестовый пакет", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { _busy = false; }
    }

    private async void StartLocalServer_Click(object sender, RoutedEventArgs e)
    {
        if (_busy || _localServer.IsRunning) return;
        _busy = true;
        try
        {
            SaveAll();
            SetStatus("Проверка подписи и хешей перед локальной раздачей...");
            var details = await _draftSigner.VerifySignedAsync(DraftPathBox.Text, _settings, CancellationToken.None);
            _localServer.Start(details.Folder);
            _settings.LastDraftPath = details.Folder;
            SettingsService.Save(_settings);
            LocalServerStatusText.Text = $"Запущен · {details.FileCount} файлов · {details.Version}";
            SetStatus("Тестовый сервер запущен на 127.0.0.1:8765");
        }
        catch (Exception ex)
        {
            SetStatus("Не удалось запустить сервер");
            Trace("ОШИБКА ЛОКАЛЬНОГО СЕРВЕРА: " + ex.Message);
            MessageBox.Show(this, ex.Message + "\n\nЕсли порт 8765 занят, останови старый Node.js LocalDraftServer.js (Ctrl+C).",
                "PROJECT ECHO — тестовый сервер", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { _busy = false; }
    }

    private void StopLocalServer_Click(object sender, RoutedEventArgs e)
    {
        _localServer.Stop();
        LocalServerStatusText.Text = "Сервер остановлен";
        SetStatus("Локальный тестовый сервер остановлен");
    }

    private void OpenDraftFolder_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var dir = Path.GetFullPath(DraftPathBox.Text.Trim().Trim('"'));
            if (!Directory.Exists(dir)) throw new DirectoryNotFoundException("Папка черновика не существует.");
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = "explorer.exe", ArgumentList = { dir }, UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private async void PrepareStagingCandidate_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        _busy = true;
        try
        {
            ModsGrid.CommitEdit(System.Windows.Controls.DataGridEditingUnit.Cell, true);
            ModsGrid.CommitEdit(System.Windows.Controls.DataGridEditingUnit.Row, true);
            SaveAll();
            SetStatus("Создание полного подписанного пакета из рабочей папки...");
            var candidate = await _stagingGithub.PrepareAsync(_settings, Trace, CancellationToken.None);
            _settings.LastStagingCandidatePath = candidate.Folder;
            SettingsService.Save(_settings);
            StagingCandidateBox.Text = candidate.Folder;
            StagingDiffRows.Clear();
            StagingDiffSummaryText.Text = "Кандидат подготовлен. Для расчёта изменений нажми «Сравнить с GitHub TEST».";
            StagingPreflightText.Text = $"Подписан: {candidate.Count} файлов; {candidate.Bytes} байт; версия {candidate.Version}";
            SetStatus("Кандидат GitHub TEST готов, в интернет не загружен");
            Trace("Кандидат создан: " + candidate.Folder);
            MessageBox.Show(this, "Готов подписанный пакет для отдельной тестовой ветки.\n\n" +
                "Проверь состав выбранных модов и нажми «Проверить подпись, исходники и лимиты».\n" +
                "Рабочие файлы игры и сервер не менялись.", "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            SetStatus("Ошибка подготовки кандидата");
            Trace("ОШИБКА КАНДИДАТА: " + ex);
            MessageBox.Show(this, ex.Message, "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { _busy = false; }
    }

    private void ChooseCandidate_Click(object sender, RoutedEventArgs e) => ChooseFolder(StagingCandidateBox);

    private async void PreflightStaging_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        _busy = true;
        try
        {
            SaveAll();
            var result = await _stagingGithub.PreflightAsync(StagingCandidateBox.Text, _settings, CancellationToken.None);
            _settings.LastStagingCandidatePath = result.Folder;
            SettingsService.Save(_settings);
            StagingPreflightText.Text = $"ПРОВЕРЕНО: {result.Count} файлов / {result.Bytes} байт; подпись и SHA-256 совпадают";
            SetStatus("Кандидат проверен, GitHub пока не изменён");
        }
        catch (Exception ex)
        {
            StagingPreflightText.Text = "ПРОВЕРКА НЕ ПРОШЛА: " + ex.Message;
            Trace("ОШИБКА PREFLIGHT: " + ex);
            MessageBox.Show(this, ex.Message, "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { _busy = false; }
    }

    private async void CompareGitHubTest_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        _busy = true;
        try
        {
            SaveAll();
            SetStatus("GitHub TEST: проверка подписи и сравнение полного пакета...");
            // Never compare a stale, locally modified or incomplete candidate.
            await _stagingGithub.PreflightAsync(StagingCandidateBox.Text, _settings, CancellationToken.None);
            var report = await _stagingDiff.CompareAsync(StagingCandidateBox.Text, _settings, CancellationToken.None);
            StagingDiffRows.Clear();
            foreach (var row in report.Rows) StagingDiffRows.Add(row);
            StagingDiffSummaryText.Text =
                $"Эталон: {report.BaselineVersion} → кандидат {report.CandidateVersion}\n" +
                $"Новых: {report.Added} | Изменённых: {report.Modified} | Уже совпадают: {report.Same} | Не включены: {report.NotSelected}\n" +
                $"Ожидаемая загрузка новыми/изменёнными файлами: {report.ClientDownloadBytes:N0} байт " +
                $"из {report.CandidateBytes:N0} байт полного пакета. " +
                "НЕ В ПАКЕТЕ — не команда удаления.";
            Trace($"GITHUB TEST DIFF: +{report.Added}, ~{report.Modified}, ={report.Same}, " +
                $"не включены {report.NotSelected}; передать ~{report.ClientDownloadBytes} байт.");
            SetStatus("Сравнение с подписанным GitHub TEST завершено");
        }
        catch (Exception ex)
        {
            StagingDiffRows.Clear();
            StagingDiffSummaryText.Text = "СРАВНЕНИЕ НЕ ПРОШЛО: " + ex.Message;
            SetStatus("GitHub TEST: ошибка сравнения");
            Trace("GITHUB TEST DIFF ОШИБКА: " + ex);
            MessageBox.Show(this, ex.Message, "PROJECT ECHO — сравнение GitHub TEST", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { _busy = false; }
    }

    private async void PublishGithubStaging_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        if (!StagingConfirmationBox.Text.Equals("STAGING", StringComparison.Ordinal))
        {
            MessageBox.Show(this, "Для публикации в тестовую ветку введи STAGING (заглавными буквами).", "PROJECT ECHO",
                MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        if (MessageBox.Show(this,
            "Публикуем подписанный пакет в публичную тестовую ветку project-echo-schema2-staging на GitHub?\n\n" +
            "Боевой main / stable / Cloudflare НЕ меняются. Публичная ветка может быть прочитана другими пользователями GitHub.",
            "PROJECT ECHO — ПОДТВЕРЖДЕНИЕ", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes)
            return;
        _busy = true;
        try
        {
            SaveAll();
            SetStatus("GitHub TEST: повторная проверка удалённого манифеста перед публикацией...");
            await _stagingGithub.PreflightAsync(StagingCandidateBox.Text, _settings, CancellationToken.None);
            var delta = await _stagingDiff.CompareAsync(StagingCandidateBox.Text, _settings, CancellationToken.None);
            if (delta.NotSelected > 0)
            {
                var answer = MessageBox.Show(this,
                    $"В предыдущем подписанном пакете GitHub TEST есть {delta.NotSelected} файлов, отсутствующих в новом пакете.\n\n" +
                    "Они исчезнут из файловой папки тестовой ветки, но у существующих клиентов автоматически НЕ удаляются. " +
                    "Это может быть следствием снятых галочек модов.\n\nПродолжить публикацию?",
                    "PROJECT ECHO — изменения состава TEST пакета", MessageBoxButton.YesNo, MessageBoxImage.Warning);
                if (answer != MessageBoxResult.Yes) { SetStatus("Публикация отменена владельцем"); return; }
            }
            Trace($"Сверка с GitHub TEST перед публикацией: новых {delta.Added}, изменённых {delta.Modified}, не включены {delta.NotSelected}.");
            SetStatus("GitHub TEST: проверка пакета и создание коммита...");
            var result = await _stagingGithub.PublishStagingAsync(StagingCandidateBox.Text, _settings, Trace, CancellationToken.None);
            _settings.LastStagingCandidatePath = StagingCandidateBox.Text;
            SettingsService.Save(_settings);
            StagingUrlText.Text = result.Url;
            StagingPreflightText.Text = $"ПУБЛИКАЦИЯ TEST: {result.Files} файлов, SHA commit {result.Commit[..12]}";
            SetStatus(result.Changed ? "Тестовая ветка GitHub обновлена" : "GitHub TEST уже содержал эти файлы");
            MessageBox.Show(this, "Готово. Обновлена только ТЕСТОВАЯ ветка GitHub.\n\n" + result.Url +
                "\n\nНе подключай этот URL к боевому клиенту!", "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            SetStatus("GitHub TEST: публикация не удалась");
            Trace("GITHUB STAGING: " + ex);
            MessageBox.Show(this, ex.Message + "\n\nЕсли ошибка авторизации: gh auth login и gh auth setup-git.",
                "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { _busy = false; StagingConfirmationBox.Clear(); }
    }

    private void OpenStagingUrl_Click(object sender, RoutedEventArgs e)
    {
        var address = StagingUrlText.Text.Trim();
        if (!address.StartsWith("https://raw.githubusercontent.com/KommandosNOD/Project-Echo-Launcher/project-echo-schema2-staging/updates/schema2-staging/manifest.json", StringComparison.Ordinal))
        {
            MessageBox.Show(this, "Сначала успешно опубликуй тестовую ветку.", "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(address) { UseShellExecute = true });
    }

    private void ChooseStagingClientSource_Click(object sender, RoutedEventArgs e) => ChooseFolder(StagingClientSourceBox);

    private async void BuildLauncherCandidate_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        _busy = true;
        try
        {
            SaveAll();
            SetStatus("Сборка и ECDSA-подпись STAGING EXE...");
            var result = await _launcherCandidate.BuildAndSignAsync(
                _settings.StagingClientSourceRoot, _settings.StagingLauncherVersion, _settings,
                Trace, CancellationToken.None);
            LauncherCandidateBox.Text = result.Directory;
            _settings.LastLauncherCandidatePath = result.Directory;
            SettingsService.Save(_settings);
            LauncherCandidateStatus.Text = $"ПОДГОТОВЛЕНО: {result.Tag} · {result.Bytes:N0} байт";
            SetStatus("STAGING EXE подготовлен. Ничего не опубликовано.");
            MessageBox.Show(this, "Подписанный EXE-кандидат собран и проверен:\n" + result.Directory +
                "\n\nЭто НЕ публикация на GitHub. Клиентов пока не обновляет.",
                "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            SetStatus("Ошибка подготовки STAGING EXE");
            Trace("STAGING EXE: " + ex);
            MessageBox.Show(this, ex.Message, "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { _busy = false; }
    }

    private async void VerifyLauncherCandidate_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        _busy = true;
        try
        {
            SaveAll();
            var result = await _launcherCandidate.VerifyAsync(LauncherCandidateBox.Text, _settings, CancellationToken.None);
            LauncherCandidateStatus.Text = $"ПРОВЕРЕНО: {result.Tag} · {result.Bytes:N0} байт · SHA-256 {result.Sha256}";
            SetStatus("Подпись и SHA-256 STAGING EXE верны");
            Trace("STAGING EXE VERIFIED: " + result.Directory);
        }
        catch (Exception ex)
        {
            SetStatus("Проверка STAGING EXE не пройдена");
            Trace("STAGING EXE VERIFY: " + ex);
            MessageBox.Show(this, ex.Message, "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { _busy = false; }
    }

private async void PublishLauncherPrerelease_Click(object sender, RoutedEventArgs e)
{
    if (_busy) return;
    if (LauncherReleaseConfirmationBox.Text.Trim() != "EXE-STAGING")
    {
        MessageBox.Show(this, "Для публикации тестового EXE введи EXE-STAGING.",
            "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Warning);
        return;
    }
    var confirm = MessageBox.Show(this,
        "Будет опубликован только TEST EXE в GitHub Prerelease. Затем подписанный launcher.json будет отправлен " +
        "в ветку project-echo-schema2-staging.\n\nБоевые main/stable, Cloudflare и моды не меняются. " +
        "Тестовый клиент с более старой версией увидит обновление. Продолжить?",
        "PROJECT ECHO — подтвердить STAGING", MessageBoxButton.YesNo, MessageBoxImage.Warning);
    if (confirm != MessageBoxResult.Yes) return;
    _busy = true;
    try
    {
        SaveAll();
        SetStatus("GitHub STAGING: проверка EXE и загрузка prerelease...");
        var result = await _launcherRelease.PublishAsync(LauncherCandidateBox.Text, _settings,
            Trace, CancellationToken.None);
        LauncherReleaseStatus.Text = "ГОТОВО: " + result.Tag + " · " + result.Bytes.ToString("N0") +
            " байт\n" + result.ReleaseUrl + "\n" + result.ManifestUrl;
        Trace("STAGING EXE PUBLISHED: " + result.ReleaseUrl);
        SetStatus("Подписанный STAGING EXE опубликован; production без изменений");
        MessageBox.Show(this, "STAGING EXE опубликован.\n\n" + result.ReleaseUrl +
            "\n\nТестируй только отдельный STAGING-клиент со встроенным Updater, не рабочий лаунчер.",
            "PROJECT ECHO — GitHub TEST", MessageBoxButton.OK, MessageBoxImage.Information);
    }
    catch (Exception ex)
    {
        SetStatus("GitHub STAGING EXE: публикация не удалась");
        Trace("STAGING EXE PUBLISH ERROR: " + ex);
        MessageBox.Show(this, "Публикация не завершена: " + ex.Message +
            "\n\nЕсли prerelease уже создан, сначала проверь его на GitHub. " +
            "Не повторяй публикацию автоматически с тем же тегом: сначала разберём причину.",
            "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Error);
    }
    finally { _busy = false; }
}

    private async void Build_Click(object sender, RoutedEventArgs e)
    {
        if (_busy) return;
        _busy = true;
        try
        {
            SaveAll();
            SetStatus("Компиляция клиентского лаунчера...");
            var path = await _clientBuild.BuildAsync(_settings, Trace, CancellationToken.None);
            SetStatus("Сборка EXE завершена");
            MessageBox.Show(this, "Клиент собран: " + path +
                "\n\nЭтот EXE пока использует старый механизм обновления модов. Он не готов к публикации как Launcher 2.0.",
                "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { SetStatus("Ошибка сборки EXE"); Trace("ОШИБКА: " + ex); MessageBox.Show(this, ex.Message, "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Error); }
        finally { _busy = false; if (_dirty) { _dirty = false; _debouncer.Stop(); _debouncer.Start(); } }
    }

    private async void SaveSettings_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            SaveAll();
            StartWatcher();
            Trace("Настройки сохранены.");
            await ScanAsync();
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Настройки", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private void ChooseFolder(System.Windows.Controls.TextBox target)
    {
        var dialog = new OpenFolderDialog { Title = "PROJECT ECHO: выбери папку", Multiselect = false };
        if (Directory.Exists(target.Text)) dialog.InitialDirectory = target.Text;
        if (dialog.ShowDialog(this) == true) target.Text = dialog.FolderName;
    }
    private void ChooseMods_Click(object sender, RoutedEventArgs e) => ChooseFolder(ModsRootBox);
    private void ChooseProject_Click(object sender, RoutedEventArgs e) => ChooseFolder(ProjectRootBox);
    private void ChooseOutput_Click(object sender, RoutedEventArgs e) => ChooseFolder(OutputRootBox);
    private void ClearLog_Click(object sender, RoutedEventArgs e) => LogBox.Clear();

    private void StartWatcher()
    {
        _autoBuildCancellation?.Cancel();
        _watcher?.Dispose();
        _watcher = null;
        _debouncer.Stop();
        if (!_settings.AutoRescan || !Directory.Exists(_settings.ModsRoot)) return;
        _watcher = new FileSystemWatcher(_settings.ModsRoot)
        {
            IncludeSubdirectories = true,
            NotifyFilter = NotifyFilters.FileName | NotifyFilters.DirectoryName | NotifyFilters.LastWrite | NotifyFilters.Size,
            EnableRaisingEvents = true
        };
        void OnChange(object s, FileSystemEventArgs e) => ScheduleRescan();
        _watcher.Created += OnChange;
        _watcher.Changed += OnChange;
        _watcher.Deleted += OnChange;
        _watcher.Renamed += (s, e) => ScheduleRescan();
        _watcher.Error += (s, e) => ScheduleRescan(); // full scan after an overflow
    }

    private void ScheduleRescan()
    {
        if (Dispatcher.HasShutdownStarted) return;
        Dispatcher.BeginInvoke(() =>
        {
            FooterText.Text = "Обнаружены изменения в папке mods";
            _debouncer.Stop();
            _debouncer.Start();
        });
    }
}
