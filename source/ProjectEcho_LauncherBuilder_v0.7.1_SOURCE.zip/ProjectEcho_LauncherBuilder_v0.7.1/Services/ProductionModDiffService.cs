using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text.Json;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder.Services;

public sealed record ProductionModDiffRow(string Change, string Path, long Bytes);

internal sealed class ProductionModDiffService
{
    internal sealed record Report(string Revision, int Added, int Modified, int Missing, int Unchanged,
        string DefaultSha256, List<ProductionModDiffRow> Rows);
    private const string Repo = "KommandosNOD/Project-Echo-Launcher";
    private const string Branch = "project-echo-schema2-production";
    private const string DirectoryName = "updates/schema2-staging"; // Existing production client v0.8.x reads this path.
    private static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(40) };
    static ProductionModDiffService() => Http.DefaultRequestHeaders.UserAgent.ParseAdd("ProjectEchoBuilder/0.7.1");

    internal async Task<Report> CompareAsync(BuilderSettings settings, CancellationToken ct)
    {
        // Resolve immutable HEAD first, preventing a mixed manifest / signature if the branch moves.
        using var headRes = await Http.GetAsync("https://api.github.com/repos/" + Repo + "/git/ref/heads/" + Branch,
            HttpCompletionOption.ResponseHeadersRead, ct);
        headRes.EnsureSuccessStatusCode();
        using var head = JsonDocument.Parse(await headRes.Content.ReadAsStreamAsync(ct));
        string sha = head.RootElement.GetProperty("object").GetProperty("sha").GetString() ?? "";
        if (sha.Length != 40 || !sha.All(Uri.IsHexDigit)) throw new InvalidDataException("Неверный commit SHA production.");
        string baseUrl = "https://raw.githubusercontent.com/" + Repo + "/" + sha + "/" + DirectoryName + "/";
        byte[] manifestBytes = await GetBoundedAsync(baseUrl + "manifest.json", 4 * 1024 * 1024, ct);
        byte[] signature = await GetBoundedAsync(baseUrl + "manifest.sig", 256, ct);
        using var key = ECDsa.Create();
        key.ImportFromPem(File.ReadAllText(Path.Combine(settings.ProjectRoot, "launcher", "TrustedReleasePublicKey.pem")));
        if (!key.VerifyData(manifestBytes, signature, HashAlgorithmName.SHA256, DSASignatureFormat.Rfc3279DerSequence))
            throw new CryptographicException("Подпись текущего GitHub production манифеста НЕВЕРНА.");
        var old = JsonSerializer.Deserialize<OwnerManifest>(manifestBytes)
            ?? throw new InvalidDataException("Production манифест пуст.");
        if (old.Schema != 2 || old.Kind != "PROJECT_ECHO_LOCAL_MODS" || old.Channel != "stable" ||
            old.Retired.Count != 0 || !old.Files.Any(f => f.Path == "mods/default.txt"))
            throw new InvalidDataException("Production-манифест не соответствует schema 2.");
        var inventory = await new ModInventoryService().ScanAsync(settings, null, ct);
        var selected = inventory.Mods.Where(m => m.IsSelected && m.FileCount > 0)
            .Select(m => m.Name).ToHashSet(StringComparer.OrdinalIgnoreCase);
        if (selected.Count == 0) throw new InvalidDataException("Нет выбранных локальных модов.");
        var files = inventory.Files.Where(f => f.Path == "mods/default.txt" ||
            (f.Path.StartsWith("mods/", StringComparison.Ordinal) && selected.Contains(f.Path.Split('/')[1])))
            .ToDictionary(f => f.Path, StringComparer.OrdinalIgnoreCase);
        if (!files.TryGetValue("mods/default.txt", out var defaultFile))
            throw new InvalidDataException("Нужен default.txt в папке Zomboid\\mods.");
        if (File.ReadAllText(defaultFile.FullPath).Contains("PROJECT_ECHO_TEST_DEFAULT_ONLY", StringComparison.Ordinal))
            throw new InvalidDataException("Тестовый default.txt не допускается в production.");
        var prior = old.Files.ToDictionary(f => f.Path, StringComparer.OrdinalIgnoreCase);
        var rows = new List<ProductionModDiffRow>();
        int added = 0, modified = 0, unchanged = 0, missing = 0;
        foreach (var f in files.Values.OrderBy(x => x.Path, StringComparer.OrdinalIgnoreCase))
        {
            if (!prior.TryGetValue(f.Path, out var before)) { added++; rows.Add(new ProductionModDiffRow("НОВЫЙ", f.Path, f.Size)); }
            else if (!f.Sha256.Equals(before.Sha256, StringComparison.OrdinalIgnoreCase)) { modified++; rows.Add(new ProductionModDiffRow("ИЗМЕНЁН", f.Path, f.Size)); }
            else unchanged++;
        }
        foreach (var f in old.Files.Where(f => !files.ContainsKey(f.Path)).OrderBy(f => f.Path, StringComparer.OrdinalIgnoreCase))
        { missing++; rows.Add(new ProductionModDiffRow("НЕ В НОВОМ ПАКЕТЕ", f.Path, f.Size)); }
        return new(old.Version, added, modified, missing, unchanged, defaultFile.Sha256, rows);
    }
    private static async Task<byte[]> GetBoundedAsync(string url, int max, CancellationToken ct)
    {
        using var req = new HttpRequestMessage(HttpMethod.Get, url);
        req.Headers.UserAgent.ParseAdd("ProjectEchoBuilder/0.7.1");
        using var response = await Http.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct);
        response.EnsureSuccessStatusCode();
        if (response.Content.Headers.ContentLength > max) throw new InvalidDataException("Production-файл слишком велик.");
        await using var stream = await response.Content.ReadAsStreamAsync(ct);
        using var ms = new MemoryStream();
        var buffer = new byte[32768];
        int n;
        while ((n = await stream.ReadAsync(buffer, ct)) > 0)
        {
            if (ms.Length + n > max) throw new InvalidDataException("Production-файл слишком велик.");
            ms.Write(buffer, 0, n);
        }
        return ms.ToArray();
    }
}
