using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder.Services;

/// <summary>
/// Owner-only signed production mods publisher. Writes ONLY updates/schema2-staging in project-echo-schema2-production.
/// Never writes main, staging branch, Cloudflare or Steam game files.
/// </summary>
internal sealed class GitHubProductionModsService
{
    private const string Repo = "KommandosNOD/Project-Echo-Launcher";
    private const string Branch = "project-echo-schema2-production";
    private const string StageSubpath = "updates/schema2-staging";
    private const long GitHubFileLimit = 95L * 1024 * 1024;
    private const long GitHubPackageLimit = 450L * 1024 * 1024;
    private readonly LocalDraftSigningService _signer = new();

    internal sealed record StagingCandidate(string Folder, int Count, long Bytes, string Version);
    internal sealed record PublishResult(string Url, string Commit, int Files, long Bytes, bool Changed);

    public async Task<StagingCandidate> PrepareAsync(BuilderSettings settings, Action<string> log, CancellationToken ct)
    {
        // Never stage from an old scan: working owner files are the only release source.
        var inventory = await new ModInventoryService().ScanAsync(settings, log);
        var mods = inventory.Mods.Where(m => m.IsSelected).ToList();
        if (mods.Count == 0) throw new InvalidDataException("Не выбран ни один мод.");
        if (mods.Any(m => m.Name.Equals("ProjectEcho_BuilderSmokeTest", StringComparison.OrdinalIgnoreCase)))
            throw new InvalidDataException("Тестовый SmokeTest запрещён для кандидата публикации.");
        var sourceDefault = Path.Combine(settings.ModsRoot, "default.txt");
        RejectSmokeDefault(sourceDefault);
        var draft = await new StageService().StageAsync(inventory, settings, log, ct, fullSnapshot: true);
        var details = await _signer.SignAsync(draft, settings, ct);
        await VerifyRealSourceAsync(details.Folder, settings, ct);
        var manifestHash = HashFile(Path.Combine(details.Folder, "manifest.json"));
        var marker = new
        {
            schema = 1,
            kind = "PROJECT_ECHO_GITHUB_PRODUCTION_MODS_CANDIDATE",
            manifestSha256 = manifestHash,
            preparedUtc = DateTimeOffset.UtcNow,
            ownerSourceFolder = settings.ModsRoot,
            branch = Branch,
            remoteDirectory = StageSubpath
        };
        await File.WriteAllTextAsync(Path.Combine(details.Folder, "PRODUCTION_MODS_CANDIDATE.json"),
            JsonSerializer.Serialize(marker, new JsonSerializerOptions { WriteIndented = true }), ct);
        return new StagingCandidate(details.Folder, details.FileCount, details.Bytes, details.Version);
    }

    public async Task<StagingCandidate> PreflightAsync(string draft, BuilderSettings settings, CancellationToken ct)
    {
        var details = await _signer.VerifySignedAsync(draft, settings, ct);
        var flag = Path.Combine(details.Folder, "PRODUCTION_MODS_CANDIDATE.json");
        if (!File.Exists(flag))
            throw new InvalidDataException("Эта папка не является реальным кандидатом релиза. Создай её кнопкой «Подготовить кандидат» — локальные SmokeTest-черновики запрещены.");
        using (var json = JsonDocument.Parse(await File.ReadAllBytesAsync(flag, ct)))
        {
            var obj = json.RootElement;
            if (obj.GetProperty("schema").GetInt32() != 1 ||
                obj.GetProperty("kind").GetString() != "PROJECT_ECHO_GITHUB_PRODUCTION_MODS_CANDIDATE" ||
                obj.GetProperty("branch").GetString() != Branch ||
                obj.GetProperty("remoteDirectory").GetString() != StageSubpath ||
                !string.Equals(obj.GetProperty("ownerSourceFolder").GetString(), settings.ModsRoot, StringComparison.OrdinalIgnoreCase) ||
                !string.Equals(obj.GetProperty("manifestSha256").GetString(), HashFile(Path.Combine(details.Folder, "manifest.json")), StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Кандидат публикации был изменён или взят из другого источника.");
        }
        await VerifyRealSourceAsync(details.Folder, settings, ct);
        if (details.Bytes > GitHubPackageLimit || details.FileCount > 2500)
            throw new InvalidDataException("Пакет слишком большой для прямой загрузки в git (450 МиБ / 2500 файлов). Понадобится отдельное файловое хранилище.");
        return new StagingCandidate(details.Folder, details.FileCount, details.Bytes, details.Version);
    }

    private static void RejectSmokeDefault(string path)
    {
        if (!File.Exists(path)) throw new FileNotFoundException("Отсутствует default.txt", path);
        if (new FileInfo(path).Length > 4 * 1024 * 1024)
            throw new InvalidDataException("default.txt слишком большой для проверки.");
        if (File.ReadAllText(path).Contains("PROJECT_ECHO_TEST_DEFAULT_ONLY", StringComparison.Ordinal))
            throw new InvalidDataException("Найден тестовый маркер в default.txt. Публикация запрещена.");
    }

    private static string HashFile(string file) =>
        Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(file))).ToLowerInvariant();

    private static async Task VerifyRealSourceAsync(string folder, BuilderSettings settings, CancellationToken ct)
    {
        var manifest = JsonSerializer.Deserialize<OwnerManifest>(await File.ReadAllBytesAsync(Path.Combine(folder, "manifest.json"), ct))
            ?? throw new InvalidDataException("Пустой манифест.");
        if (manifest.Schema != 2 || manifest.Channel != "stable" || manifest.Retired.Count != 0 ||
            !manifest.Files.Any(f => f.Path == "mods/default.txt"))
            throw new InvalidDataException("Некорректный манифест полного снимка.");
        var sourceRoot = Path.GetFullPath(settings.ModsRoot);
        foreach (var f in manifest.Files)
        {
            ct.ThrowIfCancellationRequested();
            var rel = PathSafety.ValidatePatchPath(f.Path);
            if (rel.StartsWith("mods/ProjectEcho_BuilderSmokeTest/", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Тестовый мод запрещён: " + rel);
            var sourceRel = rel["mods/".Length..];
            var full = Path.GetFullPath(Path.Combine(sourceRoot, sourceRel.Replace('/', Path.DirectorySeparatorChar)));
            if (!full.StartsWith(sourceRoot.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Путь выходит за пределы источника: " + rel);
            if (!File.Exists(full)) throw new FileNotFoundException("Исходный файл больше не существует: " + rel);
            PathSafety.CheckFile(full);
            var dir = Path.GetDirectoryName(full)!;
            while (dir.Length >= sourceRoot.Length)
            {
                PathSafety.CheckDirectory(dir);
                if (dir.Equals(sourceRoot, StringComparison.OrdinalIgnoreCase)) break;
                dir = Path.GetDirectoryName(dir)!;
            }
            if (new FileInfo(full).Length != f.Size)
                throw new InvalidDataException("Размер исходного файла изменился после сборки: " + rel);
            await using var stream = File.OpenRead(full);
            var hash = Convert.ToHexString(await SHA256.HashDataAsync(stream, ct));
            if (!hash.Equals(f.Sha256, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Исходный файл изменился после сборки: " + rel);
        }
        RejectSmokeDefault(Path.Combine(sourceRoot, "default.txt"));
        // Detect files or newly-added selected mods missing from this snapshot.
        // A release candidate must be a COMPLETE snapshot of the currently selected source,
        // not merely a subset of previously selected files.
        var current = await new ModInventoryService().ScanAsync(settings, null, ct);
        var selected = new HashSet<string>(current.Mods.Where(m => m.IsSelected).Select(m => m.Name), StringComparer.OrdinalIgnoreCase);
        var paths = current.Files.Where(f => f.Path == "mods/default.txt" ||
                (f.Path.StartsWith("mods/", StringComparison.Ordinal) && selected.Contains(f.Path.Split('/')[1])))
            .Select(f => f.Path).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var signedPaths = manifest.Files.Select(f => f.Path).ToHashSet(StringComparer.OrdinalIgnoreCase);
        if (!paths.SetEquals(signedPaths))
            throw new InvalidDataException("После подготовки пакета изменился состав выбранных модов. Создай новый кандидат перед публикацией.");
    }

    public async Task<PublishResult> PublishProductionAsync(string folder, BuilderSettings settings,
        Action<string> log, CancellationToken ct)
    {
        var details = await PreflightAsync(folder, settings, ct);
        // Explicitly require the owner's authenticated CLI. Never store or copy API secrets.
        var user = (await RunAsync("gh", new[] { "api", "user", "--jq", ".login" }, settings.OutputRoot, log, ct)).Trim();
        if (!user.Equals("KommandosNOD", StringComparison.OrdinalIgnoreCase))
            throw new UnauthorizedAccessException("gh должен быть авторизован владельцем KommandosNOD; текущий: " + user);
        var repo = (await RunAsync("gh", new[] { "repo", "view", Repo, "--json", "nameWithOwner", "--jq", ".nameWithOwner" },
            settings.OutputRoot, log, ct)).Trim();
        if (!repo.Equals(Repo, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("GitHub CLI указывает на другой репозиторий.");
        var url = "https://github.com/" + Repo + ".git";
        var stagingRoot = Path.Combine(Path.GetFullPath(settings.OutputRoot), "github-production-mods-work");
        Directory.CreateDirectory(stagingRoot);
        var temp = Path.Combine(stagingRoot, "checkout-" + Guid.NewGuid().ToString("N"));
        try
        {
            var probe = await RunResultAsync("git", new[] { "ls-remote", "--heads", url, "refs/heads/" + Branch },
                stagingRoot, log, ct);
            if (probe.Code != 0) throw new IOException("git ls-remote не смог проверить удалённую ветку: " + probe.Error);
            var branchExists = !string.IsNullOrWhiteSpace(probe.Output);
            if (!branchExists) throw new InvalidOperationException("Нет рабочей production-ветки GitHub. Публикация заблокирована.");
            var checkoutBranch = Branch;
            log("GitHub: изолированное клонирование ветки " + checkoutBranch);
            await RunAsync("git", new[] { "clone", "--depth", "1", "--single-branch", "--branch", checkoutBranch, url, temp }, stagingRoot, log, ct);
            var branch = (await RunAsync("git", new[] { "branch", "--show-current" }, temp, log, ct)).Trim();
            if (branch != Branch) throw new InvalidDataException("Отказ: активна не рабочая production-ветка GitHub.");

            var dest = Path.Combine(temp, "updates", "schema2-staging");
            if (Directory.Exists(dest))
            {
                var oldManifest = Path.Combine(dest, "manifest.json");
                var oldSig = Path.Combine(dest, "manifest.sig");
                if (File.Exists(oldManifest) && File.Exists(oldSig))
                {
                    // Never promote atop an invalid signed baseline.
                    using var verifyKey = ECDsa.Create();
                    verifyKey.ImportFromPem(File.ReadAllText(Path.Combine(settings.ProjectRoot, "launcher", "TrustedReleasePublicKey.pem")));
                    var oldBytes = File.ReadAllBytes(oldManifest);
                    var oldVersion = JsonSerializer.Deserialize<OwnerManifest>(oldBytes)?.Version;
                    if (string.IsNullOrWhiteSpace(oldVersion) ||
                        string.CompareOrdinal(details.Version, oldVersion) <= 0)
                        throw new InvalidDataException("Новый снимок должен иметь версию позже опубликованной. Создай свежий кандидат.");
                    if (!verifyKey.VerifyData(oldBytes, File.ReadAllBytes(oldSig),
                        HashAlgorithmName.SHA256, DSASignatureFormat.Rfc3279DerSequence))
                        throw new CryptographicException("Существующий production-манифест имеет неверную подпись — публикация отменена.");
                    var saved = Path.Combine(settings.OutputRoot, "production-mods-backups", DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fff"));
                    Directory.CreateDirectory(saved);
                    File.Copy(oldManifest, Path.Combine(saved, "manifest.json"));
                    File.Copy(oldSig, Path.Combine(saved, "manifest.sig"));
                    File.WriteAllText(Path.Combine(saved, "PREVIOUS_COMMIT.txt"),
                        (await RunAsync("git", new[] { "rev-parse", "HEAD" }, temp, log, ct)).Trim() + Environment.NewLine);
                    log("Резерв предыдущего production-манифеста: " + saved);
                }
                else if (File.Exists(oldManifest) || File.Exists(oldSig))
                    throw new InvalidDataException("В существующем production-канале отсутствует подпись или манифест.");
                Directory.Delete(dest, recursive: true); // only inside isolated checkout
            }
            Directory.CreateDirectory(dest);
            // CRITICAL: Git for Windows (core.autocrlf=true) can normalize CRLF -> LF
            // on git add. The ECDSA signature covers EXACT manifest bytes and mod
            // payload SHA-256 covers exact file bytes. Make the entire subtree raw.
            // This applies only to this staging release directory, never repo-wide.
            await File.WriteAllTextAsync(Path.Combine(dest, ".gitattributes"),
                "# PROJECT ECHO: byte-exact signed patches; never change line endings.\n* -text\n",
                new UTF8Encoding(false), ct);
            foreach (var name in new[] { "manifest.json", "manifest.sig" })
                File.Copy(Path.Combine(details.Folder, name), Path.Combine(dest, name));
            var manifest = JsonSerializer.Deserialize<OwnerManifest>(await File.ReadAllBytesAsync(Path.Combine(details.Folder, "manifest.json"), ct))!;
            foreach (var file in manifest.Files)
            {
                ct.ThrowIfCancellationRequested();
                if (file.Size > GitHubFileLimit)
                    throw new InvalidDataException("GitHub не принимает этот большой файл (>95 МиБ): " + file.Path);
                var rel = PathSafety.ValidatePatchPath(file.Path);
                var source = PathSafety.SafeTarget(Path.Combine(details.Folder, "files"), rel);
                var target = PathSafety.SafeTarget(Path.Combine(dest, "files"), rel);
                Directory.CreateDirectory(Path.GetDirectoryName(target)!);
                File.Copy(source, target, false);
                if (HashFile(target) != file.Sha256.ToLowerInvariant())
                    throw new CryptographicException("Сбой копирования пакета: " + rel);
            }
            await RunAsync("git", new[] { "add", "--", StageSubpath }, temp, log, ct);
            // Verify all indexed Git blobs, including JSON, LUA, JAR, tiles, pack,
            // match the local files before any commit or push can happen.
            var indexed = await VerifyGitIndexIsByteExactAsync(temp, dest, ct, log);
            var diff = await RunResultAsync("git", new[] { "diff", "--cached", "--quiet", "--", StageSubpath }, temp, log, ct);
            if (diff.Code is not (0 or 1)) throw new IOException("git diff: " + diff.Error);
            bool changed = diff.Code == 1;
            if (changed)
            {
                await RunAsync("git", new[] { "-c", "user.name=PROJECT ECHO Production Mods", "-c", "user.email=project-echo@users.noreply.github.com",
                    "commit", "-m", "release: signed schema2 production mods " + details.Version }, temp, log, ct);
            }
            // Ensure the actual committed Git tree still contains the indexed bytes.
            // Check before pushing so a bad object can never reach GitHub.
            await VerifyCommittedTreeAsync(temp, indexed, ct);
            if (changed)
                await RunAsync("git", new[] { "push", "origin", "HEAD:refs/heads/" + Branch }, temp, log, ct);
            var head = (await RunAsync("git", new[] { "rev-parse", "HEAD" }, temp, log, ct)).Trim();
            var remote = (await RunAsync("git", new[] { "ls-remote", "--heads", "origin", "refs/heads/" + Branch },
                temp, log, ct)).Trim().Split('\t')[0];
            if (head != remote) throw new InvalidDataException("Удалённая ветка не подтверждена после отправки.");
            var manifestUrl = "https://raw.githubusercontent.com/" + Repo + "/" + Branch + "/" + StageSubpath + "/manifest.json";
            log("PRODUCTION МОДЫ ОПУБЛИКОВАНЫ: " + manifestUrl);
            return new PublishResult(manifestUrl, head, details.Count, details.Bytes, changed);
        }
        finally
        {
            try { if (Directory.Exists(temp)) Directory.Delete(temp, recursive: true); }
            catch (Exception ex) { log("Временный git checkout не удалось удалить: " + ex.Message); }
        }
    }

    // SHA-1 here is only Git's blob object identifier, NOT the patch security
    // digest: ECDSA + SHA-256 in the signed manifest are still mandatory.
    private static async Task<string> GitBlobObjectIdAsync(string path, CancellationToken ct)
    {
        using var hasher = IncrementalHash.CreateHash(HashAlgorithmName.SHA1);
        var header = Encoding.ASCII.GetBytes("blob " + new FileInfo(path).Length + "\0");
        hasher.AppendData(header);
        await using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read,
            65536, FileOptions.Asynchronous | FileOptions.SequentialScan);
        var buffer = new byte[65536];
        int length;
        while ((length = await stream.ReadAsync(buffer.AsMemory(), ct)) != 0)
            hasher.AppendData(buffer, 0, length);
        return Convert.ToHexString(hasher.GetHashAndReset()).ToLowerInvariant();
    }

    private static Dictionary<string, string> ParseGitStageRecords(string raw)
    {
        var result = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var record in raw.Split('\0', StringSplitOptions.RemoveEmptyEntries))
        {
            var tab = record.IndexOf('\t');
            if (tab < 0) throw new InvalidDataException("Повреждён вывод git ls-files --stage.");
            var header = record[..tab].Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (header.Length != 3 || header[1].Length != 40 || header[2] != "0")
                throw new InvalidDataException("Неподдерживаемый индекс Git (ожидается SHA-1 и обычные файлы).");
            if (!result.TryAdd(record[(tab + 1)..], header[1].ToLowerInvariant()))
                throw new InvalidDataException("Повторяющиеся файлы в Git index.");
        }
        return result;
    }

    private static async Task<Dictionary<string, string>> VerifyGitIndexIsByteExactAsync(
        string checkout, string releaseDirectory, CancellationToken ct, Action<string> log)
    {
        var raw = await RunAsync("git", new[] { "-c", "core.quotepath=false", "ls-files", "--stage", "-z", "--", StageSubpath },
            checkout, log, ct);
        var index = ParseGitStageRecords(raw);
        var files = Directory.EnumerateFiles(releaseDirectory, "*", SearchOption.AllDirectories).ToArray();
        if (files.Length != index.Count)
            throw new InvalidDataException($"Git пропустил файлы пакета: в папке {files.Length}, в индексе {index.Count}.");
        foreach (var fullPath in files)
        {
            ct.ThrowIfCancellationRequested();
            var relative = Path.GetRelativePath(releaseDirectory, fullPath).Replace('\\', '/');
            var gitPath = StageSubpath + "/" + relative;
            if (!index.TryGetValue(gitPath, out var oid))
                throw new InvalidDataException("Git не включил файл: " + gitPath);
            var rawOid = await GitBlobObjectIdAsync(fullPath, ct);
            if (!rawOid.Equals(oid, StringComparison.OrdinalIgnoreCase))
                throw new CryptographicException("Git изменил байты файла при git add: " + gitPath +
                    ". Публикация ОСТАНОВЛЕНА. Проверь core.autocrlf / .gitattributes.");
        }
        log($"Git index: побайтно проверены {index.Count} файлов, преобразования строк нет.");
        return index;
    }

    private static async Task VerifyCommittedTreeAsync(string checkout, Dictionary<string, string> expected,
        CancellationToken ct)
    {
        var raw = await RunAsync("git", new[] { "-c", "core.quotepath=false", "ls-tree", "-r", "-z", "HEAD", "--", StageSubpath },
            checkout, _ => { }, ct);
        var found = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var record in raw.Split('\0', StringSplitOptions.RemoveEmptyEntries))
        {
            var tab = record.IndexOf('\t');
            if (tab < 0) throw new InvalidDataException("Повреждён вывод git ls-tree.");
            var header = record[..tab].Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (header.Length != 3 || header[1] != "blob" || header[2].Length != 40 ||
                !found.TryAdd(record[(tab + 1)..], header[2].ToLowerInvariant()))
                throw new InvalidDataException("Неожиданное содержимое Git tree.");
        }
        if (found.Count != expected.Count || expected.Any(kv =>
            !found.TryGetValue(kv.Key, out var oid) || !oid.Equals(kv.Value, StringComparison.Ordinal)))
            throw new CryptographicException("Git commit не совпадает с подписанным пакетом; push отменён.");
    }

    private sealed record ProcessResult(int Code, string Output, string Error);

    private static async Task<string> RunAsync(string exe, IEnumerable<string> args, string cwd,
        Action<string> log, CancellationToken ct)
    {
        var result = await RunResultAsync(exe, args, cwd, log, ct);
        if (result.Code != 0)
            throw new IOException($"{exe} завершился с кодом {result.Code}: {result.Error} {result.Output}");
        return result.Output;
    }

    private static async Task<ProcessResult> RunResultAsync(string exe, IEnumerable<string> args, string cwd,
        Action<string> log, CancellationToken ct)
    {
        using var process = new Process { StartInfo = new ProcessStartInfo
        {
            FileName = exe, WorkingDirectory = cwd, CreateNoWindow = true, UseShellExecute = false,
            RedirectStandardOutput = true, RedirectStandardError = true,
            StandardOutputEncoding = Encoding.UTF8, StandardErrorEncoding = Encoding.UTF8
        } };
        foreach (var arg in args) process.StartInfo.ArgumentList.Add(arg);
        if (!process.Start()) throw new IOException("Не удалось запустить " + exe);
        using var deadline = CancellationTokenSource.CreateLinkedTokenSource(ct);
        deadline.CancelAfter(TimeSpan.FromMinutes(15));
        var outputTask = process.StandardOutput.ReadToEndAsync(deadline.Token);
        var errorTask = process.StandardError.ReadToEndAsync(deadline.Token);
        try { await process.WaitForExitAsync(deadline.Token); }
        catch (OperationCanceledException) { try { process.Kill(entireProcessTree: true); } catch { } throw; }
        var stdout = await outputTask;
        var stderr = await errorTask;
        if (!string.IsNullOrWhiteSpace(stderr)) log(exe + ": " + stderr.Trim()[..Math.Min(stderr.Trim().Length, 1000)]);
        return new ProcessResult(process.ExitCode, stdout, stderr);
    }
}
