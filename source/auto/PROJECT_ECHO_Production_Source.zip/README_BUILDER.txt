PROJECT ECHO Launcher production source candidate 0.8.6
BASE: PROJECT_ECHO_Production_Source_v0.8.5_INTEGRATED.zip
UI: PROJECT_ECHO_LAUNCHER_UI_v1.3.1_POWERSHELL_FIX.zip
CHANGES: v1.3.1 slim scrollbar & settings helpers collapsed, Version 0.8.5 -> 0.8.6.
UPDATER: EXACT original updater/Program.cs and updater/ProjectEchoUpdater.csproj from v0.8.5.
This package does NOT contain later local-only changes to launcher and was NOT compiled on Windows.
TEST: login, news scroll, settings buttons, updater flow BEFORE publish.
BUILDER v0.7.2: EXE PRODUCTION > 0 > choose this source ZIP > version 0.8.6.
