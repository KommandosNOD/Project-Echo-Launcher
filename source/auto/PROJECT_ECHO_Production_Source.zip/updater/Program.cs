// PROJECT ECHO production dedicated updater (no WPF and no dependency on launcher UI).
// This executable is embedded into the launcher; users never download or run it manually.
using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

internal static class Program
{
    private const string Switch = "--pe-apply-launcher-update";
    private const string BinaryName = "ProjectEchoLauncher.exe";
    private static readonly string StateDir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "PZCommunityLauncher", "launcher-selfupdate");
    private static readonly StringComparison OrdinalPath = StringComparison.OrdinalIgnoreCase;

    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            Directory.CreateDirectory(StateDir);
            Trace("DEDICATED UPDATER START, PID=" + Environment.ProcessId);
            Install(args);
            Trace("DEDICATED UPDATER SUCCESS");
            return 0;
        }
        catch (Exception ex)
        {
            Trace("DEDICATED UPDATER FAILED: " + ex);
            try { File.WriteAllText(Path.Combine(StateDir, "update-error.log"), ex.ToString(), Encoding.UTF8); }
            catch { /* trace is best effort */ }
            return 1;
        }
    }

    private static void Install(string[] args)
    {
        if (args.Length != 6 || args[0] != Switch ||
            !int.TryParse(args[1], out int oldPid) || oldPid <= 0 ||
            !Regex.IsMatch(args[4], "^[a-f0-9]{64}$") ||
            !Regex.IsMatch(args[5], "^[a-f0-9]{32}$"))
            throw new InvalidDataException("Неверные аргументы production updater.");

        string target = Path.GetFullPath(args[2]);
        string stage = Path.GetFullPath(args[3]);
        string expectedSha = args[4];
        string token = args[5];
        string updaterExe = Path.GetFullPath(Environment.ProcessPath ?? throw new InvalidOperationException("No executable path"));
        string stateRoot = Path.GetFullPath(StateDir).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;

        if (!string.Equals(Path.GetFileName(target), BinaryName, OrdinalPath) ||
            target.StartsWith(stateRoot, OrdinalPath) ||
            !stage.StartsWith(stateRoot, OrdinalPath) ||
            !Path.GetFileName(stage).StartsWith("ProjectEchoLauncher.stage-", OrdinalPath) ||
            !updaterExe.StartsWith(stateRoot, OrdinalPath) ||
            !Path.GetFileName(updaterExe).StartsWith("ProjectEchoUpdater.worker-", OrdinalPath))
            throw new InvalidDataException("Запрещённая цель или путь установки.");

        if (!File.Exists(stage) || !File.Exists(target))
            throw new FileNotFoundException("production EXE не найден (скачанный или установленный).");
        Trace("Verified stage: " + stage);
        using (var input = File.OpenRead(stage))
        {
            string actual = Convert.ToHexString(SHA256.HashData(input)).ToLowerInvariant();
            if (actual != expectedSha)
                throw new CryptographicException("SHA-256 загруженного production EXE не совпадает.");
        }
        Trace("Stage SHA-256 OK");

        string ready = Path.Combine(StateDir, "worker-ready-" + token + ".txt");
        File.WriteAllText(ready, "READY", Encoding.ASCII);
        Trace("Handshake written; waiting old PID=" + oldPid);

        try
        {
            using var old = Process.GetProcessById(oldPid);
            if (!old.WaitForExit(90000))
                throw new TimeoutException("Предыдущий лаунчер не завершился за 90 секунд.");
        }
        catch (ArgumentException) { /* already terminated */ }

        Trace("Old launcher stopped; replacing EXE");
        string temp = target + ".update.tmp";
        string backup = target + ".previous-" + DateTime.UtcNow.ToString("yyyyMMdd-HHmmss");
        bool replaced = false;
        try
        {
            // Copy to same volume to make File.Replace (and backup) reliable.
            File.Copy(stage, temp, overwrite: true);
            for (int i = 0; ; ++i)
            {
                try
                {
                    File.Replace(temp, target, backup, ignoreMetadataErrors: true);
                    replaced = true;
                    break;
                }
                catch (IOException) when (i < 12) { Thread.Sleep(750); }
            }
            Trace("Replacement OK, backup=" + backup);
            using var newLauncher = Process.Start(new ProcessStartInfo(target)
            {
                UseShellExecute = true,
                WorkingDirectory = Path.GetDirectoryName(target)!
            }) ?? throw new IOException("Не удалось запустить новую версию лаунчера.");
            Trace("New launcher PID=" + newLauncher.Id);
            if (newLauncher.WaitForExit(5000))
                throw new IOException("Новый лаунчер завершился сразу (код " + newLauncher.ExitCode + ").");
            Trace("New launcher remained running for at least 5 seconds.");
        }
        catch (Exception ex)
        {
            Trace("INSTALL FAILED, attempting rollback: " + ex);
            if (replaced && File.Exists(backup))
            {
                try
                {
                    // New process should have exited if WaitForExit detected an early crash.
                    File.Copy(backup, target, overwrite: true);
                    Trace("Rollback restored old EXE.");
                }
                catch (Exception rollbackEx) { Trace("ROLLBACK FAILED: " + rollbackEx); }
            }
            try
            {
                if (File.Exists(target))
                {
                    Process.Start(new ProcessStartInfo(target)
                    {
                        UseShellExecute = true,
                        WorkingDirectory = Path.GetDirectoryName(target)!
                    });
                    Trace("Attempted to restart previous launcher.");
                }
            }
            catch (Exception restartEx) { Trace("RESTART FAILED: " + restartEx); }
            throw;
        }
        finally
        {
            try { if (File.Exists(temp)) File.Delete(temp); } catch { }
        }
    }

    private static void Trace(string message)
    {
        try
        {
            Directory.CreateDirectory(StateDir);
            File.AppendAllText(Path.Combine(StateDir, "worker-trace.log"),
                DateTimeOffset.Now.ToString("O") + " | " + message + Environment.NewLine, Encoding.UTF8);
        }
        catch { /* do not hide the original failure */ }
    }
}
