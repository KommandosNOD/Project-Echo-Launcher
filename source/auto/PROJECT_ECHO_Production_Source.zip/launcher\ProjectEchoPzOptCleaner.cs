// PROJECT ECHO - PZ Optimization residue cleaner (launcher UI + safe quarantine)
// Target: PZLauncher WPF / net10.0-windows. No external dependencies.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace PZLauncher;

internal static class ProjectEchoPzOptCleaner
{
    private const string Marker = "PROJECT_ECHO_PZOPT_CLEANER_20261025";
    private static readonly StringComparer PathComparer = StringComparer.OrdinalIgnoreCase;

    public static void Attach(Window owner)
    {
        // The launcher layout changes often. Insert next to the existing game-folder input
        // without modifying MainWindow.xaml or changing unrelated buttons.
        if (owner.FindName("GameFolderBox") is not FrameworkElement anchor)
            return; // fail closed on unknown UI rather than replacing other controls
        var button = new Button
        {
            Content = "ПРОВЕРИТЬ / ОЧИСТИТЬ PZ OPT",
            Tag = Marker,
            Margin = new Thickness(7, 6, 7, 6),
            Padding = new Thickness(14, 9, 14, 9),
            Background = new SolidColorBrush(Color.FromRgb(32, 50, 57)),
            Foreground = Brushes.White,
            BorderBrush = new SolidColorBrush(Color.FromRgb(109, 149, 137)),
            ToolTip = "Поиск хвостов PZ Optimization; удаление только после подтверждения, с карантином",
            HorizontalAlignment = HorizontalAlignment.Left,
            MinWidth = 250
        };
        button.Click += (_, _) =>
        {
            var tb = owner.FindName("GameFolderBox") as TextBox;
            var dialog = new CleanerDialog(owner, tb?.Text ?? "");
            dialog.ShowDialog();
        };

        DependencyObject? child = anchor;
        while (child is not null)
        {
            var parent = VisualTreeHelper.GetParent(child);
            if (parent is StackPanel stack && child is UIElement childUi)
            {
                if (stack.Children.OfType<Button>().Any(b => Equals(b.Tag, Marker))) return;
                int pos = stack.Children.IndexOf(childUi);
                stack.Children.Insert(Math.Max(0, pos + 1), button);
                return;
            }
            child = parent;
        }
        // Avoid guessing where to insert a control in an arbitrary Grid: use a clearly
        // visible button in the main window's overlay, without changing grid row indices.
        if (owner.Content is Panel mainPanel)
        {
            button.HorizontalAlignment = HorizontalAlignment.Right;
            button.VerticalAlignment = VerticalAlignment.Bottom;
            button.Margin = new Thickness(8, 8, 18, 80);
            Panel.SetZIndex(button, 2000);
            mainPanel.Children.Add(button);
        }
    }

    private sealed class Entry(string source, string category, string reason, bool folder)
    {
        public string Source { get; } = source;
        public string Category { get; } = category; // Game or User
        public string Reason { get; } = reason;
        public bool Folder { get; } = folder;
    }
    private sealed class ScanResult
    {
        public List<Entry> Safe { get; } = new();
        public List<string> Review { get; } = new();
        public List<string> JsonChanges { get; } = new();
        public bool JsonNeedsChange => JsonChanges.Count != 0;
        public string Root { get; init; } = "";
        public string JsonPath => Path.Combine(Root, "ProjectZomboid64.json");
        public string UserRoot => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Zomboid");
        public bool HasWork => Safe.Count > 0 || JsonNeedsChange;
    }

    private static string Full(string path) => Path.GetFullPath(path.Trim().Trim('"').TrimEnd('\\', '/'));
    private static bool Inside(string baseDir, string path) =>
        Full(path).StartsWith(Full(baseDir) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);

    private static bool Reparse(string path)
    {
        try { return (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0; }
        catch { return true; }
    }

    private static bool HasReparseAncestor(string root, string path)
    {
        try
        {
            var p = Path.GetDirectoryName(Path.GetFullPath(path));
            while (p is not null && Inside(root, p))
            {
                if (Reparse(p)) return true;
                p = Path.GetDirectoryName(p);
            }
            return Reparse(root);
        }
        catch { return true; }
    }

    private static bool ContainsReparsePoints(string folder)
    {
        try
        {
            var pending = new Stack<string>();
            pending.Push(folder);
            while (pending.Count > 0)
            {
                var current = pending.Pop();
                if (Reparse(current)) return true;
                foreach (var item in Directory.EnumerateFileSystemEntries(current))
                {
                    if (Reparse(item)) return true;
                    if (Directory.Exists(item)) pending.Push(item);
                }
            }
            return false;
        }
        catch { return true; }
    }

    private static bool ValidGameRoot(string dir) =>
        Directory.Exists(dir) && File.Exists(Path.Combine(dir, "projectzomboid.jar")) &&
        File.Exists(Path.Combine(dir, "ProjectZomboid64.json"));

    private static bool IsGameRunning()
    {
        try
        {
            return Process.GetProcesses().Any(p =>
            {
                var name = p.ProcessName;
                return name.Equals("ProjectZomboid64", StringComparison.OrdinalIgnoreCase) ||
                       name.Equals("ProjectZomboid", StringComparison.OrdinalIgnoreCase);
            });
        }
        catch { return true; } // no changes if process inspection fails
    }

    private static string Sha(string file)
    {
        using var sha = SHA256.Create();
        using var stream = File.OpenRead(file);
        return Convert.ToHexString(sha.ComputeHash(stream)).ToLowerInvariant();
    }

    private static bool IsSafeRelative(string relative)
    {
        string x = relative.Replace('\\', '/').Trim();
        if (string.IsNullOrWhiteSpace(x) || x.Contains(':') || x.StartsWith('/') ||
            x.Split('/').Any(s => s is "." or ".." || s.Length == 0)) return false;
        if (x.Equals("projectzomboid.jar", StringComparison.OrdinalIgnoreCase) ||
            x.Equals("ProjectZomboid64.json", StringComparison.OrdinalIgnoreCase)) return false;
        return new[] { "zombie/", "org/", "se/", "fmod/", "natives/", "media/", "pzopt/" }
            .Any(prefix => x.StartsWith(prefix, StringComparison.OrdinalIgnoreCase));
    }

    private static string? ResolveGameFile(string root, string relative)
    {
        if (!IsSafeRelative(relative)) return null;
        var file = Path.GetFullPath(Path.Combine(root, relative.Replace('/', Path.DirectorySeparatorChar)));
        return Inside(root, file) ? file : null;
    }

    private static IEnumerable<string> ManifestRows(string path)
    {
        if (!File.Exists(path)) yield break;
        foreach (var line in File.ReadLines(path))
        {
            var s = line.Trim();
            if (s.Length > 0 && !s.StartsWith('#')) yield return s;
        }
    }

    private static bool IsHexSha(string value) => value.Length == 64 && value.All(Uri.IsHexDigit);

    private static ScanResult Scan(string root)
    {
        var result = new ScanResult { Root = root };
        var known = new HashSet<string>(PathComparer);
        void AddKnown(string absolute, string category, string why)
        {
            if (!File.Exists(absolute) && !Directory.Exists(absolute)) return;
            if (Reparse(absolute) || HasReparseAncestor(category == "Game" ? root : result.UserRoot, absolute) ||
                (Directory.Exists(absolute) && ContainsReparsePoints(absolute)))
            { result.Review.Add("SYMLINK/JUNCTION (skip): " + absolute); return; }
            if (known.Add(absolute)) result.Safe.Add(new Entry(absolute, category, why, Directory.Exists(absolute)));
        }
        foreach (var name in new[] {
            "pzopt", "pzopt-installed.txt", "pzopt-files.txt", "pzopt.properties",
            "Uninstall-PZ-Optimization.cmd", "uninstall-pz-optimization.bash",
            "ProjectZomboid64.json.pzopt-backup", "ProjectZomboid64.json.pzopt-tmp",
            @"media\lua\client\pzopt", @"media\lua\shared\pzopt", @"media\lua\server\pzopt",
            @"zombie\pzopt"
        }) AddKnown(Path.Combine(root, name), "Game", "Recognized PZOpt path");
        var user = result.UserRoot;
        foreach (var name in new[] { "pzopt", @"Lua\pzopt-boot-repair.txt" })
            AddKnown(Path.Combine(user, name), "User", "PZOpt user cache / note");

        // Manifest lines are not enough: a different Java patch may have overwritten the file.
        // Only quarantine a class if the installed bytes still match the manifest's hash.
        string manifest = Path.Combine(root, "pzopt-installed.txt");
        foreach (var row in ManifestRows(manifest))
        {
            var fields = row.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries);
            var path = ResolveGameFile(root, fields[0]);
            if (path is null || !File.Exists(path) || known.Contains(path)) continue;
            if (Reparse(path) || HasReparseAncestor(root, path)) { result.Review.Add("SYMLINK: " + path); continue; }
            if (fields.Length > 1 && IsHexSha(fields[1]) &&
                Sha(path).Equals(fields[1], StringComparison.OrdinalIgnoreCase))
                AddKnown(path, "Game", "PZOpt manifest SHA-256 verified");
            else result.Review.Add("Unverified/changed file - preserved: " + path);
        }

        // For hand-copied installs, compare files with the Steam Workshop copy, never
        // remove ambiguous Minidoracat/other .class files by filename alone.
        string workshop = Path.GetFullPath(Path.Combine(root, "..", "..", "workshop", "content", "108600",
            "3805285544", "mods", "PZ_Optimization"));
        if (Directory.Exists(workshop))
        {
            foreach (var list in Directory.EnumerateFiles(workshop, "pzopt-files.txt", SearchOption.AllDirectories).Take(12))
            {
                string baseFolder = Path.GetDirectoryName(list)!;
                foreach (var row in ManifestRows(list).Take(3000))
                {
                    var rel = row.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries)[0];
                    var target = ResolveGameFile(root, rel);
                    var original = ResolveGameFile(baseFolder, rel);
                    if (target is null || original is null || known.Contains(target) ||
                        !File.Exists(target) || !File.Exists(original) || Reparse(target) ||
                        HasReparseAncestor(root, target)) continue;
                    if (Sha(target) == Sha(original))
                        AddKnown(target, "Game", "Byte-identical to PZOpt Workshop source");
                    else result.Review.Add("Class differs from Workshop PZOpt - preserved: " + target);
                }
            }
        }
        // Track old no-hash manifests without deleting unrelated Java mods.
        foreach (var row in ManifestRows(Path.Combine(root, "pzopt-files.txt")))
        {
            var rel = row.Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries)[0];
            var path = ResolveGameFile(root, rel);
            if (path != null && File.Exists(path) && !known.Contains(path))
                result.Review.Add("No verified ownership - preserved: " + path);
        }

        if (File.Exists(result.JsonPath))
        {
            try { BuildCleanJson(File.ReadAllText(result.JsonPath), result.JsonChanges); }
            catch (Exception ex) { result.Review.Add("Cannot parse launcher JSON: " + ex.Message); }
        }
        result.Review.Sort(StringComparer.OrdinalIgnoreCase);
        return result;
    }

    private static string BuildCleanJson(string text, List<string> changes)
    {
        var json = JsonNode.Parse(text) as JsonObject ?? throw new InvalidDataException("Invalid launcher JSON");
        if (json["vmArgs"] is JsonArray args)
        {
            var original = args.Select(x => x?.GetValue<string>() ?? "").ToArray();
            var gcMarker = original.Any(s => s.StartsWith("-Dpzopt.gc=g1", StringComparison.OrdinalIgnoreCase));
            var clean = new List<string>();
            foreach (var arg in original)
            {
                bool remove = arg.StartsWith("-Dpzopt.", StringComparison.OrdinalIgnoreCase) ||
                    arg.StartsWith("-Dpzoptpreloader.", StringComparison.OrdinalIgnoreCase) ||
                    arg.Equals("-Xlog:aot=info", StringComparison.OrdinalIgnoreCase) ||
                    arg.StartsWith("-Xlog:aot=info:file=pzopt/aot/", StringComparison.OrdinalIgnoreCase) ||
                    arg.StartsWith("-XX:AOTCache", StringComparison.OrdinalIgnoreCase) ||
                    arg.Equals("-XX:-AOTInvokeDynamicLinking", StringComparison.OrdinalIgnoreCase);
                if (remove) { changes.Add("VM: " + arg); continue; }
                if (gcMarker && arg == "-XX:+UseG1GC")
                { clean.Add("-XX:+UseZGC"); changes.Add("GC: restore ZGC from PZOpt G1 marker"); }
                else clean.Add(arg);
            }
            if (clean.Count != original.Length || changes.Count > 0)
            {
                args.Clear();
                foreach (string s in clean) args.Add(s);
            }
        }
        if (json["classpath"] is JsonArray cp)
        {
            var original = cp.Select(x => x?.GetValue<string>() ?? "").ToList();
            var clean = original.Where(s => !s.Replace('\\', '/').Equals("pzopt/aot/pzopt.jar", StringComparison.OrdinalIgnoreCase)).ToList();
            if (clean.Count < original.Count)
            {
                changes.Add("Classpath: pzopt/aot/pzopt.jar");
                if (!clean.Contains(".")) clean.Insert(0, ".");
                cp.Clear(); foreach (var x in clean) cp.Add(x);
            }
        }
        return json.ToJsonString(new JsonSerializerOptions { WriteIndented = true });
    }

    private static string QuarantineFile(Entry entry, string root, string userRoot, string quarantine)
    {
        string basedir = entry.Category == "Game" ? root : userRoot;
        string rel = Path.GetRelativePath(basedir, entry.Source);
        if (rel.StartsWith("..") || Path.IsPathRooted(rel) || Reparse(entry.Source) ||
            HasReparseAncestor(basedir, entry.Source))
            throw new IOException("Unsafe source path: " + entry.Source);
        string target = Path.Combine(quarantine, entry.Category, rel);
        void BackupAndRemoveFile(string src, string dst)
        {
            if (Reparse(src)) throw new IOException("Symlink skipped: " + src);
            Directory.CreateDirectory(Path.GetDirectoryName(dst)!);
            File.Copy(src, dst, false);
            if (Sha(src) != Sha(dst)) throw new IOException("Backup hash mismatch: " + src);
            File.Delete(src);
        }
        if (!entry.Folder) { BackupAndRemoveFile(entry.Source, target); return rel; }
        var files = Directory.EnumerateFiles(entry.Source, "*", SearchOption.AllDirectories).ToArray();
        foreach (var item in files)
        {
            var dest = Path.Combine(target, Path.GetRelativePath(entry.Source, item));
            BackupAndRemoveFile(item, dest);
        }
        // Only empty dirs removed; never remove a child junction unexpectedly.
        foreach (var folder in Directory.EnumerateDirectories(entry.Source, "*", SearchOption.AllDirectories)
                     .OrderByDescending(x => x.Length))
            if (!Reparse(folder) && !Directory.EnumerateFileSystemEntries(folder).Any()) Directory.Delete(folder);
        if (!Directory.EnumerateFileSystemEntries(entry.Source).Any()) Directory.Delete(entry.Source);
        return rel;
    }

    private static string Clean(ScanResult scan)
    {
        if (IsGameRunning()) throw new InvalidOperationException("Закрой Project Zomboid перед удалением хвостов.");
        var refreshed = Scan(scan.Root); // do not trust a stale preview
        var baseDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "ProjectEcho", "PzOptQuarantine", DateTime.Now.ToString("yyyyMMdd_HHmmss_fff"));
        Directory.CreateDirectory(baseDir);
        var log = new List<string> { "PROJECT ECHO / PZ OPT CLEANUP", "Game: " + scan.Root,
            "Quarantine: " + baseDir, "Timestamp: " + DateTime.Now.ToString("O"), "" };
        if (refreshed.JsonNeedsChange)
        {
            try
            {
                string path = refreshed.JsonPath;
                string original = File.ReadAllText(path);
                var jsonChanges = new List<string>();
                string updated = BuildCleanJson(original, jsonChanges);
                var backup = Path.Combine(baseDir, "Game", "ProjectZomboid64.json.before-cleanup");
                Directory.CreateDirectory(Path.GetDirectoryName(backup)!);
                File.Copy(path, backup, false);
                File.WriteAllText(path + ".pe-pzopt.tmp", updated, new UTF8Encoding(false));
                // Atomic replacement on the same drive with the original preserved in quarantine.
                File.Move(path + ".pe-pzopt.tmp", path, overwrite: true);
                log.Add("JSON CLEANED: " + path);
                log.AddRange(jsonChanges.Select(s => "  " + s));
            }
            catch (Exception ex) { log.Add("ERROR JSON: " + ex.Message); }
        }
        // Directory entries first, to avoid partially handling their children twice.
        foreach (var entry in refreshed.Safe.OrderByDescending(x => x.Folder).ThenBy(x => x.Source.Length))
        {
            if (!File.Exists(entry.Source) && !Directory.Exists(entry.Source)) continue;
            if (refreshed.Safe.Any(p => p != entry && p.Folder && Inside(p.Source, entry.Source))) continue;
            try { QuarantineFile(entry, refreshed.Root, refreshed.UserRoot, baseDir);
                log.Add("QUARANTINED: " + entry.Source + " (" + entry.Reason + ")"); }
            catch (Exception ex) { log.Add("ERROR: " + entry.Source + " -> " + ex.Message); }
        }
        log.Add(""); log.Add("PRESERVED / MANUAL REVIEW:");
        log.AddRange(refreshed.Review.DefaultIfEmpty("None"));
        log.Add(""); log.Add("Steam Workshop files, ProjectZomboid.jar, Minidoracat classes, saves and server untouched.");
        log.Add("RESTORE: copy files from Quarantine\\Game to game root, Quarantine\\User to ~/Zomboid.");
        log.Add("For launcher JSON restore ProjectZomboid64.json.before-cleanup to ProjectZomboid64.json.");
        string report = Path.Combine(baseDir, "CLEANUP_REPORT.txt");
        File.WriteAllLines(report, log, new UTF8Encoding(true));
        return report;
    }

    private sealed class CleanerDialog : Window
    {
        private readonly TextBox _folder;
        private readonly TextBox _output;
        private readonly Button _remove;
        private ScanResult? _scan;
        public CleanerDialog(Window owner, string gameFolder)
        {
            Owner = owner; Title = "PROJECT ECHO | Очистка PZ OPTIMIZATION";
            Width = 840; Height = 640; MinWidth = 650; MinHeight = 440;
            WindowStartupLocation = WindowStartupLocation.CenterOwner;
            Background = new SolidColorBrush(Color.FromRgb(18, 25, 31));
            Foreground = Brushes.White;
            var panel = new DockPanel { Margin = new Thickness(20) };
            Content = panel;
            var top = new StackPanel();
            DockPanel.SetDock(top, Dock.Top); panel.Children.Add(top);
            top.Children.Add(new TextBlock { Text = "Поиск хвостов PZ_Optimization / PZ Opt", FontSize = 21,
                FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 0, 0, 10) });
            top.Children.Add(new TextBlock { Text = "Путь к игре (папка с projectzomboid.jar):",
                Margin = new Thickness(0, 3, 0, 6) });
            _folder = new TextBox { Text = gameFolder, Margin = new Thickness(0, 0, 0, 12), Padding = new Thickness(7) };
            top.Children.Add(_folder);
            _folder.TextChanged += (_, _) => { if (_remove != null) _remove.IsEnabled = false; };
            var actions = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 12) };
            top.Children.Add(actions);
            Button Make(string title)
            {
                var b = new Button { Content = title, Margin = new Thickness(0, 0, 12, 0), Padding = new Thickness(17, 9, 17, 9) };
                actions.Children.Add(b); return b;
            }
            var scanButton = Make("1. ПРОВЕРИТЬ");
            _remove = Make("2. УБРАТЬ В КАРАНТИН"); _remove.IsEnabled = false;
            scanButton.Click += (_, _) => ScanNow();
            _remove.Click += (_, _) => CleanNow();
            top.Children.Add(new TextBlock { Text = "Подозрительные Java-классы без подтверждения владельца не удаляются.",
                Foreground = new SolidColorBrush(Color.FromRgb(193, 203, 208)), Margin = new Thickness(0, 0, 0, 13), TextWrapping = TextWrapping.Wrap });
            _output = new TextBox { IsReadOnly = true, FontFamily = new FontFamily("Consolas"), FontSize = 12,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
                TextWrapping = TextWrapping.NoWrap,
                Background = new SolidColorBrush(Color.FromRgb(23, 34, 40)), Foreground = Brushes.White,
                BorderThickness = new Thickness(1), Padding = new Thickness(12) };
            panel.Children.Add(_output);
            _output.Text = "Нажми ПРОВЕРИТЬ. Пока ничего не удалено.";
        }
        private void ScanNow()
        {
            try
            {
                string root = Full(_folder.Text);
                if (!ValidGameRoot(root)) throw new IOException("Не найдены projectzomboid.jar и ProjectZomboid64.json в указанной папке.");
                _scan = Scan(root);
                var lines = new List<string> { "ИГРА: " + root, "", "В КАРАНТИН (" + _scan.Safe.Count + "):" };
                lines.AddRange(_scan.Safe.Select(x => "  [OK] " + x.Source + " | " + x.Reason));
                lines.Add(""); lines.Add("JAVA-ПАРАМЕТРЫ НА УДАЛЕНИЕ (" + _scan.JsonChanges.Count + "):");
                lines.AddRange(_scan.JsonChanges.Select(x => "  " + x));
                lines.Add(""); lines.Add("ОСТАВИТЬ / ПРОВЕРИТЬ ВРУЧНУЮ (" + _scan.Review.Count + "):");
                lines.AddRange(_scan.Review.Select(x => "  " + x));
                if (!_scan.HasWork) lines.Add("\nЧистых остатков не найдено. Это не доказывает отсутствие конфликтов модов.");
                _output.Text = string.Join(Environment.NewLine, lines);
                _remove.IsEnabled = _scan.HasWork;
            }
            catch (Exception ex) { _scan = null; _remove.IsEnabled = false;
                _output.Text = "ОШИБКА: " + ex.Message; }
        }
        private void CleanNow()
        {
            if (_scan is null) return;
            if (IsGameRunning()) { MessageBox.Show(this, "Сначала полностью закрой Project Zomboid.",
                "Очистка заблокирована", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
            var decision = MessageBox.Show(this,
                "Переместить ТОЛЬКО проверенные остатки PZOpt в карантин?\n" +
                "Файлы Java без доказанного владельца сохранятся.\n" +
                "Будет создан отчёт и резервная копия изменённого JSON.",
                "PROJECT ECHO — подтверждение", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (decision != MessageBoxResult.Yes) return;
            try
            {
                string report = Clean(_scan);
                _remove.IsEnabled = false;
                _output.Text = "Процедура завершена. Проверь ошибки и оставленные файлы в отчёте.\nОтчёт и резервные копии:\n" + report +
                    "\n\nОткрой отчёт, затем запусти игру и проверь новый console.txt.";
                try { Process.Start(new ProcessStartInfo { FileName = "notepad.exe", Arguments = "\"" + report + "\"", UseShellExecute = true }); }
                catch { /* path shown above */ }
            }
            catch (Exception ex) { _output.Text = "ОШИБКА ПРИ ОЧИСТКЕ: " + ex + "\nПроверь карантин и отчёт."; }
        }
    }
}
