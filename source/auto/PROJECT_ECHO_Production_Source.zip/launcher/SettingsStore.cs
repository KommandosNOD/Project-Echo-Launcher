using System.Text.Json;
namespace PZLauncher;
internal static class SettingsStore
{
#if ECHO_RELEASE_CANDIDATE
    internal static readonly string StateRoot = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PROJECT_ECHO_RC_CLIENT_ONLY");
#elif ECHO_STAGING_CLIENT
    internal static readonly string StateRoot = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PROJECT_ECHO_STAGING_CLIENT_ONLY");
#elif ECHO_TEST_CLIENT
    internal static readonly string StateRoot = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PROJECT_ECHO_TEST_CLIENT_ONLY");
#else
    internal static readonly string StateRoot = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "PZCommunityLauncher");
#endif
    private static readonly string SettingsFile = System.IO.Path.Combine(StateRoot, "settings.json");
    public static LocalSettings Load()
    {
        try { return ManifestSource.Migrate(JsonSerializer.Deserialize<LocalSettings>(File.ReadAllText(SettingsFile)) ?? new()); }
        catch (IOException) { return new(); }
        catch (System.Text.Json.JsonException) { return new(); }
        catch (UnauthorizedAccessException) { return new(); }
    }
    public static void Save(LocalSettings settings)
    {
        settings.ManifestUrl = ManifestSource.Normalize(settings.ManifestUrl);
        Directory.CreateDirectory(StateRoot);
        var file = SettingsFile + ".tmp";
        File.WriteAllText(file, JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true }));
        File.Move(file, SettingsFile, true);
    }
}
