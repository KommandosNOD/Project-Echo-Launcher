using System.Text.Json.Serialization;
namespace PZLauncher;
public sealed class ReleaseManifest
{
    [JsonPropertyName("schema")] public int Schema { get; set; }
    [JsonPropertyName("kind")] public string Kind { get; set; } = "";
    [JsonPropertyName("retired")] public List<PatchFile> Retired { get; set; } = new();
    [JsonPropertyName("channel")] public string Channel { get; set; } = "";
    [JsonPropertyName("version")] public string Version { get; set; } = "";
    [JsonPropertyName("title")] public string Title { get; set; } = "";
    [JsonPropertyName("notes")] public string Notes { get; set; } = "";
    [JsonPropertyName("gameBuild")] public string GameBuild { get; set; } = "";
    [JsonPropertyName("server")] public ServerEntry Server { get; set; } = new();
    [JsonPropertyName("files")] public List<PatchFile> Files { get; set; } = new();
}
public sealed class ServerEntry
{
    [JsonPropertyName("name")] public string Name { get; set; } = "";
    [JsonPropertyName("host")] public string Host { get; set; } = "";
    [JsonPropertyName("port")] public int Port { get; set; } = 16261;
    [JsonPropertyName("enabled")] public bool Enabled { get; set; }
}
public sealed class PatchFile
{
    [JsonPropertyName("path")] public string Path { get; set; } = "";
    [JsonPropertyName("url")] public string Url { get; set; } = "";
    [JsonPropertyName("sha256")] public string Sha256 { get; set; } = "";
    [JsonPropertyName("size")] public long Size { get; set; }
}
public sealed record UpdatePlan(ReleaseManifest Manifest, Uri ManifestUri, IReadOnlyList<PatchFile> Changed);
public sealed class LocalSettings
{
#if ECHO_RELEASE_CANDIDATE
    public string ManifestUrl { get; set; } = ManifestSource.DefaultUrl;
#elif ECHO_STAGING_CLIENT
    public string ManifestUrl { get; set; } = ManifestSource.DefaultUrl;
#else
    public string ManifestUrl { get; set; } = ManifestSource.DefaultUrl;
#endif
    public string HostOverride { get; set; } = "26.137.250.18";
    public int PortOverride { get; set; } = 16261;
    public bool AutoInstall { get; set; } = false; // Legacy setting; upgrades now always require consent.
    public bool AutoResolveServer { get; set; } = false;
    public string GameFolder { get; set; } = "";
    public string AccountUsername { get; set; } = "";
    public bool RememberPassword { get; set; } = false;
}
