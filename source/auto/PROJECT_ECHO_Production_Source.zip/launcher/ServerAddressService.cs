namespace PZLauncher;

public sealed record LiveServerAddress(string Host, int Port, DateTimeOffset ReportedAt);

public sealed class ServerAddressService : IDisposable
{
    // Fixed PROJECT ECHO Radmin VPN address. No Cloudflare auto-IP request.
    internal const string FixedHost = "26.137.250.18";
    internal const int FixedPort = 16261;

    public Task<LiveServerAddress> ResolveAsync(CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();
        // ReportedAt is informational only: it does NOT imply that the server is online.
        return Task.FromResult(new LiveServerAddress(FixedHost, FixedPort, DateTimeOffset.MinValue));
    }

    public void Dispose() { }
}
