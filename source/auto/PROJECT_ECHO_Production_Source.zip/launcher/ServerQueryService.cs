using System;
using System.Buffers.Binary;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PZLauncher;

// Steam server query protocol (A2S_INFO). The Project Zomboid game port
// (normally UDP 16261) handles Steam queries. Requires Radmin VPN access.
internal readonly record struct ServerQueryResult(bool IsOnline, int Players, int MaxPlayers);

internal sealed class ServerQueryService
{
    private static readonly byte[] Request =
        [0xff, 0xff, 0xff, 0xff, 0x54, .. Encoding.ASCII.GetBytes("Source Engine Query\0")];

    internal async Task<ServerQueryResult> QueryAsync(string host, int queryPort)
    {
        using var timer = new CancellationTokenSource(TimeSpan.FromSeconds(4));
        using var udp = new UdpClient(AddressFamily.InterNetwork);
        udp.Connect(IPAddress.Parse(host), queryPort);
        try
        {
            await udp.SendAsync(Request, timer.Token);
            var data = (await udp.ReceiveAsync(timer.Token)).Buffer;
            if (data.Length >= 9 && IsHeader(data, 0x41))
            {
                // Newer Steam query servers require a challenge to prevent reflection.
                byte[] challenged = new byte[Request.Length + 4];
                Request.CopyTo(challenged, 0);
                data.AsSpan(5, 4).CopyTo(challenged.AsSpan(Request.Length));
                await udp.SendAsync(challenged, timer.Token);
                data = (await udp.ReceiveAsync(timer.Token)).Buffer;
            }
            return TryReadInfo(data, out var players, out var maximum)
                ? new ServerQueryResult(true, players, maximum)
                : new ServerQueryResult(false, 0, 0);
        }
        catch (OperationCanceledException) { return new ServerQueryResult(false, 0, 0); }
        catch (SocketException) { return new ServerQueryResult(false, 0, 0); }
    }

    private static bool IsHeader(byte[] data, byte responseType) =>
        data.Length >= 5 && data[0] == 0xff && data[1] == 0xff &&
        data[2] == 0xff && data[3] == 0xff && data[4] == responseType;

    private static bool TryReadInfo(byte[] data, out int players, out int maximum)
    {
        players = 0;
        maximum = 0;
        if (!IsHeader(data, 0x49)) return false;
        int i = 6; // 4 x 0xFF, 0x49 response type, protocol version
        // Server name, map, folder and game name are null-terminated strings.
        for (int n = 0; n < 4; n++)
        {
            while (i < data.Length && data[i] != 0) i++;
            if (i >= data.Length) return false;
            i++;
        }
        // App ID is a little-endian ushort, then player and max-player bytes.
        if (i + 4 > data.Length) return false;
        ushort appId = BinaryPrimitives.ReadUInt16LittleEndian(data.AsSpan(i, 2));
        if (appId != 108600 && appId != 380870) return false;
        players = data[i + 2];
        maximum = data[i + 3];
        if (maximum <= 0 || players > maximum) return false;
        return true;
    }
}
