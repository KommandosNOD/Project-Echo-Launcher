using System.Windows;
namespace PZLauncher;
public partial class App : Application { }
