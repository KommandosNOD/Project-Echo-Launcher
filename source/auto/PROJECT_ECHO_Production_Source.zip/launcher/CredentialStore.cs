using System.Security.Cryptography;
using System.Text;
namespace PZLauncher;

// Passwords never reach Cloudflare and are not inserted into Steam URLs.
internal static class CredentialStore
{
    private static readonly string FilePath = Path.Combine(SettingsStore.StateRoot, "credentials.dat");
    private static readonly byte[] Scope = Encoding.UTF8.GetBytes("PROJECT-ECHO:PZ-SERVER-CREDENTIALS:V1");
    public static void Save(string password)
    {
        Directory.CreateDirectory(SettingsStore.StateRoot);
        if (string.IsNullOrEmpty(password)) { Delete(); return; }
        var plaintext = Encoding.UTF8.GetBytes(password);
        try
        {
            var ciphertext = ProtectedData.Protect(plaintext, Scope, DataProtectionScope.CurrentUser);
            File.WriteAllBytes(FilePath + ".tmp", ciphertext);
            File.Move(FilePath + ".tmp", FilePath, true);
        }
        finally { CryptographicOperations.ZeroMemory(plaintext); }
    }
    public static string? Load()
    {
        if (!File.Exists(FilePath)) return null;
        var plaintext = ProtectedData.Unprotect(File.ReadAllBytes(FilePath), Scope, DataProtectionScope.CurrentUser);
        try { return Encoding.UTF8.GetString(plaintext); }
        finally { CryptographicOperations.ZeroMemory(plaintext); }
    }
    public static void Delete() { if (File.Exists(FilePath)) File.Delete(FilePath); }
}
