using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace PZLauncher;

public partial class MainWindow
{
    // This right-click command works without changes to MainWindow.xaml.
    private void InitializeSettingsSyncUi()
    {
        var menu = PlayButton.ContextMenu ?? new ContextMenu();
        var item = new MenuItem { Header = "PROJECT ECHO: применить профиль графики и управления..." };
        item.Click += (_, _) => ConfirmAndApplyEchoSettings(force: true);
        menu.Items.Add(item);
        PlayButton.ContextMenu = menu;
    }

    private bool ConfirmAndApplyEchoSettings(bool force = false)
    {
#if ECHO_RELEASE_CANDIDATE
        if (force) MessageBox.Show("В RC синхронизация пользовательских настроек отключена.", "PROJECT ECHO RC");
        return true;
#else
        try
        {
            var profile = EchoSettingsSync.LoadProfile();
            if (profile is null) return true; // No signed profile published yet.
            if (!force && EchoSettingsSync.AlreadyHandled(profile)) return true;
            var answer = MessageBox.Show(
                "Опубликован профиль настроек PROJECT ECHO: " + profile.Version + "\n\n" +
                "Применить графический профиль владельца PROJECT ECHO?\n" +
                "Настройки Viewpoint и клавиатуры будут запрошены отдельно.\n" +
                "Разрешение, звук и язык останутся твоими.\n" +
                "Перед изменениями будут созданы резервные копии.\n\n" +
                "Да — применить; Нет — пропустить эту версию; Отмена — не запускать игру.",
                "PROJECT ECHO — синхронизация настроек", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
            if (answer == MessageBoxResult.Cancel) return false;
            if (answer == MessageBoxResult.No)
            {
                EchoSettingsSync.MarkHandled(profile, skipped: true);
                return true;
            }
            bool keys = false, modOptions = false, viewpoint = false;
            if (profile.ViewpointFiles.Count > 0)
                viewpoint = MessageBox.Show(
                    "Найдено " + profile.ViewpointFiles.Count + " файлов настроек Viewpoint.\n" +
                    "Применить их? Это может изменить камеру и клавиши Viewpoint.\n" +
                    "Для каждого файла будет сделана резервная копия.",
                    "PROJECT ECHO — Viewpoint", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes;
            if (!string.IsNullOrWhiteSpace(profile.KeybindingsBase64))
                keys = MessageBox.Show(
                    "Применить также назначения клавиш владельца?\n\n" +
                    "Это заменит твой keysB42.ini. Настройки контроллера могут отличаться.\n" +
                    "Можно отказаться — графика и Viewpoint всё равно обновятся.",
                    "PROJECT ECHO — клавиши", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes;
            if (!string.IsNullOrWhiteSpace(profile.ModOptionsBase64))
                modOptions = MessageBox.Show(
                    "Применить все настройки модов владельца?\n\n" +
                    "Это заменит mods_options.ini, включая персональные настройки других модов.\n" +
                    "Обычно лучше выбрать НЕТ.",
                    "PROJECT ECHO — настройки модов", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes;
            var backup = EchoSettingsSync.Apply(profile, keys, modOptions, viewpoint);
            EchoSettingsSync.MarkHandled(profile, skipped: false);
            StatusText.Text = "Профиль настроек PROJECT ECHO применён.";
            MessageBox.Show("Настройки обновлены.\nРезервная копия: " + backup,
                "PROJECT ECHO", MessageBoxButton.OK, MessageBoxImage.Information);
            return true;
        }
        catch (Exception ex)
        {
            MessageBox.Show("Не удалось безопасно применить настройки:\n" + ex.Message +
                "\n\nЗапуск остановлен. Исходные настройки не должны быть утрачены: проверь папку резервных копий.",
                "PROJECT ECHO — ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            return false;
        }
#endif
    }
}
