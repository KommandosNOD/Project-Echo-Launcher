using System;

namespace PZLauncher;

// PROJECT_ECHO_MANIFEST_URL_FIX_V1
internal static class ManifestSource
{
    // The only official signed patch source. This is distinct from the GitHub EXE download.
#if ECHO_RELEASE_CANDIDATE
    // RC verifies the real signed schema2 implementation against the TEST channel.
    internal const string DefaultUrl = "https://raw.githubusercontent.com/KommandosNOD/Project-Echo-Launcher/project-echo-schema2-staging/updates/schema2-staging/manifest.json";
#elif ECHO_STAGING_CLIENT
    // Exact GitHub STAGING channel; production endpoint is forbidden in this build.
    internal const string DefaultUrl = "https://raw.githubusercontent.com/KommandosNOD/Project-Echo-Launcher/project-echo-schema2-staging/updates/schema2-staging/manifest.json";
#elif ECHO_TEST_CLIENT
    internal const string DefaultUrl = "http://127.0.0.1:8765/manifest.json";
#else
    internal const string DefaultUrl = "https://raw.githubusercontent.com/KommandosNOD/Project-Echo-Launcher/project-echo-schema2-production/updates/schema2-staging/manifest.json";
#endif

    internal static LocalSettings Migrate(LocalSettings settings)
    {
        settings.ManifestUrl = Normalize(settings.ManifestUrl);
        return settings;
    }

    internal static string Normalize(string? candidate)
    {
#if ECHO_STAGING_CLIENT || ECHO_RELEASE_CANDIDATE || ECHO_PRODUCTION_CLIENT
        // RC: the one visible URL never changes. The updater internally
        // resolves its current HEAD and then pins the full download to that SHA.
        return DefaultUrl;
#elif ECHO_TEST_CLIENT
        if (Uri.TryCreate(candidate, UriKind.Absolute, out var local) &&
            local.Scheme == Uri.UriSchemeHttp && local.IsLoopback && local.Port == 8765 &&
            local.AbsolutePath == "/manifest.json" && local.UserInfo.Length == 0 &&
            local.Query.Length == 0 && local.Fragment.Length == 0)
            return local.AbsoluteUri;
        return DefaultUrl;
#else
        // The production channel is pinned to an owner-signed snapshot on GitHub.
        return DefaultUrl;
#endif
    }
}
