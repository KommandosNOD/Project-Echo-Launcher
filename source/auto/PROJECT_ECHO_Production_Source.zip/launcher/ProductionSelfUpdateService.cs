// PROJECT_ECHO_SIGNED_production_SELFUPDATE v0.3.1 - known-good worker, handshake and trace
// production ONLY: separate signed EXE stream, completely isolated from game/mod updates.
using System;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace PZLauncher;

internal sealed class LauncherSelfUpdateService : IDisposable
{
    private const string BinaryName = "ProjectEchoLauncher.exe";
    private const string WorkerSwitch = "--pe-apply-launcher-update";
    private const long MaxBinaryBytes = 600L * 1024 * 1024;
    private const string RefApi = "https://api.github.com/repos/KommandosNOD/Project-Echo-Launcher/git/ref/heads/project-echo-schema2-production";
    private const string RawPrefix = "https://raw.githubusercontent.com/KommandosNOD/Project-Echo-Launcher/";
    private const string RemoteDirectory = "/updates/launcher-production/";
    private static readonly string StateDir = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "PZCommunityLauncher", "launcher-selfupdate");

    private readonly HttpClient _http = new(new HttpClientHandler { AllowAutoRedirect = true })
    {
        Timeout = TimeSpan.FromMinutes(15)
    };

    internal LauncherSelfUpdateService()
    {
        _http.DefaultRequestHeaders.UserAgent.ParseAdd("ProjectEcho-production-SelfUpdater/0.3.2");
    }

    private sealed record Manifest(
        int schema, string kind, string channel, string version, string tag,
        string asset, long size, string sha256, string createdUtc);

    internal sealed record AvailableUpdate(string Tag, Version Version, long Size, string DownloadUrl, string Sha256);
    internal sealed record PreparedUpdate(string FilePath, string Sha256, string Tag);

    internal static bool RunningAsPublishedLauncher =>
        string.Equals(Path.GetFileName(Environment.ProcessPath), BinaryName,
            StringComparison.OrdinalIgnoreCase);

    internal static string CurrentVersion =>
        Assembly.GetEntryAssembly()?.GetName().Version?.ToString(3) ?? "0.0.0";

    private static async Task<byte[]> ReadBoundedAsync(HttpClient client, Uri url, int max, CancellationToken ct)
    {
        using var response = await client.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, ct);
        if (response.StatusCode != HttpStatusCode.OK)
            throw new HttpRequestException("GitHub production: HTTP " + (int)response.StatusCode);
        if (response.Content.Headers.ContentLength > max)
            throw new InvalidDataException("Слишком большой ответ сервера обновлений.");
        await using var input = await response.Content.ReadAsStreamAsync(ct);
        using var output = new MemoryStream();
        var buffer = new byte[8192];
        int n;
        while ((n = await input.ReadAsync(buffer, ct)) != 0)
        {
            if (output.Length + n > max) throw new InvalidDataException("Ответ GitHub превышает лимит.");
            output.Write(buffer, 0, n);
        }
        return output.ToArray();
    }

    private static void VerifySignature(byte[] content, byte[] signature)
    {
        if (signature.Length is < 16 or > 256) throw new InvalidDataException("Некорректная ECDSA-подпись.");
        using var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("trusted-release-public-key.pem")
            ?? throw new InvalidOperationException("В production-клиенте отсутствует публичный ECDSA-ключ.");
        using var reader = new StreamReader(stream);
        using var key = ECDsa.Create();
        key.ImportFromPem(reader.ReadToEnd());
        if (!key.VerifyData(content, signature, HashAlgorithmName.SHA256, DSASignatureFormat.Rfc3279DerSequence))
            throw new CryptographicException("ПОДПИСЬ EXE-МАНИФЕСТА НЕВЕРНА. Обновление запрещено.");
    }

    private static Manifest ParseManifest(byte[] data)
    {
        var m = JsonSerializer.Deserialize<Manifest>(data) ?? throw new InvalidDataException("Пустой EXE-манифест.");
        if (m.schema != 1 || m.kind != "PROJECT_ECHO_LAUNCHER" || m.channel != "production" ||
            m.asset != BinaryName || !Regex.IsMatch(m.version ?? "", @"^\d+\.\d+\.\d+$") ||
            !Version.TryParse(m.version, out _) || m.tag != "echo-launcher-v" + m.version ||
            m.size is < 1048576 or > MaxBinaryBytes ||
            !Regex.IsMatch(m.sha256 ?? "", "^[a-f0-9]{64}$"))
            throw new InvalidDataException("Недопустимый подписанный production EXE-манифест.");
        return m;
    }

    private static string ReleaseUrl(Manifest m) =>
        "https://github.com/KommandosNOD/Project-Echo-Launcher/releases/download/" +
        m.tag + "/" + BinaryName;

    private async Task<string> HeadCommitAsync(CancellationToken ct)
    {
        using var request = new HttpRequestMessage(HttpMethod.Get,
            RefApi + "?t=" + DateTimeOffset.UtcNow.ToUnixTimeMilliseconds());
        request.Headers.CacheControl = new CacheControlHeaderValue { NoCache = true, NoStore = true };
        using var response = await _http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, ct);
        if (response.StatusCode != HttpStatusCode.OK)
            throw new HttpRequestException("Не удалось получить SHA production-ветки GitHub: HTTP " + (int)response.StatusCode);
        if (response.Content.Headers.ContentLength > 16384)
            throw new InvalidDataException("GitHub вернул слишком большой ответ.");
        var raw = await response.Content.ReadAsByteArrayAsync(ct);
        if (raw.Length > 16384) throw new InvalidDataException("GitHub вернул слишком большой ответ.");
        using var doc = JsonDocument.Parse(raw);
        var sha = doc.RootElement.GetProperty("object").GetProperty("sha").GetString();
        if (!Regex.IsMatch(sha ?? "", "^[0-9a-fA-F]{40}$"))
            throw new InvalidDataException("Неправильный SHA коммита GitHub.");
        return sha!.ToLowerInvariant();
    }

    internal async Task<AvailableUpdate?> CheckAsync(CancellationToken ct = default)
    {
        if (!RunningAsPublishedLauncher) return null;
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
        timeout.CancelAfter(TimeSpan.FromSeconds(45));
        var sha = await HeadCommitAsync(timeout.Token);
        var baseUrl = RawPrefix + sha + RemoteDirectory;
        // No fallback to mutable URLs. 404 is expected before the first EXE release.
        var jsonUri = new Uri(baseUrl + "launcher.json");
        using var response = await _http.GetAsync(jsonUri, HttpCompletionOption.ResponseHeadersRead, timeout.Token);
        if (response.StatusCode == HttpStatusCode.NotFound) return null;
        if (response.StatusCode != HttpStatusCode.OK)
            throw new HttpRequestException("EXE-манифест недоступен: HTTP " + (int)response.StatusCode);
        if (response.Content.Headers.ContentLength > 4096)
            throw new InvalidDataException("EXE-манифест слишком большой.");
        var json = await response.Content.ReadAsByteArrayAsync(timeout.Token);
        if (json.Length > 4096) throw new InvalidDataException("EXE-манифест слишком большой.");
        var sig = await ReadBoundedAsync(_http, new Uri(baseUrl + "launcher.sig"), 256, timeout.Token);
        VerifySignature(json, sig); // trust only signed metadata
        var manifest = ParseManifest(json);
        var remoteVersion = Version.Parse(manifest.version);
        var installed = Assembly.GetEntryAssembly()?.GetName().Version ?? new Version(0, 0, 0);
        if (remoteVersion <= installed) return null;
        return new AvailableUpdate(manifest.tag, remoteVersion, manifest.size, ReleaseUrl(manifest), manifest.sha256);
    }

    internal async Task<PreparedUpdate> DownloadVerifiedAsync(AvailableUpdate update,
        IProgress<double>? progress = null, CancellationToken ct = default)
    {
        Directory.CreateDirectory(StateDir);
        var path = Path.Combine(StateDir, "ProjectEchoLauncher.stage-" + update.Tag + ".exe");
        if (File.Exists(path))
        {
            if (await MatchesAsync(path, update.Sha256, update.Size, ct))
            {
                progress?.Report(100);
                return new PreparedUpdate(path, update.Sha256, update.Tag);
            }
            File.Delete(path);
        }
        try
        {
            using var response = await _http.GetAsync(update.DownloadUrl, HttpCompletionOption.ResponseHeadersRead, ct);
            if (response.StatusCode != HttpStatusCode.OK)
                throw new HttpRequestException("EXE не загружен: HTTP " + (int)response.StatusCode);
            var uri = response.RequestMessage?.RequestUri;
            if (uri is null || uri.Scheme != "https" ||
                !(uri.Host.Equals("github.com", StringComparison.OrdinalIgnoreCase) ||
                  uri.Host.Equals("release-assets.githubusercontent.com", StringComparison.OrdinalIgnoreCase) ||
                  uri.Host.Equals("objects.githubusercontent.com", StringComparison.OrdinalIgnoreCase)))
                throw new InvalidDataException("EXE получен с неподтверждённого хоста.");
            if (response.Content.Headers.ContentLength > update.Size)
                throw new InvalidDataException("Размер EXE превышает заявленный.");
            await using var src = await response.Content.ReadAsStreamAsync(ct);
            await using var dst = new FileStream(path, FileMode.CreateNew, FileAccess.Write,
                FileShare.None, 1024 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan);
            using var h = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
            var buffer = new byte[1024 * 1024];
            long total = 0;
            int n;
            while ((n = await src.ReadAsync(buffer, ct)) != 0)
            {
                total += n;
                if (total > update.Size || total > MaxBinaryBytes)
                    throw new InvalidDataException("Скачанный EXE превышает заявленный размер.");
                h.AppendData(buffer, 0, n);
                await dst.WriteAsync(buffer.AsMemory(0, n), ct);
                progress?.Report(Math.Round((double)total / update.Size * 100, 2));
            }
            await dst.FlushAsync(ct);
            if (total != update.Size ||
                !Convert.ToHexString(h.GetHashAndReset()).Equals(update.Sha256, StringComparison.OrdinalIgnoreCase))
                throw new CryptographicException("Размер или SHA-256 EXE не совпадает с подписанным манифестом.");
            return new PreparedUpdate(path, update.Sha256, update.Tag);
        }
        catch
        {
            try { File.Delete(path); } catch { }
            throw;
        }
    }

    private static async Task<bool> MatchesAsync(string file, string hash, long size, CancellationToken ct)
    {
        if (new FileInfo(file).Length != size) return false;
        await using var stream = File.OpenRead(file);
        return Convert.ToHexString(await SHA256.HashDataAsync(stream, ct)).Equals(hash, StringComparison.OrdinalIgnoreCase);
    }

    // Updater is its own non-WPF .NET process, embedded as a verified executable
    // resource in the current production client. The downloaded EXE is only DATA.
    internal static async Task StartInstallerAsync(PreparedUpdate update, CancellationToken ct = default)
    {
        if (!RunningAsPublishedLauncher)
            throw new InvalidOperationException("Самообновление разрешено только из production-клиента.");
        Directory.CreateDirectory(StateDir);
        var self = Path.GetFullPath(Environment.ProcessPath!);
        var stage = Path.GetFullPath(update.FilePath);
        var safeRoot = Path.GetFullPath(StateDir).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        if (!stage.StartsWith(safeRoot, StringComparison.OrdinalIgnoreCase) ||
            !Path.GetFileName(stage).StartsWith("ProjectEchoLauncher.stage-", StringComparison.OrdinalIgnoreCase) ||
            !Regex.IsMatch(update.Sha256, "^[a-f0-9]{64}$") || !File.Exists(stage))
            throw new InvalidDataException("Некорректный путь или SHA-256 подготовленного production EXE.");
        if (!await MatchesAsync(stage, update.Sha256, new FileInfo(stage).Length, ct))
            throw new CryptographicException("Загруженный EXE изменился с момента проверки SHA-256.");

        var token = Guid.NewGuid().ToString("N");
        var readyFile = Path.Combine(StateDir, "worker-ready-" + token + ".txt");
        var worker = Path.Combine(StateDir, "ProjectEchoUpdater.worker-" + token + ".exe");
        Process? process = null;
        try
        {
            Trace("Extracting dedicated updater resource into: " + worker);
            await using (var embedded = Assembly.GetExecutingAssembly().GetManifestResourceStream("project-echo-updater.exe")
                ?? throw new InvalidOperationException("Отдельный production Updater не встроен в этот EXE. Сначала собери BUILD_production_CLIENT.cmd."))
            await using (var output = new FileStream(worker, FileMode.CreateNew, FileAccess.Write, FileShare.None,
                1024 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan))
            {
                if (embedded.Length is < 1048576 or > (150L * 1024 * 1024))
                    throw new InvalidDataException("Встроенный Updater имеет недопустимый размер.");
                await embedded.CopyToAsync(output, ct);
                await output.FlushAsync(ct);
            }
            Trace("Dedicated updater extracted, bytes=" + new FileInfo(worker).Length);
            var psi = new ProcessStartInfo(worker)
            {
                UseShellExecute = false,
                WorkingDirectory = StateDir,
                CreateNoWindow = true
            };
            psi.ArgumentList.Add(WorkerSwitch);
            psi.ArgumentList.Add(Environment.ProcessId.ToString());
            psi.ArgumentList.Add(self);
            psi.ArgumentList.Add(stage);
            psi.ArgumentList.Add(update.Sha256);
            psi.ArgumentList.Add(token);
            process = Process.Start(psi) ?? throw new IOException("Windows не запустила отдельный Updater.");
            Trace("Dedicated updater started PID=" + process.Id);

            // Wait for the worker's own Main() to write the handshake.
            // Never close a functioning UI until that point.
            var limit = Stopwatch.StartNew();
            while (limit.Elapsed < TimeSpan.FromSeconds(30))
            {
                ct.ThrowIfCancellationRequested();
                if (File.Exists(readyFile))
                {
                    Trace("Dedicated updater ready; closing old launcher is safe.");
                    try { File.Delete(readyFile); } catch { }
                    return;
                }
                if (process.HasExited)
                    throw new IOException("Отдельный Updater завершился до подтверждения запуска: код " + process.ExitCode +
                        ". Смотри worker-trace.log и update-error.log.");
                await Task.Delay(250, ct);
            }
            throw new TimeoutException("Отдельный Updater не подтвердил запуск за 30 секунд. Старый клиент остаётся открытым.");
        }
        catch (Exception ex)
        {
            Trace("DEDICATED UPDATER LAUNCH FAILED: " + ex);
            if (process is not null)
            {
                try { if (!process.HasExited) process.Kill(entireProcessTree: true); } catch { }
            }
            try { if (File.Exists(worker) && (process is null || process.HasExited)) File.Delete(worker); } catch { }
            throw;
        }
        finally { process?.Dispose(); }
    }

    private static void Trace(string message)
    {
        try
        {
            Directory.CreateDirectory(StateDir);
            File.AppendAllText(Path.Combine(StateDir, "worker-trace.log"),
                DateTimeOffset.Now.ToString("O") + " | " + message + Environment.NewLine, Encoding.UTF8);
        }
        catch { /* log errors must not mask the original error */ }
    }

    internal static void CleanStaleDownloads()
    {
        if (!Directory.Exists(StateDir)) return;
        foreach (var pattern in new[] {
            "ProjectEchoLauncher.stage-*.exe", "ProjectEchoUpdater.worker-*.exe",
            "ProjectEchoLauncher.worker-*.exe", "worker-ready-*.txt" })
        {
            foreach (var path in Directory.EnumerateFiles(StateDir, pattern))
            {
                try { if (File.GetLastWriteTimeUtc(path) < DateTime.UtcNow.AddDays(-14)) File.Delete(path); }
                catch { }
            }
        }
    }

    public void Dispose() => _http.Dispose();
}
