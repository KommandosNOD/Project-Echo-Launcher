using System.Diagnostics;
using System.Net;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace PZLauncher;

// Windows-only client preparation. Never edits Steam workshop files or saved worlds.
internal sealed class GameClientService : IDisposable
{
    private const string CollectionId = "3816354682";
    private const string ZombieBuddyRelease = "https://api.github.com/repos/zed-0xff/ZombieBuddy/releases/tags/windows_installer_4.2";
    private const string ZombieBuddyReleaseFallback = "https://api.github.com/repos/zed-0xff/ZombieBuddy/releases/tags/windows_installer";
    private readonly HttpClient _http = new(new HttpClientHandler { AllowAutoRedirect = true })
    {
        Timeout = TimeSpan.FromSeconds(45)
    };

    internal GameClientService()
    {
        _http.DefaultRequestHeaders.UserAgent.ParseAdd("ProjectEchoLauncher/0.3 (+https://github.com/zed-0xff/ZombieBuddy)");
        _http.DefaultRequestHeaders.Accept.ParseAdd("application/vnd.github+json");
    }

    internal static string ModsRoot
    {
        get
        {
#if ECHO_RELEASE_CANDIDATE
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "PROJECT_ECHO_RC_CLIENT_ONLY", "mods");
#elif ECHO_STAGING_CLIENT
            // STAGING uses its own isolated root; never writes to real Zomboid/mods.
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "PROJECT_ECHO_STAGING_CLIENT_ONLY", "mods");
#elif ECHO_TEST_CLIENT
            // Fixed isolated root: never read, modify, or repair real Zomboid/mods.
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "PROJECT_ECHO_TEST_CLIENT_ONLY", "mods");
#else
            return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Zomboid", "mods");
#endif
        }
    }

    // Find an installed Steam copy without scanning entire drives, touching saves,
    // or assuming Steam and its libraries are installed on C:.
    // appmanifest_108600.acf is the authoritative installation record for PZ.
    private static void AddLibrary(HashSet<string> roots, string? folder)
    {
        if (string.IsNullOrWhiteSpace(folder)) return;
        try
        {
            var path = Environment.ExpandEnvironmentVariables(folder.Trim().Trim('"'))
                .Replace('/', '\\').Replace(@"\\", @"\");
            if (path.EndsWith("steam.exe", StringComparison.OrdinalIgnoreCase))
                path = Path.GetDirectoryName(path) ?? "";
            if (Directory.Exists(path)) roots.Add(Path.GetFullPath(path));
        }
        catch (Exception ex) when (ex is IOException or ArgumentException or NotSupportedException or UnauthorizedAccessException)
        {
            // A stale Steam registry entry or an unplugged disk must not break launch.
        }
    }

    internal static List<string> LibraryRoots()
    {
        var roots = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        try
        {
            using var current = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam");
            AddLibrary(roots, current?.GetValue("SteamPath") as string);
            AddLibrary(roots, current?.GetValue("SteamExe") as string);
        }
        catch (System.Security.SecurityException) { }
        catch (UnauthorizedAccessException) { }
        // Steam installed for all users may register its location only in HKLM.
        try
        {
            foreach (var name in new[] { @"SOFTWARE\Valve\Steam", @"SOFTWARE\WOW6432Node\Valve\Steam" })
            {
                using var machine = Registry.LocalMachine.OpenSubKey(name);
                AddLibrary(roots, machine?.GetValue("InstallPath") as string);
            }
        }
        catch (System.Security.SecurityException) { }
        catch (UnauthorizedAccessException) { }

        foreach (var pf in new[] {
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
            Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles) })
            if (!string.IsNullOrWhiteSpace(pf)) AddLibrary(roots, Path.Combine(pf, "Steam"));

        // libraryfolders.vdf points at Steam libraries on other drives (D:, J: etc).
        // Parse only the quoted 'path' values; a malformed VDF is skipped safely.
        foreach (var steamRoot in roots.ToArray())
        {
            var vdf = Path.Combine(steamRoot, "steamapps", "libraryfolders.vdf");
            try
            {
                if (!File.Exists(vdf)) continue;
                if (new FileInfo(vdf).Length > 4 * 1024 * 1024) continue;
                var data = File.ReadAllText(vdf);
                foreach (Match match in Regex.Matches(data,
                    @"""path""\s*""(?<folder>[^""]+)""", RegexOptions.IgnoreCase))
                    AddLibrary(roots, match.Groups["folder"].Value);
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { }
        }
        return roots.OrderBy(x => x, StringComparer.OrdinalIgnoreCase).ToList();
    }

    private static bool IsGameDirectory(string folder) =>
        File.Exists(Path.Combine(folder, "ProjectZomboid64.json"));

    private static string? FindGameInLibrary(string root)
    {
        var steamapps = Path.Combine(root, "steamapps");
        var manifestFile = Path.Combine(steamapps, "appmanifest_108600.acf");
        if (File.Exists(manifestFile))
        {
            try
            {
                if (new FileInfo(manifestFile).Length <= 1024 * 1024)
                {
                    var data = File.ReadAllText(manifestFile);
                    var match = Regex.Match(data, @"""installdir""\s*""(?<folder>[^""]+)""", RegexOptions.IgnoreCase);
                    if (match.Success)
                    {
                        var name = match.Groups["folder"].Value;
                        // Reject path traversal in untrusted Valve manifest text.
                        if (name != "." && name != ".." &&
                            name.IndexOfAny(new[] { '/', '\\', ':' }) < 0)
                        {
                            var candidate = Path.Combine(steamapps, "common", name);
                            if (IsGameDirectory(candidate)) return Path.GetFullPath(candidate);
                        }
                    }
                }
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { }
        }
        // Fallback when the Steam appmanifest is absent (e.g. a copied library).
        var conventional = Path.Combine(steamapps, "common", "ProjectZomboid");
        return IsGameDirectory(conventional) ? Path.GetFullPath(conventional) : null;
    }

    internal static string? DetectGameFolder(string? userSelected = null)
    {
        // Respect a valid manually selected folder; recover gracefully if moved.
        if (!string.IsNullOrWhiteSpace(userSelected))
        {
            try
            {
                var selected = Path.GetFullPath(userSelected.Trim().Trim('"'));
                if (IsGameDirectory(selected)) return selected;
            }
            catch (Exception ex) when (ex is IOException or ArgumentException or NotSupportedException) { }
        }
        foreach (var root in LibraryRoots())
        {
            var result = FindGameInLibrary(root);
            if (result is not null) return result;
        }
        return null;
    }

    internal static bool HasZombieBuddy(string gameFolder) =>
        File.Exists(Path.Combine(gameFolder, "ZombieBuddy.jar")) &&
        File.Exists(Path.Combine(gameFolder, "zbNative.dll"));

    // Memory setting is changed on user confirmation, with timestamped backup and proper JSON editing.
    internal static string SetMemory8Gb(string gameFolder)
    {
        var file = Path.Combine(gameFolder, "ProjectZomboid64.json");
        if (!File.Exists(file)) throw new FileNotFoundException("Файл конфигурации PZ не найден.", file);
        var node = JsonNode.Parse(File.ReadAllText(file))?.AsObject()
            ?? throw new InvalidDataException("ProjectZomboid64.json повреждён.");
        var vmArgs = node["vmArgs"] as JsonArray
            ?? throw new InvalidDataException("В JSON нет массива vmArgs. Файл оставлен без изменений.");
        int count = 0;
        for (var i = 0; i < vmArgs.Count; i++)
        {
            var arg = vmArgs[i]?.GetValue<string>();
            if (arg is null || !Regex.IsMatch(arg, @"^-Xmx\d+[mMgG]$")) continue;
            vmArgs[i] = "-Xmx8192m";
            count++;
        }
        if (count > 1) throw new InvalidDataException("Найдено несколько параметров -Xmx; требуется ручная проверка.");
        if (count == 0) vmArgs.Add("-Xmx8192m");
        var stamp = DateTime.Now.ToString("yyyyMMdd-HHmmss");
        var backup = file + ".PROJECT-ECHO-" + stamp + ".bak";
        File.Copy(file, backup, false);
        var temp = file + ".PROJECT-ECHO.tmp";
        try
        {
            File.WriteAllText(temp, node.ToJsonString(new JsonSerializerOptions { WriteIndented = true }), new System.Text.UTF8Encoding(false));
            using var check = JsonDocument.Parse(File.ReadAllText(temp));
            File.Move(temp, file, true);
        }
        finally { if (File.Exists(temp)) File.Delete(temp); }
        return backup;
    }

    // Installer is the upstream program. User must choose Install -> Both -> review -> confirm.
    internal async Task<string> DownloadZombieBuddyInstallerAsync()
    {
        // Installer releases are independent of the latest ZombieBuddy framework release.
        // The official asset has a VERSION in its name (e.g. ZombieBuddyInstaller_v4.2.exe).
        Uri? uri = null;
        var lookupErrors = new List<string>();
        foreach (var releaseApi in new[] { ZombieBuddyRelease, ZombieBuddyReleaseFallback })
        {
            try
            {
                using var response = await _http.GetAsync(releaseApi);
                response.EnsureSuccessStatusCode();
                using var doc = JsonDocument.Parse(await response.Content.ReadAsStreamAsync());
                if (!doc.RootElement.TryGetProperty("assets", out var assets) || assets.ValueKind != JsonValueKind.Array)
                {
                    lookupErrors.Add("GitHub returned no assets array for " + releaseApi);
                    continue;
                }
                foreach (var asset in assets.EnumerateArray())
                {
                    if (!asset.TryGetProperty("name", out var nameElement) ||
                        !asset.TryGetProperty("browser_download_url", out var urlElement)) continue;
                    var name = nameElement.GetString();
                    // Do not require the exact unversioned filename.
                    if (name is null || !name.StartsWith("ZombieBuddyInstaller", StringComparison.OrdinalIgnoreCase) ||
                        !name.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) continue;
                    var downloadUrl = urlElement.GetString();
                    if (!Uri.TryCreate(downloadUrl, UriKind.Absolute, out var candidate) ||
                        candidate.Scheme != Uri.UriSchemeHttps ||
                        !string.Equals(candidate.Host, "github.com", StringComparison.OrdinalIgnoreCase) ||
                        !candidate.AbsolutePath.StartsWith("/zed-0xff/ZombieBuddy/releases/download/", StringComparison.OrdinalIgnoreCase)) continue;
                    uri = candidate;
                    break;
                }
                if (uri is not null) break;
                lookupErrors.Add("No official ZombieBuddyInstaller*.exe asset in " + releaseApi);
            }
            catch (HttpRequestException ex) { lookupErrors.Add(releaseApi + ": " + ex.Message); }
            catch (TaskCanceledException ex) { lookupErrors.Add(releaseApi + ": timeout: " + ex.Message); }
            catch (JsonException ex) { lookupErrors.Add(releaseApi + ": invalid API response: " + ex.Message); }
        }
        if (uri is null)
            throw new InvalidDataException(
                "Не удалось определить официальный установщик ZombieBuddy через GitHub API.\n" +
                string.Join("\n", lookupErrors));
        using var binary = await _http.GetAsync(uri, HttpCompletionOption.ResponseHeadersRead);
        binary.EnsureSuccessStatusCode();
        var max = 75L * 1024 * 1024;
        if (binary.Content.Headers.ContentLength > max) throw new InvalidDataException("Установщик слишком большой.");
        var directory = Path.Combine(SettingsStore.StateRoot, "downloads");
        Directory.CreateDirectory(directory);
        var path = Path.Combine(directory, "ZombieBuddyInstaller.exe");
        var temporary = path + ".download";
        try
        {
            await using (var input = await binary.Content.ReadAsStreamAsync())
            await using (var output = File.Create(temporary))
            {
                var buffer = new byte[65536]; long size = 0;
                int n;
                while ((n = await input.ReadAsync(buffer)) > 0)
                {
                    size += n;
                    if (size > max) throw new InvalidDataException("Превышен размер установщика.");
                    await output.WriteAsync(buffer.AsMemory(0, n));
                }
            }
            await using (var stream = File.OpenRead(temporary))
            {
                var signature = new byte[2];
                if (await stream.ReadAsync(signature) != 2 || signature[0] != 'M' || signature[1] != 'Z')
                    throw new InvalidDataException("Загруженный файл не является Windows EXE.");
            }
            File.Move(temporary, path, true);
        }
        finally { if (File.Exists(temporary)) File.Delete(temporary); }
        return path;
    }

    internal static string FileSha256(string path) => Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(path)));
    public void Dispose() => _http.Dispose();
}
