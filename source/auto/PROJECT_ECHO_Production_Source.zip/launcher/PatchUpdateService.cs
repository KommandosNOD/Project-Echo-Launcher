using System.Buffers;
using System.Net;
using System.Net.Http.Headers;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace PZLauncher;

public sealed class PatchUpdateService : IDisposable
{
    private const long MaxManifestBytes = 1024 * 1024;
    private const long MaxLegacyPatchBytes = 25L * 1024 * 1024;
    private const long MaxDynamicPatchBytes = 512L * 1024 * 1024;
    private const long MaxDynamicPackageBytes = 8L * 1024 * 1024 * 1024;
    private const int MaxDynamicEntries = 16000;
    private readonly HttpClient _http = new(new HttpClientHandler { AllowAutoRedirect = false })
    {
        Timeout = TimeSpan.FromMinutes(20)
    };
    public static string ManagedRoot => Path.Combine(SettingsStore.StateRoot, "managed");

    public async Task<UpdatePlan> CheckAsync(string rawUrl, CancellationToken cancellationToken = default)
    {
        if (!Uri.TryCreate(rawUrl.Trim(), UriKind.Absolute, out var source) || !IsAllowedEndpoint(source))
            throw new InvalidOperationException("Требуется HTTPS URL. Для локального теста разрешён только http://localhost или http://127.0.0.1.");
        if (!source.AbsolutePath.EndsWith("/manifest.json", StringComparison.Ordinal))
            throw new InvalidOperationException("Адрес должен заканчиваться на /manifest.json");
#if ECHO_STAGING_CLIENT || ECHO_RELEASE_CANDIDATE || ECHO_PRODUCTION_CLIENT
        // Do not read a mutable branch URL. GitHub's raw CDN may return an OLD signed
        // manifest even with a cache-busting query. Pin every part of the transaction
        // (manifest, signature AND patch files) to the exact same immutable Git commit.
        if (!string.Equals(source.AbsoluteUri, ManifestSource.DefaultUrl, StringComparison.Ordinal))
            throw new InvalidOperationException("STAGING клиент разрешает только закреплённый GitHub TEST канал.");
#endif
        using var checkTimeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        checkTimeout.CancelAfter(TimeSpan.FromSeconds(45));
#if ECHO_STAGING_CLIENT || ECHO_RELEASE_CANDIDATE || ECHO_PRODUCTION_CLIENT
        var snapshotUri = await ResolveStagingCommitManifestAsync(checkTimeout.Token);
#else
        var snapshotUri = source;
#endif
        var signatureUri = new Uri(snapshotUri.AbsoluteUri.Replace("/manifest.json", "/manifest.sig", StringComparison.Ordinal));
        // For local/legacy endpoints keep cache-busting. For STAGING, the immutable
        // commit SHA in the URL is the cache key; manifest and signature cannot diverge.
        var suffix = "v=" + DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        var manifestBytes = await ReadBoundedAsync(AddQuery(snapshotUri, suffix), 4 * MaxManifestBytes, checkTimeout.Token);
        var signatureBytes = await ReadBoundedAsync(AddQuery(signatureUri, suffix), 2048, checkTimeout.Token);
        using (var key = ECDsa.Create())
        {
            using var keyStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("trusted-release-public-key.pem")
                ?? throw new InvalidOperationException("В сборке отсутствует публичный ключ обновлений.");
            using var reader = new StreamReader(keyStream);
            key.ImportFromPem(await reader.ReadToEndAsync(cancellationToken));
            if (!key.VerifyData(manifestBytes, signatureBytes, HashAlgorithmName.SHA256, DSASignatureFormat.Rfc3279DerSequence))
                throw new CryptographicException("ПОДПИСЬ МАНИФЕСТА НЕВЕРНА. Обновление заблокировано.");
        }
        var manifest = JsonSerializer.Deserialize<ReleaseManifest>(manifestBytes) ?? throw new InvalidDataException("Пустой манифест.");
        ValidateManifest(manifest, snapshotUri);
        var changed = new List<PatchFile>();
        foreach (var file in manifest.Files)
        {
            var dest = TargetPath(file.Path, manifest.Schema);
            if (!File.Exists(dest) || !await MatchesHashAsync(dest, file.Sha256, cancellationToken)) changed.Add(file);
        }
        // A signed inventory may request retirement of old owner-managed files.
        // Re-checking this tiny file keeps cleanup visible to the existing UI.
        var inventory = manifest.Schema == 1 ? manifest.Files.FirstOrDefault(x => x.Path == "managed-mods.json") : null;
        if (inventory is not null && !changed.Contains(inventory) &&
            (await RetiredCandidatesAsync(manifest, cancellationToken)).Count != 0)
            changed.Add(inventory);
        return new UpdatePlan(manifest, snapshotUri, changed);
    }

    public async Task InstallAsync(UpdatePlan plan, IProgress<double>? progress = null, CancellationToken cancellationToken = default)
    {
        ValidateManifest(plan.Manifest, plan.ManifestUri);
        if (plan.Changed.Count == 0) { progress?.Report(100); return; }
        var jobId = DateTime.UtcNow.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N")[..8];
        var stageRoot = Path.Combine(SettingsStore.StateRoot, "staging", jobId);
        var backupRoot = Path.Combine(SettingsStore.StateRoot, "backups", jobId);
        Directory.CreateDirectory(stageRoot);
        var staged = new List<(PatchFile File, string Stage, string Target, string Backup, bool Existed)>();
        var applied = new List<(string Target, string Backup, bool Existed)>();
        var retiredPaths = new List<string>();
        long total = plan.Changed.Sum(x => x.Size);
        long downloaded = 0;
        try
        {
            // Download and check EVERYTHING before changing any existing installed file.
            foreach (var file in plan.Changed)
            {
                cancellationToken.ThrowIfCancellationRequested();
                var stageFile = Path.Combine(stageRoot, Guid.NewGuid().ToString("N") + ".download");
                var url = PatchUrl(plan.ManifestUri, file.Url);
                using var response = await _http.GetAsync(url, HttpCompletionOption.ResponseHeadersRead, cancellationToken);
                if (response.StatusCode != HttpStatusCode.OK) throw new HttpRequestException($"Загрузка не удалась: HTTP {(int)response.StatusCode}");
                if (response.Content.Headers.ContentLength > file.Size) throw new InvalidDataException("Сервер вернул слишком большой файл.");
                await using var network = await response.Content.ReadAsStreamAsync(cancellationToken);
                await using var disk = new FileStream(stageFile, FileMode.CreateNew, FileAccess.Write, FileShare.None, 64 * 1024, true);
                using var hasher = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);
                byte[] buffer = ArrayPool<byte>.Shared.Rent(65536);
                long fileBytes = 0;
                try
                {
                    while (true)
                    {
                        int n = await network.ReadAsync(buffer.AsMemory(0, buffer.Length), cancellationToken);
                        if (n == 0) break;
                        fileBytes += n;
                        if (fileBytes > file.Size || fileBytes > MaxFileBytes(plan.Manifest.Schema)) throw new InvalidDataException("Размер патча не совпадает с манифестом.");
                        await disk.WriteAsync(buffer.AsMemory(0, n), cancellationToken);
                        hasher.AppendData(buffer, 0, n);
                        downloaded += n;
                        progress?.Report(total == 0 ? 100 : Math.Clamp(downloaded * 100d / total, 0, 100));
                    }
                }
                finally { ArrayPool<byte>.Shared.Return(buffer); }
                await disk.FlushAsync(cancellationToken);
                if (fileBytes != file.Size || !HashEquals(Convert.ToHexString(hasher.GetHashAndReset()), file.Sha256))
                    throw new CryptographicException("SHA-256 скачанного патча не совпал. Установка отменена.");
                var target = TargetPath(file.Path, plan.Manifest.Schema);
                staged.Add((file, stageFile, target, Path.Combine(backupRoot, file.Path.Replace('/', Path.DirectorySeparatorChar)), File.Exists(target)));
            }
            foreach (var f in staged)
            {
                cancellationToken.ThrowIfCancellationRequested();
                EnsureNoLinks(f.Target);
                Directory.CreateDirectory(Path.GetDirectoryName(f.Target)!);
                if (f.Existed)
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(f.Backup)!);
                    File.Copy(f.Target, f.Backup, false);
                }
                // Track the pending replacement before moving so a failed move can be reverted.
                applied.Add((f.Target, f.Backup, f.Existed));
                File.Move(f.Stage, f.Target, true);
            }
            // Inventory was installed and verified by its signed manifest SHA-256.
            // Delete ONLY a former PROJECT ECHO file with its exact OLD hash.
            foreach (var retired in plan.Manifest.Schema == 1 ? await RetiredCandidatesAsync(plan.Manifest, cancellationToken) : new List<RetiredModFile>())
            {
                cancellationToken.ThrowIfCancellationRequested();
                var target = TargetPath(retired.Path);
                var backup = Path.Combine(backupRoot, "retired", retired.Path.Replace('/', Path.DirectorySeparatorChar));
                // Hash again just before deletion: never remove user-modified files.
                if (!File.Exists(target) || !await MatchesHashAsync(target, retired.Sha256, cancellationToken)) continue;
                Directory.CreateDirectory(Path.GetDirectoryName(backup)!);
                File.Copy(target, backup, false);
                applied.Add((target, backup, true));
                File.Delete(target);
                retiredPaths.Add(target);
            }
            // Remove empty folders of retired mod files, never directories with other contents.
            foreach (var target in retiredPaths) TryPruneEmptyModDirs(target);
            progress?.Report(100);
        }
        catch
        {
            for (int i = applied.Count - 1; i >= 0; i--)
            {
                var step = applied[i];
                try
                {
                    if (step.Existed && File.Exists(step.Backup))
                    {
                        Directory.CreateDirectory(Path.GetDirectoryName(step.Target)!);
                        File.Copy(step.Backup, step.Target, true);
                    }
                    else if (!step.Existed && File.Exists(step.Target)) File.Delete(step.Target);
                }
                catch { /* Backups are preserved for manual recovery if a rollback cannot complete. */ }
            }
            throw;
        }
        finally
        {
            try { Directory.Delete(stageRoot, true); } catch (IOException) { } catch (UnauthorizedAccessException) { }
        }
    }

    private sealed record RetiredModFile(string Path, string Sha256);

    private static async Task<List<RetiredModFile>> RetiredCandidatesAsync(
        ReleaseManifest manifest, CancellationToken ct)
    {
        var file = manifest.Files.FirstOrDefault(x => x.Path == "managed-mods.json");
        if (manifest.Schema != 1 || file is null) return new();
        var local = TargetPath(file.Path);
        if (!File.Exists(local) || new FileInfo(local).Length > 256 * 1024) return new();
        var inventoryBytes = await File.ReadAllBytesAsync(local, ct);
        if (!HashEquals(Convert.ToHexString(SHA256.HashData(inventoryBytes)), file.Sha256)) return new();
        using var document = JsonDocument.Parse(inventoryBytes);
        var root = document.RootElement;
        if (!root.TryGetProperty("schema", out var schema) || schema.GetInt32() != 1 ||
            !root.TryGetProperty("retired", out var entries) || entries.ValueKind != JsonValueKind.Array ||
            entries.GetArrayLength() > 1500)
            throw new InvalidDataException("Некорректный подписанный реестр устаревших модов.");
        var live = new HashSet<string>(manifest.Files.Select(f => f.Path), StringComparer.OrdinalIgnoreCase);
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var result = new List<RetiredModFile>();
        foreach (var entry in entries.EnumerateArray())
        {
            var path = entry.GetProperty("path").GetString() ?? "";
            var hash = entry.GetProperty("sha256").GetString() ?? "";
            var parts = path.Split('/');
            if (parts.Length < 3 || parts[0] != "mods" ||
                !EchoModDirectories.Contains(parts[1]) || live.Contains(path) ||
                !seen.Add(path) || !Regex.IsMatch(hash, "^[0-9a-fA-F]{64}$"))
                throw new InvalidDataException("Небезопасная запись очистки: " + path);
            var dest = TargetPath(path); // also rejects path traversal and reparse points
            if (File.Exists(dest) && await MatchesHashAsync(dest, hash, ct))
                result.Add(new RetiredModFile(path, hash));
        }
        return result;
    }

    private static void TryPruneEmptyModDirs(string retiredFile)
    {
        var modsRoot = Path.GetFullPath(GameClientService.ModsRoot).TrimEnd(Path.DirectorySeparatorChar);
        var modPrefix = modsRoot + Path.DirectorySeparatorChar;
        if (!retiredFile.StartsWith(modPrefix, StringComparison.OrdinalIgnoreCase)) return;
        var rel = Path.GetRelativePath(modsRoot, retiredFile);
        var folder = rel.Split(Path.DirectorySeparatorChar)[0];
        if (!EchoModDirectories.Contains(folder)) return;
        var stopAt = Path.Combine(modsRoot, folder);
        var current = Path.GetDirectoryName(retiredFile);
        while (current is not null && current.StartsWith(stopAt, StringComparison.OrdinalIgnoreCase))
        {
            try
            {
                if (Directory.GetFileSystemEntries(current).Length != 0) break;
                Directory.Delete(current, false);
            }
            catch (IOException) { break; }
            catch (UnauthorizedAccessException) { break; }
            if (current.Equals(stopAt, StringComparison.OrdinalIgnoreCase)) break;
            current = Path.GetDirectoryName(current);
        }
    }

#if ECHO_STAGING_CLIENT || ECHO_RELEASE_CANDIDATE || ECHO_PRODUCTION_CLIENT
    private const string StagingRefApi =
#if ECHO_PRODUCTION_CLIENT
        "https://api.github.com/repos/KommandosNOD/Project-Echo-Launcher/git/ref/heads/project-echo-schema2-production";
#else
        "https://api.github.com/repos/KommandosNOD/Project-Echo-Launcher/git/ref/heads/project-echo-schema2-staging";
#endif
    private const string StagingRawPrefix =
        "https://raw.githubusercontent.com/KommandosNOD/Project-Echo-Launcher/";
    private const string StagingManifestSuffix = "/updates/schema2-staging/manifest.json";

    // GitHub REST API returns the object.sha of the current branch HEAD.
    // The commit-specific raw URL is immutable. Never fall back to the mutable
    // branch URL when API access fails: that would silently reintroduce stale data.
    private async Task<Uri> ResolveStagingCommitManifestAsync(CancellationToken token)
    {
        var checkUri = new Uri(StagingRefApi + "?stamp=" + DateTimeOffset.UtcNow.ToUnixTimeMilliseconds());
        using var request = new HttpRequestMessage(HttpMethod.Get, checkUri);
        request.Headers.UserAgent.ParseAdd("ProjectEcho-StagingUpdater/0.2.2");
        request.Headers.CacheControl = new CacheControlHeaderValue
        {
            NoCache = true,
            NoStore = true,
            MaxAge = TimeSpan.Zero
        };
        using var response = await _http.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, token);
        if (response.StatusCode != HttpStatusCode.OK)
            throw new HttpRequestException($"Не удалось определить коммит GitHub TEST: HTTP {(int)response.StatusCode}. Обновление остановлено.");
        if (response.Content.Headers.ContentLength > 16 * 1024)
            throw new InvalidDataException("GitHub вернул слишком большой ответ с SHA коммита.");
        var data = await response.Content.ReadAsByteArrayAsync(token);
        if (data.Length > 16 * 1024)
            throw new InvalidDataException("GitHub вернул слишком большой ответ с SHA коммита.");
        using var doc = JsonDocument.Parse(data);
        var sha = doc.RootElement.GetProperty("object").GetProperty("sha").GetString();
        if (sha is null || !Regex.IsMatch(sha, "^[0-9a-fA-F]{40}$", RegexOptions.CultureInvariant))
            throw new InvalidDataException("GitHub вернул некорректный SHA коммита.");
        return new Uri(StagingRawPrefix + sha.ToLowerInvariant() + StagingManifestSuffix);
    }

    private static bool IsPinnedStagingSnapshot(Uri source)
    {
        if (source.Scheme != Uri.UriSchemeHttps ||
            !source.Host.Equals("raw.githubusercontent.com", StringComparison.OrdinalIgnoreCase) ||
            source.UserInfo.Length != 0 || source.Query.Length != 0 || source.Fragment.Length != 0)
            return false;
        var full = source.AbsoluteUri;
        if (!full.StartsWith(StagingRawPrefix, StringComparison.Ordinal)) return false;
        var suffix = full[StagingRawPrefix.Length..];
        return suffix.EndsWith(StagingManifestSuffix, StringComparison.Ordinal) &&
            Regex.IsMatch(suffix[..^StagingManifestSuffix.Length], "^[0-9a-f]{40}$", RegexOptions.CultureInvariant);
    }
#endif

    private static Uri AddQuery(Uri uri, string query) => new UriBuilder(uri) { Query = query }.Uri;
    private static bool IsAllowedEndpoint(Uri uri) => uri.Scheme == Uri.UriSchemeHttps ||
        (uri.Scheme == Uri.UriSchemeHttp && uri.IsLoopback && (uri.Host == "localhost" || uri.Host == "127.0.0.1" || uri.Host == "[::1]"));

    private async Task<byte[]> ReadBoundedAsync(Uri uri, long maxBytes, CancellationToken token)
    {
        using var response = await _http.GetAsync(uri, HttpCompletionOption.ResponseHeadersRead, token);
        if (response.StatusCode != HttpStatusCode.OK) throw new HttpRequestException($"HTTP {(int)response.StatusCode}: {uri.AbsolutePath}");
        if (response.Content.Headers.ContentLength > maxBytes) throw new InvalidDataException("Ответ превышает допустимый размер.");
        await using var stream = await response.Content.ReadAsStreamAsync(token);
        using var output = new MemoryStream();
        byte[] buffer = new byte[32768];
        while (true)
        {
            int n = await stream.ReadAsync(buffer.AsMemory(), token);
            if (n == 0) return output.ToArray();
            if (output.Length + n > maxBytes) throw new InvalidDataException("Ответ превышает допустимый размер.");
            output.Write(buffer, 0, n);
        }
    }
    // PROJECT_ECHO_SIX_MODS_FIX3: restrict special assets to expected signed mod paths.
    private static readonly HashSet<string> AllowedExtensions = new(StringComparer.OrdinalIgnoreCase)
        { ".txt", ".lua", ".info", ".json", ".xml", ".png" };
    private static readonly HashSet<string> EchoModDirectories = new(StringComparer.Ordinal)
        { "ProjectEchoLocal", "ProjectEcho", "RM_ServerCompatPatch", "PZ42SpecialLootCallbackGuard", "PZ_Vehicle_Template_Aliases_B42", "Viewpoint_local", "PhleaMarket_WORLD_READY", "ViewpointInventory_ControllerFallback", "ProjectEcho_AmmoCompat", "ProjectEcho_BrokenSmallHandle_Fix", "ProjectEcho_RU", "ProjectEcho_SleepApproachFix", "ProjectEchoAuthenticZRU", "ProjectEchoDAMNLibraryRU", "ProjectEchoFurniturePushPullRU", "ProjectEchoItemStoriesGroundFix", "ProjectEchoKitsuneCrossbowRU", "ProjectEchoMoneyExchange", "ProjectEchoSandboxLoader", "ProjectEchoWeaponVisualFix" };
    private static bool EchoAllowedFile(string raw)
    {
        // TargetPath also checks the path after stripping mods/, so recognize both forms.
        var normalized = raw.StartsWith("mods/", StringComparison.Ordinal) ? raw : "mods/" + raw;
        if (AllowedExtensions.Contains(Path.GetExtension(raw))) return true;
        if (normalized == "mods/Viewpoint_local/LICENSE" || normalized == "mods/PhleaMarket_WORLD_READY/LICENSE") return true;
        if (normalized == "mods/Viewpoint_local/42/media/java/client/Viewpoint.jar") return true;
        if (normalized == "mods/PhleaMarket_WORLD_READY/common/media/phleamarket.tiles") return true;
        if (normalized == "mods/ProjectEcho/common/media/phleamarket.tiles") return true;
        if (normalized == "mods/PhleaMarket_WORLD_READY/common/media/texturepacks/phleamarket.pack") return true;
        if (normalized == "mods/ProjectEcho/common/media/texturepacks/phleamarket.pack") return true;
        return false;
    }
    private static readonly HashSet<string> BlockedDynamicExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".exe", ".dll", ".ps1", ".bat", ".cmd", ".com", ".msi", ".scr", ".vbs", ".wsf",
        ".pem", ".pfx", ".p12", ".key", ".env", ".kdbx", ".sqlite-wal", ".sqlite-shm"
    };
    private static readonly Regex ReservedWindowsName = new(
        @"^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

    private static long MaxFileBytes(int schema) => schema == 2 ? MaxDynamicPatchBytes : MaxLegacyPatchBytes;

    private static string RelativePath(string raw, int schema)
    {
        if (string.IsNullOrWhiteSpace(raw) || raw.Length > (schema == 2 ? 500 : 220) ||
            raw.Contains('\\') || raw.Contains(':') || raw.StartsWith('/') || raw.Contains('%') ||
            raw.Contains('?') || raw.Contains('#') || raw.Any(char.IsControl))
            throw new InvalidDataException("Запрещённый путь патча: " + raw);
        var parts = raw.Split('/');
        if (parts.Any(p => p is "" or "." or ".." || p.EndsWith('.') || p.EndsWith(' ') ||
            p.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 || ReservedWindowsName.IsMatch(p)))
            throw new InvalidDataException("Недопустимый путь патча: " + raw);
        if (schema == 1)
        {
            if (!EchoAllowedFile(raw)) throw new InvalidDataException("Небезопасное расширение патча: " + raw);
        }
        else if (schema == 2)
        {
            if (Path.GetFileName(raw).StartsWith(".env", StringComparison.OrdinalIgnoreCase) ||
                BlockedDynamicExtensions.Contains(Path.GetExtension(raw)))
                throw new InvalidDataException("Заблокированный тип файла: " + raw);
        }
        else throw new InvalidDataException("Неизвестная схема патча.");
        return Path.Combine(parts);
    }

    private static string RootForTarget(string relative, int schema, out string safeRelative)
    {
        if (schema == 2)
        {
            // Dynamic manifests are restricted to a single root: Zomboid/mods.
            // Only mods/default.txt or mods/<folder>/<file> is accepted.
            if (relative == "mods/default.txt")
            {
                safeRelative = "default.txt";
                return GameClientService.ModsRoot;
            }
            if (!relative.StartsWith("mods/", StringComparison.Ordinal))
                throw new InvalidDataException("Новый манифест может изменять только папку mods: " + relative);
            var parts = relative.Split('/');
            if (parts.Length < 3 || parts[1].Equals("default.txt", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Ожидается папка мода и имя файла: " + relative);
            safeRelative = relative["mods/".Length..];
            return GameClientService.ModsRoot;
        }
        if (relative.StartsWith("mods/", StringComparison.Ordinal))
        {
            var parts = relative.Split('/');
            if (parts.Length < 3 || !EchoModDirectories.Contains(parts[1]))
                throw new InvalidDataException("Неизвестный каталог старого мода: " + relative);
            safeRelative = relative["mods/".Length..];
            return GameClientService.ModsRoot;
        }
        if (relative.StartsWith("mods/", StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Некорректный регистр каталога mods: " + relative);
        safeRelative = relative;
        return ManagedRoot;
    }
    private static string TargetPath(string relative, int schema = 1)
    {
        var basePath = RootForTarget(relative, schema, out var safeRelative);
        var root = Path.GetFullPath(basePath).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        var resolved = Path.GetFullPath(Path.Combine(root, RelativePath(safeRelative, schema)));
        if (!resolved.StartsWith(root, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Попытка выхода из папки патчей.");
        EnsureNoLinks(resolved);
        return resolved;
    }
    private static void EnsureNoLinks(string fullTarget)
    {
        // Check existing directory and file components to prevent reparse-point redirection.
        var root = fullTarget.StartsWith(Path.GetFullPath(GameClientService.ModsRoot).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar,
             StringComparison.OrdinalIgnoreCase) ? Path.GetFullPath(GameClientService.ModsRoot) : Path.GetFullPath(ManagedRoot);
        var path = Path.GetPathRoot(root)!;
        foreach (var part in Path.GetRelativePath(path, root).Split(Path.DirectorySeparatorChar))
        {
            if (part is "" or ".") continue;
            path = Path.Combine(path, part);
            if ((File.Exists(path) || Directory.Exists(path)) && File.GetAttributes(path).HasFlag(FileAttributes.ReparsePoint))
                throw new IOException("Символические ссылки в пути установки запрещены.");
        }
        foreach (var part in Path.GetRelativePath(root, fullTarget).Split(Path.DirectorySeparatorChar))
        {
            if (part is "" or ".") continue;
            path = Path.Combine(path, part);
            if ((File.Exists(path) || Directory.Exists(path)) && File.GetAttributes(path).HasFlag(FileAttributes.ReparsePoint))
                throw new IOException("Символические ссылки внутри папки патчей запрещены.");
        }
    }
    private static void ValidateManifest(ReleaseManifest manifest, Uri source)
    {
#if ECHO_STAGING_CLIENT || ECHO_RELEASE_CANDIDATE || ECHO_PRODUCTION_CLIENT
        if (manifest.Schema != 2 || !IsPinnedStagingSnapshot(source))
            throw new InvalidDataException("STAGING клиент допускает только подписанный schema 2 из закреплённого GitHub TEST коммита.");
#elif ECHO_TEST_CLIENT
        if (manifest.Schema != 2 || !source.IsLoopback)
            throw new InvalidDataException("Тестовый клиент разрешает только подписанный schema 2 с локального сервера.");
#endif
        if (manifest.Files is null || string.IsNullOrWhiteSpace(manifest.Version) || manifest.Version.Length > 80 ||
            manifest.Channel != "stable" || manifest.Schema is not (1 or 2))
            throw new InvalidDataException("Неизвестный формат, канал или версия манифеста.");
        if (manifest.Schema == 1)
        {
            if (manifest.Files.Count > 1000 || manifest.Server is null || manifest.Server.Port is < 1 or > 65535)
                throw new InvalidDataException("Некорректный устаревший манифест.");
        }
        else
        {
            if (manifest.Kind != "PROJECT_ECHO_LOCAL_MODS" || manifest.Files.Count > MaxDynamicEntries ||
                manifest.Retired is null || manifest.Retired.Count != 0)
                throw new InvalidDataException("Формат schema 2 некорректен. Удаление файлов пока намеренно отключено.");
            if (!manifest.Files.Any(f => f.Path == "mods/default.txt"))
                throw new InvalidDataException("В schema 2 отсутствует обязательный файл mods/default.txt.");
        }
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        long totalSize = 0;
        foreach (var file in manifest.Files)
        {
            _ = RelativePath(file.Path, manifest.Schema);
            _ = TargetPath(file.Path, manifest.Schema);
            if (!seen.Add(file.Path)) throw new InvalidDataException("Дублирующийся файл манифеста: " + file.Path);
            if (file.Size < 0 || file.Size > MaxFileBytes(manifest.Schema))
                throw new InvalidDataException("Недопустимый размер патча: " + file.Path);
            totalSize = checked(totalSize + file.Size);
            if (totalSize > (manifest.Schema == 2 ? MaxDynamicPackageBytes : 500L * 1024 * 1024))
                throw new InvalidDataException("Суммарный размер обновления слишком велик.");
            if (!Regex.IsMatch(file.Sha256 ?? "", "^[0-9a-fA-F]{64}$"))
                throw new InvalidDataException("Недопустимый SHA-256: " + file.Path);
            if (manifest.Schema == 2 && file.Url != "files/" + file.Path)
                throw new InvalidDataException("URL файла не соответствует пути в манифесте: " + file.Path);
            _ = PatchUrl(source, file.Url);
        }
        // Reject file-as-directory conflicts before copying anything.
        foreach (var path in seen)
        {
            var parts = path.Split('/');
            var parent = parts[0];
            for (int i = 1; i < parts.Length; i++)
            {
                if (seen.Contains(parent)) throw new InvalidDataException("Конфликт путей в манифесте: " + path);
                parent += "/" + parts[i];
            }
        }
    }
    private static Uri PatchUrl(Uri source, string relative)
    {
        if (string.IsNullOrWhiteSpace(relative) || relative.Contains('\\') || relative.Contains('%') || relative.Contains('?') || relative.Contains('#') || !relative.StartsWith("files/", StringComparison.Ordinal))
            throw new InvalidDataException("Запрещённый URL обновления.");
        var segments = relative.Split('/');
        if (segments.Any(s => s is "" or "." or "..")) throw new InvalidDataException("URL содержит переход по каталогам.");
        var absolute = new Uri(source, relative);
        var sourceDir = source.AbsolutePath[..(source.AbsolutePath.LastIndexOf('/') + 1)];
        if (absolute.Scheme != source.Scheme || absolute.Authority != source.Authority || !absolute.AbsolutePath.StartsWith(sourceDir + "files/", StringComparison.Ordinal))
            throw new InvalidDataException("Обновление пытается обратиться к другому источнику.");
        return absolute;
    }
    private static bool HashEquals(string a, string b) => string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
    private static async Task<bool> MatchesHashAsync(string path, string expectedHash, CancellationToken ct)
    {
        await using var stream = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read, 65536, true);
        return HashEquals(Convert.ToHexString(await SHA256.HashDataAsync(stream, ct)), expectedHash);
    }
    public void Dispose() => _http.Dispose();
}
