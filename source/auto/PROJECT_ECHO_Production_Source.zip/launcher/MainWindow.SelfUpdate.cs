// PROJECT_ECHO_SELFUPDATE_STEP17
using System;
using System.Threading.Tasks;
using System.Windows;

namespace PZLauncher;

public partial class MainWindow
{
#if ECHO_RELEASE_CANDIDATE
    // Do not fetch production/latest or replace an RC executable before the
    // owner-signed production launcher channel has been released.
    private Task<bool> CheckSelfUpdateAtStartupAsync() => Task.FromResult(false);
#else
    private async Task<bool> CheckSelfUpdateAtStartupAsync()
    {
        try
        {
            // A renamed download (e.g. "ProjectEchoLauncher (1).exe") cannot be
            // safely replaced by the dedicated production updater. Make the
            // limitation visible instead of silently skipping EXE updates.
            if (!LauncherSelfUpdateService.RunningAsPublishedLauncher)
            {
                if (IsLoaded)
                    StatusText.Text = "Автообновление EXE: переименуй файл в ProjectEchoLauncher.exe и перезапусти лаунчер.";
                return false;
            }
            using var autoUpdater = new LauncherSelfUpdateService();
            var update = await autoUpdater.CheckAsync();
            if (update is null || !IsLoaded) return false;

            // Consent before downloading a ~200 MiB executable. Merely checking
            // the signed metadata must never start a download.
            var consent = MessageBox.Show(this,
                $"Доступен PROJECT ECHO Launcher {update.Tag}.\n" +
                $"Размер загрузки: {update.Size / (1024d * 1024d):0.0} МиБ.\n\n" +
                "Скачать обновление сейчас?\n\n" +
                "Если выбрать «Нет», лаунчер продолжит работу без скачивания.",
                "PROJECT ECHO — доступно обновление", MessageBoxButton.YesNo,
                MessageBoxImage.Question);
            if (consent != MessageBoxResult.Yes) return false;

            StatusText.Text = $"Новая версия лаунчера {update.Tag}: загрузка…";
            UpdateProgress.Value = 0;
            var progress = new Progress<double>(value =>
            {
                if (IsLoaded)
                {
                    UpdateProgress.Value = value;
                    StatusText.Text = $"Загрузка лаунчера {update.Tag}: {value:0}%";
                }
            });
            var prepared = await autoUpdater.DownloadVerifiedAsync(update, progress);
            if (!IsLoaded) return false;
            StatusText.Text = $"Лаунчер {update.Tag} загружен и проверен (SHA-256).";
            var answer = MessageBox.Show(this,
                $"Доступна новая версия PROJECT ECHO Launcher {update.Tag}.\n\n" +
                "Обновление уже загружено с GitHub и проверено по SHA-256.\n" +
                "Перезапустить лаунчер и установить обновление сейчас?\n\n" +
                "Игра, моды и сохранения не изменятся.",
                "PROJECT ECHO — обновление лаунчера", MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (answer != MessageBoxResult.Yes) return false;

            await LauncherSelfUpdateService.StartInstallerAsync(prepared);
            Application.Current.Shutdown();
            return true;
        }
        catch (Exception ex)
        {
            if (IsLoaded) StatusText.Text = "EXE-обновление не выполнено: " + ex.Message;
            // GitHub availability must NEVER prevent play or signed mod patch verification.
            try
            {
#if ECHO_STAGING_CLIENT
                var logDir = System.IO.Path.Combine(SettingsStore.StateRoot, "launcher-selfupdate");
#else
                var logDir = System.IO.Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                    "PZCommunityLauncher", "launcher-selfupdate");
#endif
                System.IO.Directory.CreateDirectory(logDir);
                System.IO.File.WriteAllText(System.IO.Path.Combine(logDir, "check-error.log"), ex.ToString());
            }
            catch { }
            return false;
        }
    }
#endif
}
