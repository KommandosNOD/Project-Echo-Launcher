using System.Diagnostics;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace PZLauncher;

// Client settings come ONLY from a JSON file installed via the existing
// ECDSA-verified + SHA256-verified PatchUpdateService. Never download
// settings from an independent, unsigned URL.
internal static class EchoSettingsSync
{
    // Profile is staged ONLY by PatchUpdateService after ECDSA + SHA-256 verification.
    private const int MaxProfileSize = 1024 * 1024;
    private const int MaxFileSize = 256 * 1024;
    private const int MaxViewpointFiles = 24;
    private static readonly string ProfilePath = Path.Combine(PatchUpdateService.ManagedRoot, "config", "echo-settings.json");
    private static readonly string StatePath = Path.Combine(SettingsStore.StateRoot, "settings-sync-state-v3.json");
    private static readonly HashSet<string> GraphicKeys = new(StringComparer.OrdinalIgnoreCase)
    {
        "lighting", "lightFPS", "water", "bloodDecals", "textureCompression",
        "simpleClothingTextures", "simpleWeaponTextures", "modelTextureMipmaps",
        "dynamicSkybox", "skybox", "windSpriteEffects", "fogQuality",
        "renderPrecipitation", "corpseShadows", "performanceSmoothing",
        "zoom", "maxZoom", "minZoom", "zoomLevels1x", "zoomLevels2x"
    };
    private static readonly Regex ViewpointFilename = new(
        @"^(?:Viewpoint|ProjectViewpoint)[A-Za-z0-9_.-]{0,90}\.(?:ini|json|txt)$",
        RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);

    internal sealed class Profile
    {
        public int Schema { get; set; }
        public string Version { get; set; } = "";
        public string Fingerprint { get; set; } = "";
        public Dictionary<string, string> Graphics { get; set; } = new(StringComparer.OrdinalIgnoreCase);
        public string? KeybindingsBase64 { get; set; }
        public string? ModOptionsBase64 { get; set; }
        public Dictionary<string, string> ViewpointFiles { get; set; } = new(StringComparer.OrdinalIgnoreCase);
    }

    private sealed class State
    {
        public string Fingerprint { get; set; } = "";
        public bool Skipped { get; set; }
    }

    internal static Profile? LoadProfile()
    {
        if (!File.Exists(ProfilePath)) return null;
        var info = new FileInfo(ProfilePath);
        if (info.Length is < 1 or > MaxProfileSize) throw new InvalidDataException("Некорректный размер профиля.");
        var bytes = File.ReadAllBytes(ProfilePath);
        var profile = JsonSerializer.Deserialize<Profile>(bytes, new JsonSerializerOptions { PropertyNameCaseInsensitive = true })
            ?? throw new InvalidDataException("Некорректный JSON профиля.");
        if (profile.Schema != 1 || string.IsNullOrWhiteSpace(profile.Version) || profile.Version.Length > 80)
            throw new InvalidDataException("Неизвестная версия формата настроек.");
        profile.Graphics ??= new Dictionary<string, string>();
        profile.ViewpointFiles ??= new Dictionary<string, string>();
        if (profile.ViewpointFiles.Count > MaxViewpointFiles) throw new InvalidDataException("Слишком много файлов Viewpoint.");
        if (profile.Graphics.Count > 40) throw new InvalidDataException("Слишком много параметров графики.");
        foreach (var pair in profile.Graphics)
            if (!GraphicKeys.Contains(pair.Key) || pair.Value.Length > 200 || pair.Value.Contains('\r') || pair.Value.Contains('\n'))
                throw new InvalidDataException("Запрещённый ключ графики: " + pair.Key);
        foreach (var pair in profile.ViewpointFiles)
            if (!ViewpointFilename.IsMatch(pair.Key) || pair.Value is null || pair.Value.Length > MaxFileSize * 2)
                throw new InvalidDataException("Запрещённый файл Viewpoint: " + pair.Key);
        profile.Fingerprint = Convert.ToHexString(SHA256.HashData(bytes));
        return profile;
    }

    internal static bool AlreadyHandled(Profile profile)
    {
        try
        {
            using var doc = JsonDocument.Parse(File.ReadAllText(StatePath));
            return doc.RootElement.TryGetProperty("Fingerprint", out var fp) &&
                string.Equals(fp.GetString(), profile.Fingerprint, StringComparison.OrdinalIgnoreCase);
        }
        catch (IOException) { return false; }
        catch (JsonException) { return false; }
        catch (UnauthorizedAccessException) { return false; }
    }

    internal static void MarkHandled(Profile profile, bool skipped)
    {
        Directory.CreateDirectory(SettingsStore.StateRoot);
        var tmp = StatePath + ".tmp";
        File.WriteAllText(tmp, JsonSerializer.Serialize(new State { Fingerprint = profile.Fingerprint, Skipped = skipped }));
        File.Move(tmp, StatePath, true);
    }

    internal static string Apply(Profile profile, bool keys, bool modOptions, bool viewpoint)
    {
        // Fail closed if the game is running.
        if (Process.GetProcessesByName("ProjectZomboid64").Length != 0 ||
            Process.GetProcessesByName("ProjectZomboid").Length != 0)
            throw new IOException("Сначала полностью закрой Project Zomboid.");

        var root = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Zomboid");
        var lua = Path.Combine(root, "Lua");
        var planned = new Dictionary<string, byte[]>(StringComparer.OrdinalIgnoreCase);

        if (profile.Graphics.Count > 0)
        {
            var path = Path.Combine(root, "options.ini");
            if (!File.Exists(path)) throw new FileNotFoundException("Сначала запусти PZ один раз — options.ini отсутствует.", path);
            var raw = File.ReadAllBytes(path);
            bool bom = raw.Length >= 3 && raw[0] == 0xEF && raw[1] == 0xBB && raw[2] == 0xBF;
            // Strict UTF-8 avoids silently corrupting Russian text in legacy-encoded options.ini.
            var strictUtf8 = new UTF8Encoding(false, true);
            string original;
            try { original = strictUtf8.GetString(raw, bom ? 3 : 0, raw.Length - (bom ? 3 : 0)); }
            catch (DecoderFallbackException)
            { throw new InvalidDataException("options.ini is not valid UTF-8. Refusing to rewrite it; ask for a legacy encoding patch."); }
            string updated = MergeGraphics(original, profile.Graphics);
            if (updated != original)
            {
                var bytes = new UTF8Encoding(false).GetBytes(updated);
                if (bom) bytes = new byte[] { 0xEF, 0xBB, 0xBF }.Concat(bytes).ToArray();
                planned.Add(path, bytes);
            }
        }
        if (keys && !string.IsNullOrWhiteSpace(profile.KeybindingsBase64))
            planned.Add(Path.Combine(lua, "keysB42.ini"), Decode(profile.KeybindingsBase64));
        if (modOptions && !string.IsNullOrWhiteSpace(profile.ModOptionsBase64))
            planned.Add(Path.Combine(lua, "mods_options.ini"), Decode(profile.ModOptionsBase64));
        if (viewpoint)
        {
            foreach (var item in profile.ViewpointFiles)
            {
                if (!ViewpointFilename.IsMatch(item.Key)) throw new InvalidDataException("Незнакомое имя файла Viewpoint.");
                planned.Add(Path.Combine(lua, item.Key), Decode(item.Value));
            }
        }
        if (planned.Count == 0) return "Файлы не изменены";
        var archiveDir = Path.Combine(SettingsStore.StateRoot, "settings-backups",
            DateTime.Now.ToString("yyyyMMdd-HHmmss") + "-" + Guid.NewGuid().ToString("N")[..8]);
        var journal = new List<(string Destination, string Backup, bool Existed)>();
        Directory.CreateDirectory(archiveDir);
        try
        {
            // Validate symlink-free paths and stage every file before touching targets.
            foreach (var item in planned)
            {
                EnsureNoReparsePoints(root, item.Key);
                if (item.Value.Length > MaxFileSize) throw new InvalidDataException("Слишком большой файл настроек.");
            }
            foreach (var item in planned)
            {
                var target = item.Key;
                Directory.CreateDirectory(Path.GetDirectoryName(target)!);
                var bak = Path.Combine(archiveDir, Path.GetFileName(target) + ".bak");
                bool exists = File.Exists(target);
                if (exists) File.Copy(target, bak, false);
                var temp = target + ".echo-settings-" + Guid.NewGuid().ToString("N") + ".tmp";
                File.WriteAllBytes(temp, item.Value);
                journal.Add((target, bak, exists));
                try { File.Move(temp, target, true); }
                finally { if (File.Exists(temp)) File.Delete(temp); }
            }
            File.WriteAllText(Path.Combine(archiveDir, "README.txt"),
                "PROJECT ECHO — backups of previous client settings.\n" +
                "To restore: close the game and copy *.bak files back into the Zomboid/Lua folder, " +
                "except options.ini.bak which goes into Zomboid root.\n");
            return archiveDir;
        }
        catch
        {
            for (int i = journal.Count - 1; i >= 0; i--)
            {
                var j = journal[i];
                try
                {
                    if (j.Existed && File.Exists(j.Backup)) File.Copy(j.Backup, j.Destination, true);
                    else if (!j.Existed && File.Exists(j.Destination)) File.Delete(j.Destination);
                }
                catch { /* Backup survives for manual restore. */ }
            }
            throw;
        }
    }

    private static byte[] Decode(string content)
    {
        if (content.Length > MaxFileSize * 2) throw new InvalidDataException("Слишком длинный Base64 в профиле.");
        var bytes = Convert.FromBase64String(content);
        if (bytes.Length > MaxFileSize) throw new InvalidDataException("Размер настроек превышает лимит.");
        return bytes;
    }

    private static string MergeGraphics(string original, Dictionary<string, string> changes)
    {
        // Preserve original encoding-independent content, unknown keys, player resolution,
        // audio, language and other personal settings. Append only safe missing keys.
        var result = original;
        foreach (var pair in changes)
        {
            if (!GraphicKeys.Contains(pair.Key)) throw new InvalidDataException("Неизвестный графический параметр.");
            var regex = new Regex(@"(?m)^([ \t]*" + Regex.Escape(pair.Key) + @"[ \t]*=[ \t]*)([^\r\n]*)(\r?)$",
                RegexOptions.IgnoreCase | RegexOptions.CultureInvariant);
            if (regex.IsMatch(result)) result = regex.Replace(result, m => m.Groups[1].Value + pair.Value + m.Groups[3].Value);
            // Do not add keys that do not exist in the player's game version.
        }
        return result;
    }

    private static void EnsureNoReparsePoints(string root, string target)
    {
        var fullRoot = Path.GetFullPath(root);
        var fullTarget = Path.GetFullPath(target);
        if (!fullTarget.StartsWith(fullRoot.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar,
            StringComparison.OrdinalIgnoreCase)) throw new IOException("Путь настроек вне Zomboid.");
        var parent = Path.GetPathRoot(fullRoot)!;
        foreach (var part in Path.GetRelativePath(parent, fullTarget).Split(Path.DirectorySeparatorChar))
        {
            if (part is "" or ".") continue;
            parent = Path.Combine(parent, part);
            if ((Directory.Exists(parent) || File.Exists(parent)) && File.GetAttributes(parent).HasFlag(FileAttributes.ReparsePoint))
                throw new IOException("Запрещена запись через символическую ссылку: " + parent);
        }
    }
}
