@echo off
setlocal
cd /d "%~dp0"
echo ================================================
echo  PROJECT ECHO - Minidoracat client patch 0.2.10
echo ================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PE_MinidoracatClient.ps1" -Mode Install
set "RC=%ERRORLEVEL%"
echo.
echo Result code: %RC%
pause
exit /b %RC%
