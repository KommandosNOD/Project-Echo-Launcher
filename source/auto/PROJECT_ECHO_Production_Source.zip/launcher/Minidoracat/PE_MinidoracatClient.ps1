﻿# PROJECT ECHO helper ONLY; official Minidoracat installer does all actual file changes.
# Pinned to Project Zomboid 42.21.0 and upstream client-v0.2.10 (2026-10-20).
[CmdletBinding()]
param([ValidateSet('Install','Uninstall')][string]$Mode='Install')
$ErrorActionPreference = 'Stop'
$Version = '42.21.0-0.2.10'
$ArchiveName = "MinidoracatClientPatches-$Version.zip"
$DownloadUrl = "https://github.com/Minidoracat/MinidoracatJavaPatchFor42/releases/download/client-v0.2.10/$ArchiveName"
$ExpectedSha = 'ad53db099d78107b36d25fbeed393f861e9ff9cc42ced77c6b690a2d5a54193b'
$ArchivePath = Join-Path $PSScriptRoot $ArchiveName
$ExtractDir = Join-Path $PSScriptRoot ('Official_Minidoracat_' + $Version)
try {
    Write-Host ''
    Write-Host 'PROJECT ECHO / Minidoracat 42.21.0 client-v0.2.10' -ForegroundColor Cyan
    Write-Host 'Source: Minidoracat/MinidoracatJavaPatchFor42' -ForegroundColor Cyan
    Write-Host 'WARNING: This is NOT a standard Workshop mod. Original installer manages game .class files.'
    Write-Host 'Close Project Zomboid first.' -ForegroundColor Yellow
    Write-Host 'If PZ_Optimization is installed: switch OFF Warm-start cache (Java AOT),'
    Write-Host 'start the game to MAIN MENU once, then exit BEFORE installing/removing.' -ForegroundColor Yellow
    Write-Host 'DO NOT manually delete conflicting .class files.' -ForegroundColor Yellow
    Write-Host ''
    if (-not (Test-Path -LiteralPath $ArchivePath -PathType Leaf)) {
        Write-Host 'Official archive is missing in this folder; downloading from GitHub...'
        Write-Host $DownloadUrl
        try {
            # TLS 1.2 compatibility with older Windows PowerShell installations.
            [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
            Invoke-WebRequest -Uri $DownloadUrl -OutFile $ArchivePath -UseBasicParsing -MaximumRedirection 8
        } catch {
            Remove-Item -LiteralPath $ArchivePath -ErrorAction SilentlyContinue
            throw "Official GitHub download failed. Download $ArchiveName manually at $DownloadUrl and place it next to this script. Details: $($_.Exception.Message)"
        }
    }
    $Hash = (Get-FileHash -LiteralPath $ArchivePath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($Hash -ne $ExpectedSha) {
        throw "SHA-256 mismatch. Actual $Hash; expected $ExpectedSha. Installation cancelled. Remove incorrect ZIP and download again."
    }
    Write-Host 'SHA-256 VERIFIED against original GitHub release metadata.' -ForegroundColor Green

    $Bats = @()
    if (Test-Path -LiteralPath $ExtractDir) {
        $Bats = @(Get-ChildItem -LiteralPath $ExtractDir -File -Recurse -Filter 'Install-Patches.bat')
    }
    if ($Bats.Count -ne 1) {
        # Never overwrite a previously extracted toolchain: it may contain original uninstall state.
        if (Test-Path -LiteralPath $ExtractDir) {
            $entries = @(Get-ChildItem -LiteralPath $ExtractDir -Force)
            if ($entries.Count -gt 0) { throw "Existing extraction is incomplete: $ExtractDir. Do not delete files while the patch is installed. Inspect manually." }
        }
        Write-Host 'Extracting official release archive...'
        Expand-Archive -LiteralPath $ArchivePath -DestinationPath $ExtractDir -Force
        $Bats = @(Get-ChildItem -LiteralPath $ExtractDir -File -Recurse -Filter 'Install-Patches.bat')
    }
    if ($Bats.Count -ne 1) { throw 'Could not uniquely locate original Install-Patches.bat in verified official release.' }
    $OfficialDir = $Bats[0].DirectoryName
    if (-not (Test-Path (Join-Path $OfficialDir 'Manage-Patches.ps1'))) { throw 'Official installer missing Manage-Patches.ps1.' }
    if ($Mode -eq 'Install') {
        $Target = Join-Path $OfficialDir 'Install-Patches.bat'
        Write-Host 'Opening ORIGINAL interactive installer.' -ForegroundColor Green
        Write-Host 'Choose: [1] Install/update -> [1] Client fixes -> press ENTER for recommended variant -> [Y].'
        Write-Host 'For PROJECT ECHO with PZ_Optimization keep the COMPATIBLE variant if proposed.' -ForegroundColor Yellow
    } else {
        $Target = Join-Path $OfficialDir 'Uninstall-Patches.bat'
        if (-not (Test-Path $Target)) { throw 'Original Uninstall-Patches.bat is missing.' }
        Write-Host 'Opening ORIGINAL uninstaller: choose [A] before updating game.' -ForegroundColor Yellow
    }
    Write-Host "Executing: $Target"
    & $Target '-Lang' 'en'
    $exitCode = $LASTEXITCODE
    if ($exitCode -ne 0) { throw "Original installer/uninstaller returned exit code $exitCode. Follow its diagnostic output; nothing else was modified by this wrapper." }
    Write-Host 'Original installer completed. Refer to its report above.' -ForegroundColor Green
    exit 0
} catch {
    Write-Host ("ERROR: " + $_.Exception.Message) -ForegroundColor Red
    exit 1
}
