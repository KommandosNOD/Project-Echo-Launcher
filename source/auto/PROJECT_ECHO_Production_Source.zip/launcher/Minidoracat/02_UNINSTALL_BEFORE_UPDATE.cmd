@echo off
setlocal
cd /d "%~dp0"
echo ================================================
echo  PROJECT ECHO - REMOVE Minidoracat patch
echo ================================================
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0PE_MinidoracatClient.ps1" -Mode Uninstall
set "RC=%ERRORLEVEL%"
echo.
echo Result code: %RC%
pause
exit /b %RC%
