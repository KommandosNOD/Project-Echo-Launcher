using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Security.Cryptography;

namespace PZLauncher;

/// <summary>
/// Opens the pinned, verified upstream Minidoracat interactive installer.
/// Minidoracat is NOT a Workshop mod; it alters Java game files only after player approval.
/// Never bundles unofficially repackaged copyrighted game class files.
/// </summary>
internal static class MinidoracatClientService
{
    internal const string Version = "42.21.0 / client-v0.2.10";
    internal const string OfficialReleaseUrl =
        "https://github.com/Minidoracat/MinidoracatJavaPatchFor42/releases/tag/client-v0.2.10";
    internal static string InstallerRoot => Path.Combine(SettingsStore.StateRoot, "minidoracat-client-v0.2.10");

    private static readonly (string Resource, string FileName)[] Helpers =
    {
        ("project-echo-minidoracat-wrapper.ps1", "PE_MinidoracatClient.ps1"),
        ("project-echo-minidoracat-readme.txt", "README_RU.txt"),
        ("project-echo-minidoracat-sha.txt", "RELEASE_SHA256.txt"),
        ("project-echo-minidoracat-install.cmd", "01_INSTALL_CLIENT.cmd"),
        ("project-echo-minidoracat-uninstall.cmd", "02_UNINSTALL_BEFORE_UPDATE.cmd")
    };

    private static string PrepareVerifiedHelper()
    {
        var root = InstallerRoot;
        Directory.CreateDirectory(root);
        // Never purge this directory: upstream uses it to retain uninstall state/backups.
        if ((File.GetAttributes(root) & FileAttributes.ReparsePoint) != 0)
            throw new IOException("Каталог установщика Minidoracat не должен быть символической ссылкой.");
        foreach (var (resource, name) in Helpers)
        {
            var path = Path.Combine(root, name);
            using var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resource)
                ?? throw new InvalidDataException("Отсутствует встроенный компонент Minidoracat: " + name);
            using var buffer = new MemoryStream();
            stream.CopyTo(buffer);
            var correct = buffer.ToArray();
            // The launcher installs only its own vetted wrapper, not upstream altered .class files.
            if (File.Exists(path))
            {
                if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
                    throw new IOException("Обнаружена символическая ссылка вместо файла установщика: " + path);
                if (SHA256.HashData(File.ReadAllBytes(path)).AsSpan().SequenceEqual(SHA256.HashData(correct)))
                    continue;
            }
            var temp = path + ".new-" + Guid.NewGuid().ToString("N");
            try { File.WriteAllBytes(temp, correct); File.Move(temp, path, overwrite: true); }
            finally { if (File.Exists(temp)) File.Delete(temp); }
        }
        return root;
    }

    internal static void OpenOfficialInstaller(bool remove)
    {
        var root = PrepareVerifiedHelper();
        // The user's supplied installer CMD keeps its console open (pause), so
        // download/checksum/install errors are visible rather than silently disappearing.
        var script = Path.Combine(root, remove ? "02_UNINSTALL_BEFORE_UPDATE.cmd" : "01_INSTALL_CLIENT.cmd");
        var cmd = new ProcessStartInfo
        {
            FileName = script,
            WorkingDirectory = root,
            UseShellExecute = true,
            WindowStyle = ProcessWindowStyle.Normal
        };
        if (Process.Start(cmd) is null)
            throw new IOException("Не удалось открыть официальный интерактивный установщик Minidoracat.");
    }
}
