using System.Windows;
namespace PZLauncher;
public partial class App
{
    private void LauncherSelfUpdate_OnStartup(object sender, StartupEventArgs e)
    {
        LauncherSelfUpdateService.CleanStaleDownloads();
        new MainWindow().Show();
    }
}
