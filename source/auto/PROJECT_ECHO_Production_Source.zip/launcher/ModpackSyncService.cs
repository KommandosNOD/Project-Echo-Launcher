using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace PZLauncher;

// PROJECT_ECHO_DYNAMIC_MODPACK_V1
// Distinct from signed patch files. This signed document is the server's CURRENT requirements.
internal sealed class ModpackSyncService : IDisposable
{
    private const string ManifestUrl = "https://no-signal-pz.komanndosnod.workers.dev/data/modpack.json";
    private readonly HttpClient _http = new(new HttpClientHandler { AllowAutoRedirect = false })
    {
        Timeout = TimeSpan.FromSeconds(35)
    };

    internal sealed class Document
    {
        [JsonPropertyName("schema")] public int Schema { get; set; }
        [JsonPropertyName("channel")] public string Channel { get; set; } = "";
        [JsonPropertyName("revision")] public string Revision { get; set; } = "";
        [JsonPropertyName("gameBuild")] public string GameBuild { get; set; } = "";
        [JsonPropertyName("workshopIds")] public List<string> WorkshopIds { get; set; } = new();
        [JsonPropertyName("modIds")] public List<string> ModIds { get; set; } = new();
    }

    internal async Task<Document> FetchAsync(CancellationToken ct = default)
    {
        var version = "v=" + DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        var body = await FetchBounded(new Uri(ManifestUrl + "?" + version), 512 * 1024, ct);
        var sig = await FetchBounded(new Uri(ManifestUrl.Replace(".json", ".sig", StringComparison.Ordinal) + "?" + version), 2048, ct);
        using var trustedKey = ECDsa.Create();
        using var embedded = Assembly.GetExecutingAssembly().GetManifestResourceStream("trusted-release-public-key.pem")
            ?? throw new InvalidOperationException("Не найден встроенный публичный ключ PROJECT ECHO.");
        using (var reader = new StreamReader(embedded)) trustedKey.ImportFromPem(await reader.ReadToEndAsync(ct));
        if (!trustedKey.VerifyData(body, sig, HashAlgorithmName.SHA256, DSASignatureFormat.Rfc3279DerSequence))
            throw new CryptographicException("Подпись списка серверных модов недействительна. Проверка остановлена.");
        var doc = JsonSerializer.Deserialize<Document>(body) ?? throw new InvalidDataException("Пустой modpack.json");
        if (doc.Schema != 1 || doc.Channel != "stable" || doc.WorkshopIds is null || doc.ModIds is null
            || doc.WorkshopIds.Count > 2000 || doc.ModIds.Count > 3000
            || (doc.WorkshopIds.Count == 0 && doc.ModIds.Count == 0))
            throw new InvalidDataException("Неправильный формат подписанного списка модов.");
        if (!DateTimeOffset.TryParse(doc.Revision, out _)) throw new InvalidDataException("Отсутствует дата ревизии modpack.");
        if (doc.WorkshopIds.Any(x => !Regex.IsMatch(x, @"^[0-9]{5,20}$")) ||
            doc.ModIds.Any(x => string.IsNullOrWhiteSpace(x) || x.Length > 150 || x.Any(c => char.IsControl(c) || c is '/' or '\\' or ';')) ||
            doc.WorkshopIds.Distinct(StringComparer.Ordinal).Count() != doc.WorkshopIds.Count ||
            doc.ModIds.Distinct(StringComparer.OrdinalIgnoreCase).Count() != doc.ModIds.Count)
            throw new InvalidDataException("В подписанном списке некорректные или повторяющиеся идентификаторы.");
        return doc;
    }

    private async Task<byte[]> FetchBounded(Uri uri, int limit, CancellationToken ct)
    {
        using var reply = await _http.GetAsync(uri, HttpCompletionOption.ResponseHeadersRead, ct);
        if (reply.StatusCode != HttpStatusCode.OK) throw new HttpRequestException($"Список серверных модов недоступен: HTTP {(int)reply.StatusCode}");
        if (reply.Content.Headers.ContentLength > limit) throw new InvalidDataException("Слишком большой список модов.");
        await using var stream = await reply.Content.ReadAsStreamAsync(ct);
        using var buffer = new MemoryStream();
        var bytes = new byte[8192];
        int n;
        while ((n = await stream.ReadAsync(bytes, ct)) != 0)
        {
            if (buffer.Length + n > limit) throw new InvalidDataException("Превышен лимит списка модов.");
            buffer.Write(bytes, 0, n);
        }
        return buffer.ToArray();
    }

    internal static IReadOnlyList<string> MissingWorkshopIds(IEnumerable<string> required, IReadOnlyList<string> libraries) =>
        required.Where(id => !libraries.Any(root =>
            Directory.Exists(Path.Combine(root, "steamapps", "workshop", "content", "108600", id))))
        .ToList();

    // PROJECT_ECHO_MODSCAN_FIX_V2_REBUILT: tolerate nested 42/42.20 mod layouts and inaccessible siblings.
    internal static IReadOnlyList<string> MissingModIds(IEnumerable<string> required,
        IEnumerable<string> workshopRoots, string localModsRoot)
    {
        var found = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var roots = workshopRoots.Append(localModsRoot)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase);
        foreach (var root in roots)
        {
            if (!Directory.Exists(root)) continue;
            var folders = new Stack<string>();
            folders.Push(root);
            while (folders.Count > 0)
            {
                var current = folders.Pop();
                try
                {
                    foreach (var file in Directory.EnumerateFiles(current))
                    {
                        if (!string.Equals(Path.GetFileName(file), "mod.info", StringComparison.OrdinalIgnoreCase)) continue;
                        try
                        {
                            foreach (var line in File.ReadLines(file))
                            {
                                var match = Regex.Match(line.TrimStart('\uFEFF'), @"^\s*id\s*=\s*(.*?)\s*$", RegexOptions.IgnoreCase);
                                if (!match.Success) continue;
                                var id = match.Groups[1].Value.Trim().Trim('"');
                                if (id.Length > 0) found.Add(id);
                                break;
                            }
                        }
                        catch (IOException) { }
                        catch (UnauthorizedAccessException) { }
                    }
                    foreach (var folder in Directory.EnumerateDirectories(current))
                    {
                        try
                        {
                            if ((File.GetAttributes(folder) & FileAttributes.ReparsePoint) == 0) folders.Push(folder);
                        }
                        catch (IOException) { }
                        catch (UnauthorizedAccessException) { }
                    }
                }
                catch (IOException) { }
                catch (UnauthorizedAccessException) { }
            }
        }
        return required.Where(id => !found.Contains(id)).ToList();
    }

    public void Dispose() => _http.Dispose();
}
