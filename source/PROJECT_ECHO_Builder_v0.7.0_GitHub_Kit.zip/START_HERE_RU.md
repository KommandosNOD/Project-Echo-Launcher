# PROJECT ECHO Builder 0.7.0 — как получить готовый EXE без CMD

## 1. Установить новую версию Builder через GitHub Actions

1. Открой GitHub → KommandosNOD/Project-Echo-Launcher → Code → ветка `main` → папка `source`.
2. `Add file` → `Upload files`: добавь `ProjectEcho_LauncherBuilder_v0.7.0_SOURCE.zip` из `source` этого комплекта в папку `source` репозитория.
3. Однократно создай через `Add file` → `Create new file` путь `.github/workflows/build-builder-v070.yml`. Скопируй туда текст из `workflow/build-builder-v070.yml`; Commit changes в `main`.
4. Actions → **Build PROJECT ECHO Builder 0.7.0 (Windows)** → **Run workflow**.
5. В успешной сборке в **Artifacts** скачай `PROJECT-ECHO-Builder-0.7.0-Windows-x64`, распакуй ВСЁ в новую папку и открой `ProjectEcho.Builder.exe`.

## 2. Единая сборка следующих версий клиента в Builder

Во вкладке **EXE PRODUCTION** сначала нажми «Подключить GitHub-сборку (один раз)». Builder добавит в GitHub единственный workflow `build-project-echo-auto.yml`. Нужно, чтобы GitHub CLI (`gh`) имел права на запись workflows.

Для последующего выпуска клиента подготовь ZIP с корневыми папками `launcher/` и `updater/` и новой production-версией в `launcher/PZLauncher.csproj` (например, 0.8.2). В Builder введи ту же версию и выбери ZIP. Нажми **«СОБРАТЬ + ПРОВЕРИТЬ + ПОДПИСАТЬ»**. Builder загрузит исходники в публичный GitHub, соберёт EXE на Windows, проверит его SHA-256, создаст подписанный кандидат. Приватный PEM-ключ не отправляется в GitHub.

**ВАЖНО:** EXE игрокам автоматически НЕ выпускается. Сначала лично проверь кандидат на Windows, затем нажми старую кнопку публикации EXE PRODUCTION с подтверждением. Не используй версию 0.8.1 повторно — она уже опубликована.

## Ограничения

Схема GitHub-сборки требует первой установки workflow; после этого ручная загрузка исходников в браузере для каждого нового релиза не нужна. Модпак, новости, сайт и текущая production-версия 0.8.1 не затрагиваются.

Эту версию C# проверили статически (синтаксическая структура XAML/XML и обработчики); реальную Windows-компиляцию и сетевой запуск GitHub Actions необходимо проверить первой сборкой.
