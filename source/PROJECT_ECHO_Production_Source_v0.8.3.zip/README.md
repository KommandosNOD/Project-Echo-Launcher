# PROJECT ECHO Production Launcher v0.8.3 — SOURCE ONLY

What's new: settings buttons for pinned Minidoracat 42.21.0 client patch 0.2.10: INSTALL and UNINSTALL before game updates. User-supplied wrapper is embedded and opens the upstream *interactive* installer (via installed PowerShell). It checks the upstream zip SHA-256 before running. Upstream client package is NOT redistributed in this source archive. Game .class files are never bundled with the launcher.

IMPORTANT: The Minidoracat patch requires the exact PZ 42.21.0 game binary. The upstream installer verifies the official ProjectZomboid.jar checksum. If it does not match, stop; do not bypass the check. Close the game. If PZ_Optimization is used: turn off Warm-start cache, launch game once to menu, exit, then use installer. Before updating the GAME, uninstall Minidoracat via the second button and choose A. Keep the official install state stored under PZCommunityLauncher/minidoracat-client-v0.2.10.

Local mod patches continue to use signed schema 2 manifest `mods/default.txt` and selected mod files; the launcher writes `default.txt` to `%USERPROFILE%/Zomboid/mods/default.txt` using the existing backup-and-atomic-update logic. It is NOT a standalone mod.info plugin.

This ZIP is for GitHub Actions/Builder v0.7.x Windows compilation. No EXE is included. Do not publish a new version before a real Windows compile and acceptance test.
