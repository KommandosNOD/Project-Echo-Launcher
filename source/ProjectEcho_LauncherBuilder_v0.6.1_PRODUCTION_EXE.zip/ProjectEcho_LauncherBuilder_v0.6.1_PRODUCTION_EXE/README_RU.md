# PROJECT ECHO Launcher Builder v0.6.1 — EXE PRODUCTION

Новая вкладка «EXE PRODUCTION». Все функции v0.6.0 сохранены.

## Порядок выпуска EXE — без PowerShell / ручного подписания

1. Собери `PROJECT_ECHO_Production_Source_v0.8.1.zip` через GitHub Actions (замени путь в workflow). Получи `ProjectEchoLauncher.exe` в Artifacts.
2. На Windows распакуй EXE из GitHub Actions. Проверь запуск, новости, настройки, версию `v0.8.1`, открытие игры.
3. Открой Launcher Builder v0.6.1, в настройках укажи `C:\Users\KommandosNOD\Desktop\pzportal2`.
4. В «EXE PRODUCTION» выбери собранный `ProjectEchoLauncher.exe`, версию `0.8.1` и нажми «Создать подписанный production-кандидат».
5. Нажми «Проверить подпись и SHA-256».
6. Введи **RELEASE-PROD-EXE** и нажми «ОПУБЛИКОВАТЬ EXE PRODUCTION». Подтверди предупреждение.

Builder требует авторизованный GitHub CLI (gh) и Git for Windows, как в уже работающей вкладке EXE TEST.
Пароль и токены не передаются в коде или пакете. Для ECDSA используется только оригинальный ключ
`pzportal2/secrets/release-private.pem` и соответствующий публичный `pzportal2/launcher/TrustedReleasePublicKey.pem`.
Нельзя менять ключи, старые лаунчеры перестанут доверять подписи.

## Последовательность внутри Builder

- Собирает копию EXE без изменения байтов; сверяет версию из файловых ресурсов.
- Подписывает `launcher.json` (schema=1, kind=PROJECT_ECHO_LAUNCHER, channel=production, tag=echo-launcher-v0.8.1).
- Верифицирует ECDSA по текущему ключу и SHA-256 подписанного EXE.
- Проверяет gh auth (KommandosNOD), наличие GitHub production-ветки, существующие теги и релизы.
- Сначала публикует EXE как GitHub Release (создаёт Draft при необходимости); **не перезаписывает чужой EXE**.
- Сверяет SHA-256 размещённого на GitHub asset с локальным подписанным кандидатом.
- Публикует `launcher.json` и `launcher.sig` в `project-echo-schema2-production/updates/launcher-production/`.
- Проверяет побайтовую идентичность Git blobs до/после коммита и удалённый SHA ветки.
- После этого устанавливает GitHub Release как Latest. Уже существующий stable URL сайта продолжит работать.

При ошибке на промежуточном этапе **сначала** смотрите GitHub Release и вкладку Журнал.
Не повторяйте публикацию вслепую; операция может быть частично завершена.

## Границы

Никаких изменений `updates/schema2-staging`, модов, `updates/stable`, сайта или Cloudflare.
Нет автоматического удаления файлов. GitHub Actions и локальная компиляция .NET на Windows отдельно проверяются.

## Исходники и запуск Builder

`BUILD_BUILDER.cmd` — прежний скрипт сборки Builder под Windows. Затем `dist/ProjectEcho.Builder.exe`.
После получения EXE Builder, в дальнейших выпусках **командная строка не требуется**.
