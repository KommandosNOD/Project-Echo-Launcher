using System.IO;
using System.Security.Cryptography;
using System.Text;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder.Services;

/// <summary>
/// Creates a SMALL isolated test source, with a new mod and changed default.txt.
/// Never writes to the user's live Zomboid/mods source.
/// </summary>
internal sealed class SmokeTestService
{
    internal sealed record Result(string DraftPath, string SourcePath, string BaseMod,
        IReadOnlyList<string> ChangedPaths);

    public async Task<Result> CreateAsync(BuilderSettings settings, Action<string>? log, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(settings.LastSignedTestDraftPath))
            throw new InvalidOperationException("Сначала подпиши и проверь первоначальный тестовый пакет. Он станет эталоном для сравнения.");
        var inventory = await new ModInventoryService().ScanAsync(settings, log, ct);
        var chosen = inventory.Mods
            .Where(m => m.IsSelected && m.FileCount > 0 && m.Name != "ProjectEcho_BuilderSmokeTest")
            .OrderBy(m => m.Name.Equals("ProjectEchoBetterBeltsRU", StringComparison.OrdinalIgnoreCase) ? 0 : 1)
            .ThenBy(m => m.Bytes)
            .FirstOrDefault() ?? throw new InvalidOperationException("Выбери хотя бы один локальный мод (лучше BetterBelts).");
        if (chosen.Bytes > 50L * 1024 * 1024)
            throw new InvalidOperationException("Выбранный для песочницы мод больше 50 МБ. Отметь небольшой мод и повтори.");
        var originalDefault = inventory.Files.SingleOrDefault(f => f.Path == "mods/default.txt")
            ?? throw new FileNotFoundException("В исходной папке mods нет default.txt.");

        // Test-only source is always under the output directory, never under the live mods root.
        var stamp = DateTimeOffset.UtcNow.ToString("yyyyMMdd-HHmmss-fff");
        var source = Path.GetFullPath(Path.Combine(settings.OutputRoot, "test-sources", stamp, "mods"));
        var liveRoot = Path.GetFullPath(settings.ModsRoot).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        if (source.StartsWith(liveRoot, StringComparison.OrdinalIgnoreCase) ||
            liveRoot.StartsWith(source.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Небезопасное пересечение пути тестового источника с рабочей папкой модов.");
        if (Directory.Exists(source)) throw new IOException("Папка тестового источника уже существует.");
        Directory.CreateDirectory(source);
        try
        {
            var entries = inventory.Files.Where(f => f.Path == "mods/default.txt" ||
                f.Path.StartsWith("mods/" + chosen.Name + "/", StringComparison.OrdinalIgnoreCase)).ToArray();
            foreach (var item in entries)
            {
                ct.ThrowIfCancellationRequested();
                var relative = PathSafety.ValidatePatchPath(item.Path)["mods/".Length..];
                var destination = Path.GetFullPath(Path.Combine(source, relative.Replace('/', Path.DirectorySeparatorChar)));
                if (!destination.StartsWith(source.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar,
                    StringComparison.OrdinalIgnoreCase))
                    throw new InvalidDataException("Некорректный путь при копировании тестового файла.");
                Directory.CreateDirectory(Path.GetDirectoryName(destination)!);
                await using (var input = new FileStream(item.FullPath, FileMode.Open, FileAccess.Read, FileShare.Read,
                    65536, FileOptions.Asynchronous | FileOptions.SequentialScan))
                await using (var output = new FileStream(destination, FileMode.CreateNew, FileAccess.Write, FileShare.None,
                    65536, FileOptions.Asynchronous | FileOptions.SequentialScan))
                    await input.CopyToAsync(output, ct);
                await using var checkStream = File.OpenRead(destination);
                var checksum = Convert.ToHexString(await SHA256.HashDataAsync(checkStream, ct));
                if (new FileInfo(destination).Length != item.Size || !checksum.Equals(item.Sha256, StringComparison.OrdinalIgnoreCase))
                    throw new IOException("Исходный файл изменился при копировании: " + item.Path);
            }

            // The test marker is appended to a COPY, not to the user's real default.txt.
            var copiedDefault = Path.Combine(source, "default.txt");
            await File.AppendAllTextAsync(copiedDefault,
                "\r\n# PROJECT_ECHO_TEST_DEFAULT_ONLY_" + stamp + "\r\n", Encoding.UTF8, ct);

            var fake = "ProjectEcho_BuilderSmokeTest";
            var fakeDir = Path.Combine(source, fake);
            var common = Path.Combine(fakeDir, "common");
            var luaDir = Path.Combine(fakeDir, "42", "media", "lua", "shared");
            Directory.CreateDirectory(common);
            Directory.CreateDirectory(luaDir);
            await File.WriteAllTextAsync(Path.Combine(common, "mod.info"),
                "name=PROJECT ECHO Builder Smoke Test\nid=ProjectEcho_BuilderSmokeTest\ndescription=LOCAL TEST ONLY\n", ct);
            await File.WriteAllTextAsync(Path.Combine(luaDir, "ProjectEchoBuilderSmokeTest.lua"),
                "-- Generated test file. Do not install into a production game.\n" +
                "ProjectEchoBuilderSmokeTestVersion = '" + stamp + "'\n", ct);

            var sandboxSettings = new BuilderSettings
            {
                ModsRoot = source,
                ProjectRoot = settings.ProjectRoot,
                OutputRoot = settings.OutputRoot,
                ClientVersion = settings.ClientVersion,
                LastSignedTestDraftPath = settings.LastSignedTestDraftPath,
                ExcludedAutoFolders = new(),
                AdditionalFolders = new()
            };
            var sourceInventory = await new ModInventoryService().ScanAsync(sandboxSettings, log, ct);
            var stage = new StageService();
            var changes = stage.GetChanges(sourceInventory, sandboxSettings);
            var expected = new[] { "mods/default.txt", "mods/" + fake + "/common/mod.info",
                "mods/" + fake + "/42/media/lua/shared/ProjectEchoBuilderSmokeTest.lua" };
            foreach (var entry in expected)
            {
                if (!changes.Changed.Any(c => c.Path == entry))
                    throw new InvalidDataException("Тестовое изменение не обнаружено: " + entry);
            }
            var draft = await stage.StageAsync(sourceInventory, sandboxSettings, log, ct);
            log?.Invoke($"ПЕСОЧНИЦА: скопирован мод {chosen.Name}; создан новый {fake}; изменён ТОЛЬКО тестовый default.txt");
            return new Result(draft, source, chosen.Name, changes.Changed.Select(c => c.Path).ToArray());
        }
        catch
        {
            // Preserve the isolated sandbox as diagnostic evidence if something went wrong.
            log?.Invoke("Тестовая песочница не завершена: " + source);
            throw;
        }
    }
}
