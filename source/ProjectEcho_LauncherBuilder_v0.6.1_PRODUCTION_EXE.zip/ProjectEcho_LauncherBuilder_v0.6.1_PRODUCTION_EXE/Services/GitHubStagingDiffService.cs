using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text.Json;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder.Services;

// Read-only comparison against the public TEST branch. This service NEVER publishes,
// modifies the checkout, or emits retired/deletion instructions.
public sealed record StagingDiffRow(string Change, string Path, long Bytes);

internal sealed class GitHubStagingDiffService
{
    private const string RemoteBase = "https://raw.githubusercontent.com/KommandosNOD/Project-Echo-Launcher/project-echo-schema2-staging/updates/schema2-staging/";
    private const int MaxManifestBytes = 4 * 1024 * 1024;
    private const int MaxSigBytes = 256;
    private readonly LocalDraftSigningService _signer = new();

    internal sealed record Report(string CandidateVersion, string BaselineVersion,
        int Added, int Modified, int Same, int NotSelected, long ClientDownloadBytes,
        long CandidateBytes, IReadOnlyList<StagingDiffRow> Rows, string CandidateSha256);

    public async Task<Report> CompareAsync(string folder, BuilderSettings settings, CancellationToken ct)
    {
        var details = await _signer.VerifySignedAsync(folder, settings, ct);
        // The candidate is already required to be a complete signed snapshot; verify
        // its origin and unchanged source in the caller's GitHubStagingService.PreflightAsync.
        var candidateBytes = await File.ReadAllBytesAsync(Path.Combine(details.Folder, "manifest.json"), ct);
        var candidate = Parse(candidateBytes);
        using var client = new HttpClient { Timeout = TimeSpan.FromSeconds(35) };
        client.DefaultRequestHeaders.CacheControl = new CacheControlHeaderValue { NoCache = true, NoStore = true };

        // A random query string avoids a cached manifest/sig pair from an older push.
        // Both URLs use the SAME cache-busting token.
        var cacheToken = "?echo_diff=" + Guid.NewGuid().ToString("N");
        var remoteData = await DownloadAsync(client, RemoteBase + "manifest.json" + cacheToken, MaxManifestBytes, true, ct);
        OwnerManifest? old = null;
        if (remoteData is not null)
        {
            var remoteSignature = await DownloadAsync(client, RemoteBase + "manifest.sig" + cacheToken, MaxSigBytes, false, ct)
                ?? throw new CryptographicException("В GitHub отсутствует manifest.sig.");
            if (remoteSignature.Length is < 16 or > MaxSigBytes)
                throw new CryptographicException("Неверный размер подписи GitHub.");
            var keyPath = Path.Combine(settings.ProjectRoot, "launcher", "TrustedReleasePublicKey.pem");
            if (!File.Exists(keyPath)) throw new FileNotFoundException("Не найден доверенный публичный ключ клиента.", keyPath);
            if ((File.GetAttributes(keyPath) & FileAttributes.ReparsePoint) != 0)
                throw new InvalidDataException("Символическая ссылка на публичный ключ запрещена.");
            using var key = ECDsa.Create();
            key.ImportFromPem(await File.ReadAllTextAsync(keyPath, ct));
            if (!key.VerifyData(remoteData, remoteSignature, HashAlgorithmName.SHA256,
                DSASignatureFormat.Rfc3279DerSequence))
                throw new CryptographicException("Подпись текущего GitHub TEST манифеста не совпадает. Сравнение отменено.");
            old = Parse(remoteData);
        }

        var earlier = old?.Files.ToDictionary(f => f.Path, StringComparer.OrdinalIgnoreCase)
            ?? new Dictionary<string, ManifestFile>(StringComparer.OrdinalIgnoreCase);
        var current = candidate.Files.ToDictionary(f => f.Path, StringComparer.OrdinalIgnoreCase);
        var rows = new List<StagingDiffRow>();
        int added = 0, modified = 0, same = 0, omitted = 0;
        long transfer = 0, total = 0;
        foreach (var file in candidate.Files.OrderBy(f => f.Path, StringComparer.OrdinalIgnoreCase))
        {
            ct.ThrowIfCancellationRequested();
            total = checked(total + file.Size);
            if (!earlier.TryGetValue(file.Path, out var before))
            {
                added++;
                transfer = checked(transfer + file.Size);
                rows.Add(new StagingDiffRow("НОВЫЙ", file.Path, file.Size));
            }
            else if (before.Size != file.Size || !before.Sha256.Equals(file.Sha256, StringComparison.OrdinalIgnoreCase))
            {
                modified++;
                transfer = checked(transfer + file.Size);
                rows.Add(new StagingDiffRow("ИЗМЕНЁН", file.Path, file.Size));
            }
            else same++;
        }
        foreach (var file in earlier.Values.OrderBy(f => f.Path, StringComparer.OrdinalIgnoreCase))
        {
            if (current.ContainsKey(file.Path)) continue;
            omitted++;
            rows.Add(new StagingDiffRow("НЕ В ПАКЕТЕ", file.Path, file.Size));
        }
        // Status 'НЕ В ПАКЕТЕ' is informational only. Client deletion is NOT supported.
        return new Report(candidate.Version, old?.Version ?? "нет предыдущей публикации",
            added, modified, same, omitted, transfer, total, rows,
            Convert.ToHexString(SHA256.HashData(candidateBytes)).ToLowerInvariant());
    }

    private static OwnerManifest Parse(byte[] bytes)
    {
        var doc = JsonSerializer.Deserialize<OwnerManifest>(bytes)
            ?? throw new InvalidDataException("Пустой манифест.");
        if (doc.Schema != 2 || doc.Kind != "PROJECT_ECHO_LOCAL_MODS" ||
            doc.Channel != "stable" || doc.Retired is null || doc.Retired.Count != 0 ||
            string.IsNullOrWhiteSpace(doc.Version) || doc.Files is null || doc.Files.Count is < 2 or > 16000 ||
            !doc.Files.Any(f => f.Path == "mods/default.txt"))
            throw new InvalidDataException("Неверный формат манифеста TEST (schema 2).");
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var f in doc.Files)
        {
            if (f is null || !seen.Add(PathSafety.ValidatePatchPath(f.Path)) ||
                f.Size < 0 || f.Sha256 is null || f.Sha256.Length != 64 ||
                !f.Sha256.All(Uri.IsHexDigit) || f.Url != "files/" + f.Path)
                throw new InvalidDataException("Неверная запись файла в манифесте.");
        }
        return doc;
    }

    private static async Task<byte[]?> DownloadAsync(HttpClient client, string address, int max, bool allowMissing,
        CancellationToken ct)
    {
        using var response = await client.GetAsync(address, HttpCompletionOption.ResponseHeadersRead, ct);
        if (allowMissing && response.StatusCode == HttpStatusCode.NotFound) return null;
        response.EnsureSuccessStatusCode();
        if (response.Content.Headers.ContentLength is long len && len > max)
            throw new InvalidDataException("GitHub вернул слишком большой файл манифеста/подписи.");
        await using var stream = await response.Content.ReadAsStreamAsync(ct);
        using var collected = new MemoryStream();
        var buffer = new byte[16384];
        while (true)
        {
            var count = await stream.ReadAsync(buffer, ct);
            if (count == 0) break;
            if (collected.Length + count > max)
                throw new InvalidDataException("Превышен лимит данных GitHub.");
            collected.Write(buffer, 0, count);
        }
        return collected.ToArray();
    }
}
