using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder.Services;

// Publisher is owner-only: EXACT production repo and branch. Never writes to main, stable or mods.
internal sealed class ProductionExeReleaseService
{
    private const string Repo="KommandosNOD/Project-Echo-Launcher";
    private const string Branch="project-echo-schema2-production";
    private const string Subdir="updates/launcher-production";
    private const string Asset="ProjectEchoLauncher.exe";
    private readonly ProductionExeCandidateService _candidates=new();
    internal sealed record PublishInfo(string Tag,string Commit,string ManifestUrl,string ReleaseUrl);
    private sealed record CommandResult(int Code,string Stdout,string Stderr);

    private static async Task<CommandResult> RunAsync(string binary,IEnumerable<string> args,string cwd,CancellationToken ct,Action<string>? log=null)
    {
        Directory.CreateDirectory(cwd);
        var psi=new ProcessStartInfo(binary) {WorkingDirectory=cwd,UseShellExecute=false,RedirectStandardOutput=true,
            RedirectStandardError=true,CreateNoWindow=true};
        foreach(var arg in args)psi.ArgumentList.Add(arg);
        using var process=new Process{StartInfo=psi};
        try{if(!process.Start())throw new IOException("Не удалось запустить "+binary);}
        catch(Win32Exception ex){throw new InvalidOperationException("Для публикации нужны Git for Windows и GitHub CLI (gh auth login).",ex);}
        var o=new StringBuilder();var e=new StringBuilder();
        async Task ReadAsync(StreamReader reader,StringBuilder target,bool errors)
        {
            while(await reader.ReadLineAsync(ct) is { } line)
            {
                if(target.Length<200000)target.AppendLine(line);
                if(errors && line.Length<400)log?.Invoke(line);
            }
        }
        using var reg=ct.Register(()=>{try{if(!process.HasExited)process.Kill(true);}catch{}});
        await Task.WhenAll(ReadAsync(process.StandardOutput,o,false),ReadAsync(process.StandardError,e,true),process.WaitForExitAsync(ct));
        return new CommandResult(process.ExitCode,o.ToString().Trim(),e.ToString().Trim());
    }
    private static async Task<string> MustAsync(string app,IEnumerable<string> args,string dir,CancellationToken ct,Action<string>? log=null)
    {
        var r=await RunAsync(app,args,dir,ct,log);
        if(r.Code!=0)throw new IOException(app+" завершился с кодом "+r.Code+": "+(r.Stderr.Length>2000?r.Stderr[..2000]:r.Stderr));
        return r.Stdout;
    }
    private static async Task<JsonElement?> FindReleaseAsync(string tag,string dir,CancellationToken ct)
    {
        for(int page=1;page<=5;page++)
        {
            var raw=await MustAsync("gh",new[]{"api",$"repos/{Repo}/releases?per_page=100&page={page}"},dir,ct);
            using var doc=JsonDocument.Parse(raw);
            if(doc.RootElement.ValueKind!=JsonValueKind.Array)throw new InvalidDataException("GitHub не вернул массив релизов.");
            foreach(var r in doc.RootElement.EnumerateArray())
                if(r.GetProperty("tag_name").GetString()==tag)return r.Clone();
            if(doc.RootElement.GetArrayLength()<100)return null;
        }
        throw new InvalidOperationException("Более 500 релизов. Проверка безопасности не выполнена.");
    }
    private static async Task<JsonElement> WaitReleaseAsync(string tag,string dir,CancellationToken ct)
    {
        for(int i=0;i<12;i++)
        {
            var r=await FindReleaseAsync(tag,dir,ct);
            if(r.HasValue)
            {
                var assets=r.Value.GetProperty("assets").EnumerateArray().ToArray();
                if(assets.Any(a=>a.GetProperty("name").GetString()==Asset &&
                    a.TryGetProperty("digest",out var digest) && digest.ValueKind==JsonValueKind.String &&
                    digest.GetString()?.StartsWith("sha256:")==true)) return r.Value;
            }
            await Task.Delay(TimeSpan.FromSeconds(3),ct);
        }
        throw new IOException("GitHub ещё не подтвердил SHA-256 загруженного EXE; манифест не публиковался. Проверь Release вручную.");
    }
    private static void CheckRelease(JsonElement release,ProductionExeCandidateService.CandidateInfo c)
    {
        if(release.GetProperty("tag_name").GetString()!=c.Tag ||release.GetProperty("prerelease").GetBoolean())
            throw new InvalidDataException("Это не обычный production GitHub Release.");
        var assets=release.GetProperty("assets").EnumerateArray().Where(a=>a.GetProperty("name").GetString()==Asset).ToArray();
        if(assets.Length!=1 ||assets[0].GetProperty("size").GetInt64()!=c.Bytes)
            throw new InvalidDataException("GitHub Release содержит неправильный EXE или размер.");
        var hash=assets[0].GetProperty("digest").GetString();
        if(!string.Equals(hash,"sha256:"+c.Sha256,StringComparison.OrdinalIgnoreCase))
            throw new CryptographicException("SHA-256 GitHub Release asset отличается от локального подписанного EXE!");
    }
    internal async Task<PublishInfo> PublishAsync(string folder,BuilderSettings settings,Action<string> log,CancellationToken ct)
    {
        var candidate=await _candidates.VerifyAsync(folder,settings,ct);
        var work=Path.Combine(Path.GetFullPath(settings.OutputRoot),"github-production-exe-work");
        Directory.CreateDirectory(work);
        var login=await MustAsync("gh",new[]{"api","user","--jq",".login"},work,ct);
        if(!string.Equals(login.Trim(),"KommandosNOD",StringComparison.OrdinalIgnoreCase))
            throw new UnauthorizedAccessException("Авторизация gh должна быть от KommandosNOD.");
        var push=await MustAsync("gh",new[]{"api",$"repos/{Repo}","--jq",".permissions.push"},work,ct);
        if(push.Trim()!="true")throw new UnauthorizedAccessException("GitHub не дал право push.");
        const string remote="https://github.com/"+Repo+".git";
        var branchRef="refs/heads/"+Branch;
        var remoteHead=await MustAsync("git",new[]{"ls-remote","--heads",remote,branchRef},work,ct);
        if(remoteHead.Length==0)throw new InvalidDataException("Production-ветка GitHub не найдена.");
        log("Проверка GitHub Release: "+candidate.Tag);
        var release=await FindReleaseAsync(candidate.Tag,work,ct);
        if(!release.HasValue)
        {
            var tag=await MustAsync("git",new[]{"ls-remote","--tags",remote,"refs/tags/"+candidate.Tag},work,ct);
            if(tag.Length!=0)throw new InvalidOperationException("Тег есть, Release отсутствует. Подмена тега запрещена.");
            candidate=await _candidates.VerifyAsync(folder,settings,ct);
            log("Загружаем EXE в GitHub DRAFT (не в рабочий канал обновлений).");
            await MustAsync("gh",new[]{"release","create",candidate.Tag,
                Path.Combine(candidate.Directory,Asset),Path.Combine(candidate.Directory,"SHA256SUMS.txt"),
                "--repo",Repo,"--target","main","--draft","--latest=false",
                "--title","PROJECT ECHO Launcher v"+candidate.Version,
                "--notes","PROJECT ECHO Launcher v"+candidate.Version+" — signed production release."},work,ct,log);
        }
        release=await WaitReleaseAsync(candidate.Tag,work,ct);
        CheckRelease(release.Value,candidate);
        if(release.Value.GetProperty("draft").GetBoolean())
        {
            log("Проверено: digest GitHub совпадает. Публикуем Release без переключения Latest.");
            await MustAsync("gh",new[]{"release","edit",candidate.Tag,"--repo",Repo,
                "--draft=false","--prerelease=false","--latest=false"},work,ct,log);
            release=await WaitReleaseAsync(candidate.Tag,work,ct);
            CheckRelease(release.Value,candidate);
            if(release.Value.GetProperty("draft").GetBoolean())throw new IOException("Release остался черновиком.");
        }
        else log("GitHub Release уже опубликован, его EXE сверился по SHA-256 — повторно не загружаем.");
        candidate=await _candidates.VerifyAsync(folder,settings,ct);
        // Do not publish older or same version over an existing signed channel.
        var checkout=Path.Combine(work,"checkout-"+Guid.NewGuid().ToString("N"));
        try
        {
            await MustAsync("git",new[]{"clone","--depth","1","--single-branch","--branch",Branch,remote,checkout},work,ct,log);
            var branch=await MustAsync("git",new[]{"branch","--show-current"},checkout,ct);
            if(branch.Trim()!=Branch)throw new InvalidDataException("Неверная ветка checkout, публикация остановлена.");
            var dest=Path.Combine(checkout,"updates","launcher-production");
            Directory.CreateDirectory(dest);
            var prior=Path.Combine(dest,"launcher.json");
            if(File.Exists(prior))
            {
                using var doc=JsonDocument.Parse(await File.ReadAllBytesAsync(prior,ct));
                if(!Version.TryParse(doc.RootElement.GetProperty("version").GetString(),out var old)||
                    !Version.TryParse(candidate.Version,out var next)||next<=old)
                    throw new InvalidOperationException("Нельзя повторно опубликовать ту же или более старую версию.");
            }
            foreach(var name in new[]{"launcher.json","launcher.sig"})
                File.Copy(Path.Combine(candidate.Directory,name),Path.Combine(dest,name),true);
            await File.WriteAllTextAsync(Path.Combine(dest,".gitattributes"),"# exact ECDSA signed bytes\n* -text\n",new UTF8Encoding(false),ct);
            await MustAsync("git",new[]{"add","--",Subdir},checkout,ct);
            foreach(var name in new[]{"launcher.json","launcher.sig"})
            {
                var path=Subdir+"/"+name;
                var indexed=await MustAsync("git",new[]{"rev-parse",":"+path},checkout,ct);
                var disk=await MustAsync("git",new[]{"hash-object","--no-filters",Path.Combine(dest,name)},checkout,ct);
                if(!indexed.Equals(disk,StringComparison.OrdinalIgnoreCase))
                    throw new CryptographicException("Git изменил байты подписанного манифеста: "+name);
            }
            var changes=(await MustAsync("git",new[]{"diff","--cached","--name-only"},checkout,ct))
                .Split('\n',StringSplitOptions.RemoveEmptyEntries|StringSplitOptions.TrimEntries);
            if(changes.Length==0||changes.Any(x=>!x.StartsWith(Subdir+"/",StringComparison.Ordinal)))
                throw new InvalidDataException("В индекс Git попали не-production-EXE файлы.");
            candidate=await _candidates.VerifyAsync(folder,settings,ct);
            await MustAsync("git",new[]{"-c","user.name=PROJECT ECHO OWNER",
                "-c","user.email=project-echo@users.noreply.github.com","commit","-m",
                "release: signed launcher production v"+candidate.Version},checkout,ct,log);
            var sha=await MustAsync("git",new[]{"rev-parse","HEAD"},checkout,ct);
            foreach(var name in new[]{"launcher.json","launcher.sig"})
            {
                var blob=await MustAsync("git",new[]{"rev-parse","HEAD:"+Subdir+"/"+name},checkout,ct);
                var disk=await MustAsync("git",new[]{"hash-object","--no-filters",Path.Combine(dest,name)},checkout,ct);
                if(!blob.Equals(disk,StringComparison.OrdinalIgnoreCase))
                    throw new CryptographicException("Подписанный файл изменился в коммите.");
            }
            await MustAsync("git",new[]{"push","origin","HEAD:"+branchRef},checkout,ct,log);
            var refSha=await MustAsync("git",new[]{"ls-remote","origin",branchRef},checkout,ct);
            if(!refSha.StartsWith(sha+"\t",StringComparison.OrdinalIgnoreCase))
                throw new IOException("GitHub production branch не совпадает с загруженным коммитом.");
            // Only after signed metadata is published does the Release become "Latest".
            try{await MustAsync("gh",new[]{"release","edit",candidate.Tag,"--repo",Repo,"--latest"},work,ct,log);}
            catch(Exception ex){log("ВНИМАНИЕ: подписанное обновление уже опубликовано, но Latest не установлен: "+ex.Message);}
            var uri="https://raw.githubusercontent.com/"+Repo+"/"+sha+"/"+Subdir+"/launcher.json";
            log("Готов production EXE: "+uri);
            return new PublishInfo(candidate.Tag,sha,uri,"https://github.com/"+Repo+"/releases/tag/"+candidate.Tag);
        }
        finally{try{if(Directory.Exists(checkout))Directory.Delete(checkout,true);}catch(Exception e){log("Очистка временной папки: "+e.Message);}}
    }
}
