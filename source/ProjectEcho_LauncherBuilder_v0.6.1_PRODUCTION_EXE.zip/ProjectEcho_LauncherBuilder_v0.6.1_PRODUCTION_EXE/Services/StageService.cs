using System.IO;
using System.Security.Cryptography;
using System.Text.Json;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder.Services;

internal sealed class StageService
{
    internal sealed record ChangeSummary(List<FileChange> Changed, List<FileChange> Retired, int Unchanged, bool ReferenceFound, string ReferenceLabel);

    public ChangeSummary GetChanges(InventoryResult current, BuilderSettings settings)
    {
        var selected = SelectedFiles(current);
        var reference = ReferenceFiles(settings, out bool referenceFound, out string referenceLabel);
        var changed = new List<FileChange>();
        foreach (var file in selected)
        {
            if (!reference.TryGetValue(file.Path, out var old))
                changed.Add(new FileChange(file.Path, "НОВЫЙ", file.Size, file.Sha256));
            else if (!string.Equals(file.Sha256, old.Sha256, StringComparison.OrdinalIgnoreCase))
                changed.Add(new FileChange(file.Path, "ИЗМЕНЁН", file.Size, file.Sha256));
        }
        var alive = new HashSet<string>(selected.Select(f => f.Path), StringComparer.OrdinalIgnoreCase);
        // The old published set can include folders the owner intentionally didn't select.
        // These are only *candidates* for review; not a deletion instruction.
        var retired = reference.Values.Where(f => !alive.Contains(f.Path))
            .Select(f => new FileChange(f.Path, "НЕ В ПАКЕТЕ", f.Size, f.Sha256))
            .OrderBy(f => f.Path, StringComparer.OrdinalIgnoreCase).ToList();
        return new ChangeSummary(changed.OrderBy(f => f.Path, StringComparer.OrdinalIgnoreCase).ToList(),
            retired, selected.Count - changed.Count, referenceFound, referenceLabel);
    }

    public async Task<string> StageAsync(InventoryResult inventory, BuilderSettings settings,
        Action<string>? log, CancellationToken ct, bool fullSnapshot = false)
    {
        var chosen = SelectedFiles(inventory);
        if (!inventory.Mods.Any(m => m.IsSelected && m.FileCount > 0))
            throw new InvalidOperationException("Не выбрано ни одной папки мода с файлами.");
        if (!chosen.Any(f => f.Path == "mods/default.txt"))
            throw new InvalidOperationException("default.txt не найден. Пакет не будет подготовлен, пока файл отсутствует.");
        var summary = fullSnapshot
            ? new ChangeSummary(new List<FileChange>(), new List<FileChange>(), chosen.Count, false, "полный снимок для тестовой ветки GitHub")
            : GetChanges(inventory, settings);
        if (!fullSnapshot && summary.ReferenceFound && summary.Changed.Count == 0)
            throw new InvalidOperationException("Новых или изменённых файлов нет. Кандидаты из старого манифеста не считаются подтверждёнными удалениями.");
        // Staging alone never deletes anything. Retired entries require a verified publisher and client.
        var stamp = DateTimeOffset.UtcNow.ToString("yyyyMMdd-HHmmss-fff");
        var destination = Path.Combine(Path.GetFullPath(settings.OutputRoot), "drafts", stamp);
        if (Directory.Exists(destination)) throw new IOException("Каталог временной сборки уже существует: " + destination);
        var temp = destination + ".incomplete";
        Directory.CreateDirectory(temp);
        try
        {
            foreach (var file in chosen)
            {
                ct.ThrowIfCancellationRequested();
                var dest = PathSafety.SafeTarget(Path.Combine(temp, "files"), file.Path);
                Directory.CreateDirectory(Path.GetDirectoryName(dest)!);
                await using (var source = new FileStream(file.FullPath, FileMode.Open, FileAccess.Read, FileShare.Read,
                    1024 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan))
                await using (var output = new FileStream(dest, FileMode.CreateNew, FileAccess.Write, FileShare.None,
                    1024 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan))
                    await source.CopyToAsync(output, ct);
                await using var verify = File.OpenRead(dest);
                var checksum = Convert.ToHexString(await SHA256.HashDataAsync(verify, ct)).ToLowerInvariant();
                if (new FileInfo(dest).Length != file.Size || checksum != file.Sha256)
                    throw new IOException("Файл изменился во время подготовки пакета. Повтори сканирование: " + file.Path);
                log?.Invoke("Упакован: " + file.Path);
            }
            var manifest = new OwnerManifest { Version = stamp };
            manifest.Files = chosen.Select(f => new ManifestFile
            {
                Path = f.Path, Url = "files/" + f.Path, Size = f.Size, Sha256 = f.Sha256
            }).ToList();
            // v0.1.4 SAFE MODE: Never emit deletion instructions from a legacy baseline.
            // Migrations and explicit owner-approved retirements need a separate implementation.
            manifest.Retired = new List<ManifestFile>();
            var opts = new JsonSerializerOptions { WriteIndented = true };
            var metadata = new
            {
                status = "UNSIGNED_DRAFT_DO_NOT_PUBLISH",
                builtUtc = DateTimeOffset.UtcNow,
                selectedMods = inventory.Mods.Where(m => m.IsSelected).Select(m => m.Name).OrderBy(x => x).ToArray(),
                reference = summary.ReferenceLabel,
                warnings = new[] {
                    "Builder v0.2.1: this is a LOCAL TEST draft only. Production publication is disabled.",
                    "This draft is not signed and MUST NOT be uploaded as a live update.",
                    "Retired files are NOT listed as deletion instructions in this draft. Legacy candidates are informational only."
                },
                changed = summary.Changed,
                retiredCandidatesOnly = summary.Retired,
                retirementInstructions = "none"
            };
            await File.WriteAllTextAsync(Path.Combine(temp, "manifest.json"), JsonSerializer.Serialize(manifest, opts), ct);
            await File.WriteAllTextAsync(Path.Combine(temp, "preview.json"), JsonSerializer.Serialize(metadata, opts), ct);
            await File.WriteAllTextAsync(Path.Combine(temp, "README_DO_NOT_PUBLISH.txt"),
                "PROJECT ECHO UNSIGNED DRAFT\r\nThis directory is PREVIEW ONLY.\r\nDo not copy it into the live site or distribute to players.\r\nClient-side dynamic updater and signing must be integrated first.\r\n", ct);
            Directory.Move(temp, destination);
            return destination;
        }
        catch
        {
            try { Directory.Delete(temp, true); } catch { /* a failed draft can be cleaned manually */ }
            throw;
        }
    }

    private static List<ManagedFile> SelectedFiles(InventoryResult current)
    {
        var selected = new HashSet<string>(current.Mods.Where(m => m.IsSelected).Select(m => m.Name), StringComparer.OrdinalIgnoreCase);
        return current.Files.Where(f => f.Path == "mods/default.txt" ||
               (f.Path.StartsWith("mods/", StringComparison.Ordinal) && selected.Contains(f.Path.Split('/')[1])))
            .OrderBy(f => f.Path, StringComparer.OrdinalIgnoreCase).ToList();
    }

    private static Dictionary<string, ManifestFile> ReferenceFiles(BuilderSettings settings, out bool found, out string label)
    {
        // For local tests, compare against a verified signed test manifest instead of
        // the obsolete schema-1 site manifest. Do not silently fall back after a failed
        // verification: a missing/invalid baseline must be made explicit.
        string reference;
        if (!string.IsNullOrWhiteSpace(settings.LastSignedTestDraftPath))
        {
            var draftsDir = Path.GetFullPath(Path.Combine(settings.OutputRoot, "drafts"));
            var folder = Path.GetFullPath(settings.LastSignedTestDraftPath);
            if (!folder.StartsWith(draftsDir.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar,
                    StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("Предыдущий тестовый черновик находится вне папки drafts. Сбрось тестовый эталон.");
            PathSafety.CheckDirectory(draftsDir);
            PathSafety.CheckDirectory(folder);
            reference = Path.Combine(folder, "manifest.json");
            var signatureFile = Path.Combine(folder, "manifest.sig");
            var pubKey = Path.Combine(settings.ProjectRoot, "launcher", "TrustedReleasePublicKey.pem");
            if (!File.Exists(reference) || !File.Exists(signatureFile) || !File.Exists(pubKey))
                throw new FileNotFoundException("Не найден подписанный тестовый манифест/публичный ключ. Проверь исходники или сбрось тестовый эталон.");
            PathSafety.CheckFile(reference);
            PathSafety.CheckFile(signatureFile);
            // .pem is forbidden INSIDE mod packages, but reading the trusted public key is required here.
            if ((File.GetAttributes(pubKey) & FileAttributes.ReparsePoint) != 0)
                throw new InvalidDataException("Публичный ключ не должен быть символической ссылкой.");
            if (new FileInfo(reference).Length > 4 * 1024 * 1024 || new FileInfo(signatureFile).Length > 256)
                throw new InvalidDataException("Тестовый манифест или подпись слишком велики.");
            using var verifier = ECDsa.Create();
            verifier.ImportFromPem(File.ReadAllText(pubKey));
            if (!verifier.VerifyData(File.ReadAllBytes(reference), File.ReadAllBytes(signatureFile),
                HashAlgorithmName.SHA256, DSASignatureFormat.Rfc3279DerSequence))
                throw new CryptographicException("Предыдущий тестовый манифест изменён или подпись неверна. Сбрось тестовый эталон.");
            label = "подписанный локальный тест: " + Path.GetFileName(folder);
        }
        else
        {
            reference = Path.Combine(settings.ProjectRoot, "site", "updates", "stable", "manifest.json");
            label = "старый сайт: site/updates/stable/manifest.json";
        }

        var result = new Dictionary<string, ManifestFile>(StringComparer.OrdinalIgnoreCase);
        found = File.Exists(reference);
        if (!found) { label = "нет эталона"; return result; }
        using var data = JsonDocument.Parse(File.ReadAllText(reference));
        if (!data.RootElement.TryGetProperty("files", out var entries) || entries.ValueKind != JsonValueKind.Array)
            throw new InvalidDataException("Эталонный manifest.json не содержит массива files.");
        bool localTest = !string.IsNullOrWhiteSpace(settings.LastSignedTestDraftPath);
        if (localTest &&
            (!data.RootElement.TryGetProperty("schema", out var schema) || schema.GetInt32() != 2 ||
             !data.RootElement.TryGetProperty("kind", out var kind) || kind.GetString() != "PROJECT_ECHO_LOCAL_MODS"))
            throw new InvalidDataException("Тестовый эталон должен использовать schema=2 и PROJECT_ECHO_LOCAL_MODS.");
        foreach (var item in entries.EnumerateArray())
        {
            var path = item.GetProperty("path").GetString() ?? "";
            if (!path.StartsWith("mods/", StringComparison.Ordinal)) continue;
            PathSafety.ValidatePatchPath(path);
            var hash = item.GetProperty("sha256").GetString() ?? "";
            if (hash.Length != 64 || !hash.All(Uri.IsHexDigit)) throw new InvalidDataException("Некорректный SHA-256 в эталоне: " + path);
            if (!result.TryAdd(path, new ManifestFile { Path = path, Sha256 = hash.ToLowerInvariant(), Size = item.GetProperty("size").GetInt64() }))
                throw new InvalidDataException("Дублирующийся путь в эталоне: " + path);
        }
        return result;
    }
}
