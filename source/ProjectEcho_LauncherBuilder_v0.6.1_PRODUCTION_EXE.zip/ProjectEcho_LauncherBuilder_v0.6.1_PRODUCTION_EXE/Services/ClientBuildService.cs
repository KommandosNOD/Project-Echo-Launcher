using System.IO;
using System.Diagnostics;
using System.Text.RegularExpressions;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder.Services;

internal sealed class ClientBuildService
{
    public async Task<string> BuildAsync(BuilderSettings cfg, Action<string>? log, CancellationToken ct)
    {
        var root = Path.GetFullPath(cfg.ProjectRoot);
        var project = Path.Combine(root, "launcher", "PZLauncher.csproj");
        if (!File.Exists(project)) throw new FileNotFoundException("Не найден исходный проект клиента. Укажи корневую папку pzportal2.", project);
        if (!Regex.IsMatch(cfg.ClientVersion, @"^\d+\.\d+\.\d+$"))
            throw new InvalidDataException("Версия должна иметь формат 0.4.0");
        var output = Path.Combine(Path.GetFullPath(cfg.OutputRoot), "client-builds", "v" + cfg.ClientVersion);
        Directory.CreateDirectory(output);
        var start = new ProcessStartInfo("dotnet")
        {
            WorkingDirectory = root,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };
        foreach (var arg in new[] {
                     "publish", project, "-c", "Release", "-r", "win-x64", "--self-contained", "true",
                     "-p:PublishSingleFile=true", "-p:PublishTrimmed=false", "-p:Version=" + cfg.ClientVersion,
                     "-o", output }) start.ArgumentList.Add(arg);
        log?.Invoke("dotnet publish — " + cfg.ClientVersion);
        using var proc = new Process { StartInfo = start };
        try { proc.Start(); }
        catch (System.ComponentModel.Win32Exception ex) { throw new InvalidOperationException("Не установлен .NET 10 SDK или dotnet не найден в PATH.", ex); }
        // Read both redirected streams concurrently to avoid deadlocks.
        var outTask = DrainAsync(proc.StandardOutput, log);
        var errTask = DrainAsync(proc.StandardError, log);
        using var registration = ct.Register(() => { try { if (!proc.HasExited) proc.Kill(entireProcessTree: true); } catch { } });
        await proc.WaitForExitAsync(ct);
        await Task.WhenAll(outTask, errTask);
        if (proc.ExitCode != 0) throw new InvalidOperationException("dotnet publish завершился с ошибкой: " + proc.ExitCode);
        var exe = Path.Combine(output, "ProjectEchoLauncher.exe");
        if (!File.Exists(exe)) throw new FileNotFoundException("Сборка закончилась, но ProjectEchoLauncher.exe не найден.", exe);
        log?.Invoke("Готов клиентский EXE: " + exe);
        return exe;
    }

    private static async Task DrainAsync(StreamReader stream, Action<string>? log)
    {
        while (await stream.ReadLineAsync() is { } line) log?.Invoke(line);
    }
}
