using System.IO;
using System.Text.Json;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder.Services;

internal static class SettingsService
{
    private static readonly string PathToSettings = System.IO.Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "ProjectEcho", "Builder", "settings.json");

    public static BuilderSettings Load()
    {
        if (!File.Exists(PathToSettings)) return new BuilderSettings();
        try
        {
            var cfg = JsonSerializer.Deserialize<BuilderSettings>(File.ReadAllText(PathToSettings)) ?? new BuilderSettings();
            cfg.AdditionalFolders ??= new();
            cfg.ExcludedAutoFolders ??= new();
            return cfg;
        }
        catch (JsonException) { throw new InvalidDataException("Файл настроек Builder повреждён: " + PathToSettings); }
    }

    public static void Save(BuilderSettings settings)
    {
        Directory.CreateDirectory(System.IO.Path.GetDirectoryName(PathToSettings)!);
        var temp = PathToSettings + ".tmp";
        File.WriteAllText(temp, JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true }));
        File.Move(temp, PathToSettings, true);
    }
}
