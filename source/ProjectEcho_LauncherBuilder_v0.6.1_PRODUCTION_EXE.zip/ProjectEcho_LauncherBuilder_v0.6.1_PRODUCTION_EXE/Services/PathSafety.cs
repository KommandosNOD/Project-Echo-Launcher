using System.IO;
using System.Text.RegularExpressions;

namespace ProjectEcho.Builder.Services;

internal static class PathSafety
{
    private static readonly HashSet<string> BlockedExtensions = new(StringComparer.OrdinalIgnoreCase)
    {
        ".exe", ".dll", ".ps1", ".bat", ".cmd", ".com", ".msi", ".scr", ".vbs", ".wsf",
        ".pem", ".pfx", ".p12", ".key", ".env", ".kdbx", ".sqlite-wal", ".sqlite-shm"
    };
    private static readonly HashSet<string> IgnoredNames = new(StringComparer.OrdinalIgnoreCase)
    { ".DS_Store", "Thumbs.db", "desktop.ini" };
    private static readonly HashSet<string> IgnoredDirectories = new(StringComparer.OrdinalIgnoreCase)
    { ".git", ".svn", ".vs" };
    private static readonly Regex DriveDeviceName = new(@"^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?$", RegexOptions.IgnoreCase | RegexOptions.CultureInvariant | RegexOptions.Compiled);

    public static bool IgnoreDirectory(string name) => IgnoredDirectories.Contains(name);
    public static bool IgnoreFile(string name) => IgnoredNames.Contains(name);

    public static string CheckFolderName(string value)
    {
        if (string.IsNullOrWhiteSpace(value) || value.Length > 90 || value is "." or ".." || value.Contains('/') || value.Contains('\\'))
            throw new InvalidDataException("Название мода должно быть именем ОДНОЙ папки без слешей.");
        CheckSegment(value);
        if (string.Equals(value, "default.txt", StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("default.txt — это отдельный файл, не папка мода.");
        return value;
    }

    public static string ValidatePatchPath(string path)
    {
        if (string.IsNullOrWhiteSpace(path) || path.Length > 500 || !path.StartsWith("mods/", StringComparison.Ordinal) ||
            path.Contains('\\') || path.Contains('%'))
            throw new InvalidDataException("Небезопасный относительный путь: " + path);
        var parts = path.Split('/');
        if (parts.Length == 2 && string.Equals(parts[1], "default.txt", StringComparison.Ordinal)) return path;
        if (parts.Length < 3) throw new InvalidDataException("Некорректная структура папки модов: " + path);
        foreach (var seg in parts) CheckSegment(seg);
        return path;
    }

    private static void CheckSegment(string value)
    {
        if (string.IsNullOrWhiteSpace(value) || value is "." or ".." || value.EndsWith('.') || value.EndsWith(' ') ||
            value.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 || value.Any(char.IsControl) ||
            value.Contains(':') || DriveDeviceName.IsMatch(value))
            throw new InvalidDataException("Небезопасное имя файла/папки: " + value);
    }

    public static void CheckFile(string path)
    {
        var name = Path.GetFileName(path);
        if (BlockedExtensions.Contains(Path.GetExtension(name)) || name.StartsWith(".env", StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Потенциально опасный файл — требуется ручная проверка: " + path);
        if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
            throw new InvalidDataException("Символические ссылки запрещены: " + path);
    }

    public static void CheckDirectory(string directory)
    {
        if ((File.GetAttributes(directory) & FileAttributes.ReparsePoint) != 0)
            throw new InvalidDataException("Ссылки/junction запрещены: " + directory);
    }

    public static string SafeTarget(string parent, string patchPath)
    {
        ValidatePatchPath(patchPath);
        var basePath = Path.GetFullPath(parent).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        var result = Path.GetFullPath(Path.Combine(basePath, patchPath.Replace('/', Path.DirectorySeparatorChar)));
        if (!result.StartsWith(basePath, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Попытка выхода за каталог обновлений: " + patchPath);
        return result;
    }
}
