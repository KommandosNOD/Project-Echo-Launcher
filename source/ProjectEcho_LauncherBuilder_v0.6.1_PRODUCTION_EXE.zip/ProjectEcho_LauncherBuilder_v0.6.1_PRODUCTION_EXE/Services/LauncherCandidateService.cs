using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder.Services;

/// <summary>
/// Builds and signs an owner-only STAGING client candidate. No network writes.
/// EXE publication is deliberately NOT implemented in this first stage.
/// </summary>
internal sealed class LauncherCandidateService
{
    private const string BinaryName = "ProjectEchoLauncher_STAGING.exe";
    private const long MinSize = 1024 * 1024;
    private const long MaxSize = 600L * 1024 * 1024;
    internal sealed record CandidateInfo(string Directory, string Version, string Tag, long Bytes, string Sha256);

    private sealed record LauncherManifest(
        int schema, string kind, string channel, string version, string tag,
        string asset, long size, string sha256, string createdUtc);

    private static string CandidateRoot(BuilderSettings cfg) =>
        Path.GetFullPath(Path.Combine(cfg.OutputRoot, "launcher-candidates"));

    private static string GetVersion(string version)
    {
        if (!Regex.IsMatch(version, @"^\d+\.\d+\.\d+$") || !Version.TryParse(version, out var parsed) ||
            parsed.Major < 0 || parsed.Minor < 0 || parsed.Build < 0)
            throw new InvalidDataException("Версия EXE должна иметь формат 0.4.3 и быть неотрицательной.");
        return version;
    }

    private static string RequireRoot(string raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) throw new InvalidDataException("Выбери папку исходников STAGING-клиента.");
        var root = Path.GetFullPath(Environment.ExpandEnvironmentVariables(raw.Trim(' ', '"')));
        if (!File.Exists(Path.Combine(root, "launcher", "PZLauncher.csproj")) ||
            !File.Exists(Path.Combine(root, "launcher", "ManifestSource.cs")) ||
            !File.Exists(Path.Combine(root, "BUILD_STAGING_CLIENT.cmd")) ||
            !File.Exists(Path.Combine(root, "launcher", "StagingSelfUpdateService.cs")) ||
            !File.Exists(Path.Combine(root, "updater", "ProjectEchoUpdater.csproj")) ||
            !File.Exists(Path.Combine(root, "updater", "Program.cs")))
            throw new InvalidDataException("Нужны исходники STAGING-клиента, а НЕ папка pzportal2 или рабочий лаунчер.");
        // The project must have an explicit isolated STAGING build and naming.
        var projectText = File.ReadAllText(Path.Combine(root, "launcher", "PZLauncher.csproj"));
        if (!projectText.Contains("EchoStagingClient", StringComparison.Ordinal) ||
            !projectText.Contains("ProjectEchoLauncher_STAGING", StringComparison.Ordinal) ||
            !projectText.Contains("project-echo-staging-updater.exe", StringComparison.Ordinal))
            throw new InvalidDataException("Нужна сборка STAGING с отдельным встроенным Updater. Старые исходники v0.3.0 не подходят.");
        return root;
    }

    private static async Task<string> RunPublishAsync(string root, string version, string output,
        Action<string> log, CancellationToken ct)
    {
        // The dedicated updater MUST be compiled first and embedded into every new EXE.
        // Otherwise a newer launcher regresses to the earlier broken self-update mechanism.
        var updaterProject = Path.Combine(root, "updater", "ProjectEchoUpdater.csproj");
        var updaterOutput = Path.Combine(root, "build", "updater");
        Directory.CreateDirectory(updaterOutput);
        log("Этап 1/2: собираем отдельный Updater, который будет встроен в EXE.");
        var workerArgs = new[] { "publish", updaterProject, "-c", "Release", "-r", "win-x64",
            "--self-contained", "true", "-p:PublishSingleFile=true", "-p:PublishTrimmed=false",
            "-p:NuGetAudit=false", "-o", updaterOutput };
        await RunDotnetAsync(root, workerArgs, log, ct);
        var updaterExe = Path.Combine(updaterOutput, "ProjectEchoUpdater_STAGING.exe");
        if (!File.Exists(updaterExe) || new FileInfo(updaterExe).Length < 100_000)
            throw new FileNotFoundException("Отдельный Updater не собран или подозрительно мал.", updaterExe);
        log("Этап 2/2: собираем STAGING-клиент с встроенным Updater.");
        var csproj = Path.Combine(root, "launcher", "PZLauncher.csproj");
        var clientArgs = new[] { "publish", csproj, "-c", "Release", "-r", "win-x64",
            "--self-contained", "true", "-p:EchoStagingClient=true",
            "-p:PublishSingleFile=true", "-p:PublishTrimmed=false", "-p:NuGetAudit=false",
            "-p:Version=" + version, "-o", output };
        await RunDotnetAsync(root, clientArgs, log, ct);
        var exe = Path.Combine(output, BinaryName);
        if (!File.Exists(exe)) throw new FileNotFoundException("STAGING EXE не появился после сборки.", exe);
        return exe;
    }

    private static async Task RunDotnetAsync(string root, string[] args,
        Action<string> log, CancellationToken ct)
    {
        var psi = new ProcessStartInfo("dotnet")
        {
            WorkingDirectory = root,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };
        foreach (var item in args) psi.ArgumentList.Add(item);
        using var process = new Process { StartInfo = psi };
        try { process.Start(); }
        catch (System.ComponentModel.Win32Exception ex)
        {
            throw new InvalidOperationException("dotnet не найден. Установи .NET 10 SDK и перезапусти Builder.", ex);
        }
        async Task Drain(StreamReader stream)
        {
            while (await stream.ReadLineAsync(ct) is { } line) log(line);
        }
        var stdout = Drain(process.StandardOutput);
        var stderr = Drain(process.StandardError);
        using var reg = ct.Register(() => { try { if (!process.HasExited) process.Kill(true); } catch { } });
        await process.WaitForExitAsync(ct);
        await Task.WhenAll(stdout, stderr);
        if (process.ExitCode != 0)
            throw new InvalidOperationException("dotnet publish завершился с кодом " + process.ExitCode +
                ". Смотри журнал сборки выше.");
    }

    private static (string Private, string Public) KeyPaths(BuilderSettings cfg)
    {
        var owner = Path.GetFullPath(cfg.ProjectRoot);
        var privatePath = Path.Combine(owner, "secrets", "release-private.pem");
        var publicPath = Path.Combine(owner, "launcher", "TrustedReleasePublicKey.pem");
        if (!File.Exists(privatePath) || !File.Exists(publicPath))
            throw new FileNotFoundException("Не найдена оригинальная пара ECDSA-ключей в pzportal2. Новый ключ создавать нельзя.");
        if ((File.GetAttributes(privatePath) & FileAttributes.ReparsePoint) != 0 ||
            (File.GetAttributes(publicPath) & FileAttributes.ReparsePoint) != 0)
            throw new InvalidDataException("Ключи не должны быть символическими ссылками.");
        return (privatePath, publicPath);
    }

    public async Task<CandidateInfo> BuildAndSignAsync(string source, string releaseVersion,
        BuilderSettings cfg, Action<string> log, CancellationToken ct)
    {
        var root = RequireRoot(source);
        var version = GetVersion(releaseVersion);
        // The new client must embed exactly the owner's trusted public key.
        var sourcePublic = Path.Combine(root, "launcher", "TrustedReleasePublicKey.pem");
        if (!File.Exists(sourcePublic)) throw new FileNotFoundException("Нет публичного ключа в STAGING исходниках.", sourcePublic);
        using (var sourceKey = ECDsa.Create())
        using (var ownerKey = ECDsa.Create())
        {
            sourceKey.ImportFromPem(await File.ReadAllTextAsync(sourcePublic, ct));
            ownerKey.ImportFromPem(await File.ReadAllTextAsync(KeyPaths(cfg).Public, ct));
            if (!sourceKey.ExportSubjectPublicKeyInfo().AsSpan().SequenceEqual(ownerKey.ExportSubjectPublicKeyInfo()))
                throw new CryptographicException("STAGING исходники содержат другой публичный ключ, чем действующий PROJECT ECHO.");
        }
        var rootDir = CandidateRoot(cfg);
        Directory.CreateDirectory(rootDir);
        var folder = Path.Combine(rootDir, "v" + version);
        if (Directory.Exists(folder) || File.Exists(folder))
            throw new InvalidOperationException("Кандидат v" + version + " уже существует. Увеличь версию; готовые версии не перезаписываем.");
        var buildRoot = Path.Combine(rootDir, "_build-" + Guid.NewGuid().ToString("N"));
        try
        {
            Directory.CreateDirectory(buildRoot);
            log("Собираем изолированный STAGING EXE v" + version);
            var built = await RunPublishAsync(root, version, buildRoot, log, ct);
            var bytes = new FileInfo(built).Length;
            if (bytes is < MinSize or > MaxSize)
                throw new InvalidDataException("Подозрительный размер EXE. Разрешено от 1 до 600 МиБ.");
            await using var stream = File.OpenRead(built);
            var hash = Convert.ToHexString(await SHA256.HashDataAsync(stream, ct)).ToLowerInvariant();
            var tag = "echo-launcher-test-v" + version;
            var content = new LauncherManifest(1, "PROJECT_ECHO_LAUNCHER", "staging", version,
                tag, BinaryName, bytes, hash, DateTimeOffset.UtcNow.ToString("O"));
            var manifestBytes = JsonSerializer.SerializeToUtf8Bytes(content, new JsonSerializerOptions { WriteIndented = true });
            var paths = KeyPaths(cfg);
            using var privateKey = ECDsa.Create();
            privateKey.ImportFromPem(await File.ReadAllTextAsync(paths.Private, ct));
            using var publicKey = ECDsa.Create();
            publicKey.ImportFromPem(await File.ReadAllTextAsync(paths.Public, ct));
            if (!privateKey.ExportSubjectPublicKeyInfo().AsSpan().SequenceEqual(publicKey.ExportSubjectPublicKeyInfo()))
                throw new CryptographicException("Ключи подписи не соответствуют друг другу.");
            var signature = privateKey.SignData(manifestBytes, HashAlgorithmName.SHA256, DSASignatureFormat.Rfc3279DerSequence);
            if (!publicKey.VerifyData(manifestBytes, signature, HashAlgorithmName.SHA256, DSASignatureFormat.Rfc3279DerSequence))
                throw new CryptographicException("Самопроверка подписи EXE не пройдена.");
            Directory.CreateDirectory(folder);
            File.Copy(built, Path.Combine(folder, BinaryName), false);
            await File.WriteAllBytesAsync(Path.Combine(folder, "launcher.json"), manifestBytes, ct);
            await File.WriteAllBytesAsync(Path.Combine(folder, "launcher.sig"), signature, ct);
            await File.WriteAllTextAsync(Path.Combine(folder, "DO_NOT_PUBLISH_YET.txt"),
                "PROJECT ECHO STAGING EXE candidate. Signed locally; publish ONLY through Builder EXE (TEST) after explicit confirmation.\r\n" +
                "This must not be uploaded to main/stable or installed over the production launcher.\r\n", ct);
            var result = await VerifyAsync(folder, cfg, ct);
            log($"Подписанный кандидат: {result.Version}, {result.Bytes:N0} байт, SHA-256 {result.Sha256}");
            return result;
        }
        catch
        {
            if (Directory.Exists(folder))
            {
                try { Directory.Delete(folder, recursive: true); } catch { }
            }
            throw;
        }
        finally
        {
            try { if (Directory.Exists(buildRoot)) Directory.Delete(buildRoot, recursive: true); }
            catch { log("Временную папку сборки не удалось удалить: " + buildRoot); }
        }
    }

    public async Task<CandidateInfo> VerifyAsync(string dir, BuilderSettings cfg, CancellationToken ct)
    {
        var folder = Path.GetFullPath(Environment.ExpandEnvironmentVariables(dir.Trim(' ', '"')));
        var root = CandidateRoot(cfg).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        if (!folder.StartsWith(root, StringComparison.OrdinalIgnoreCase) ||
            !Directory.Exists(folder) || (File.GetAttributes(folder) & FileAttributes.ReparsePoint) != 0)
            throw new InvalidDataException("Кандидат должен находиться в настроенной папке launcher-candidates.");
        var file = Path.Combine(folder, BinaryName);
        var manifest = Path.Combine(folder, "launcher.json");
        var sig = Path.Combine(folder, "launcher.sig");
        foreach (var path in new[] { file, manifest, sig })
        {
            if (!File.Exists(path) || (File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
                throw new FileNotFoundException("Отсутствует или небезопасен файл кандидата: " + path);
        }
        if (new FileInfo(manifest).Length > 4096 || new FileInfo(sig).Length is < 16 or > 256)
            throw new InvalidDataException("Неверный размер подписанного манифеста или подписи.");
        var raw = await File.ReadAllBytesAsync(manifest, ct);
        var data = JsonSerializer.Deserialize<LauncherManifest>(raw)
            ?? throw new InvalidDataException("Пустой launcher.json.");
        if (data.schema != 1 || data.kind != "PROJECT_ECHO_LAUNCHER" || data.channel != "staging" ||
            data.asset != BinaryName || GetVersion(data.version) != data.version ||
            data.tag != "echo-launcher-test-v" + data.version ||
            data.size is < MinSize or > MaxSize ||
            !Regex.IsMatch(data.sha256, "^[0-9a-f]{64}$") ||
            !string.Equals(Path.GetFileName(folder), "v" + data.version, StringComparison.Ordinal))
            throw new InvalidDataException("Манифест не является допустимой STAGING-сборкой EXE.");
        using var key = ECDsa.Create();
        key.ImportFromPem(await File.ReadAllTextAsync(KeyPaths(cfg).Public, ct));
        if (!key.VerifyData(raw, await File.ReadAllBytesAsync(sig, ct), HashAlgorithmName.SHA256,
            DSASignatureFormat.Rfc3279DerSequence))
            throw new CryptographicException("Подпись EXE-кандидата не совпадает.");
        if (new FileInfo(file).Length != data.size)
            throw new InvalidDataException("Размер EXE изменился после подписи.");
        await using var input = File.OpenRead(file);
        var hash = Convert.ToHexString(await SHA256.HashDataAsync(input, ct)).ToLowerInvariant();
        if (hash != data.sha256) throw new CryptographicException("SHA-256 EXE изменился после подписи.");
        return new CandidateInfo(folder, data.version, data.tag, data.size, hash);
    }
}
