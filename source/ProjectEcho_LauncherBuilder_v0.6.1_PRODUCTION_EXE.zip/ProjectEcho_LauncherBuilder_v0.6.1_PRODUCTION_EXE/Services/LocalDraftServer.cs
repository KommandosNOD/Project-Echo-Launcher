using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace ProjectEcho.Builder.Services;

/// <summary>
/// Read-only HTTP server for a signed TEST draft. Uses TcpListener to avoid HTTP.sys URLACL
/// and listens exclusively on IPv4 loopback. Never binds to a public interface.
/// </summary>
internal sealed class LocalDraftServer : IDisposable
{
    private readonly Action<string> _log;
    private TcpListener? _listener;
    private CancellationTokenSource? _lifetime;
    private Task? _loop;
    private string? _draftRoot;

    public bool IsRunning => _listener is not null;

    public LocalDraftServer(Action<string> log) => _log = log;

    public void Start(string draftRoot)
    {
        if (IsRunning) throw new InvalidOperationException("Тестовый сервер уже запущен.");
        _draftRoot = Path.GetFullPath(draftRoot);
        var listener = new TcpListener(IPAddress.Loopback, 8765);
        listener.Start(8); // Throws if the old Node.js test server still owns the port.
        var lifetime = new CancellationTokenSource();
        _lifetime = lifetime;
        _listener = listener;
        var servingRoot = _draftRoot;
        _loop = Task.Run(() => AcceptLoopAsync(listener, servingRoot, lifetime.Token));
        _log("ТЕСТОВЫЙ СЕРВЕР: http://127.0.0.1:8765/manifest.json");
        _log("Раздача ТОЛЬКО папки: " + _draftRoot);
    }

    public void Stop()
    {
        if (_listener is null) return;
        _lifetime?.Cancel();
        _listener.Stop();
        _listener = null;
        _log("Тестовый сервер остановлен.");
    }

    private async Task AcceptLoopAsync(TcpListener listener, string root, CancellationToken ct)
    {
        try
        {
            while (!ct.IsCancellationRequested)
            {
                using var client = await listener.AcceptTcpClientAsync(ct);
                // 1 request at a time is enough for sequential downloads of a local test package;
                // bounded processing avoids unlimited background tasks.
                using var requestTimeout = CancellationTokenSource.CreateLinkedTokenSource(ct);
                requestTimeout.CancelAfter(TimeSpan.FromSeconds(35));
                try { await HandleAsync(client, root, requestTimeout.Token); }
                catch (OperationCanceledException) when (!ct.IsCancellationRequested) { /* idle client */ }
                catch (IOException) { /* disconnected client */ }
                catch (SocketException) { /* disconnected client */ }
                catch (Exception ex) { _log("Локальный HTTP: " + ex.Message); }
            }
        }
        catch (OperationCanceledException) { }
        catch (SocketException) when (ct.IsCancellationRequested) { }
        catch (ObjectDisposedException) when (ct.IsCancellationRequested) { }
        catch (Exception ex) { _log("Ошибка локального HTTP-сервера: " + ex.Message); }
    }

    private static async Task HandleAsync(TcpClient client, string root, CancellationToken ct)
    {
        using var network = client.GetStream();
        using var reader = new StreamReader(network, Encoding.ASCII, false, 1024, true);
        var first = await reader.ReadLineAsync(ct);
        if (string.IsNullOrEmpty(first) || first.Length > 2048)
        {
            await RespondAsync(network, 400, null, false, ct);
            return;
        }
        var parts = first.Split(' ', StringSplitOptions.RemoveEmptyEntries);
        if (parts.Length != 3 || (parts[0] != "GET" && parts[0] != "HEAD") ||
            parts[2] is not ("HTTP/1.1" or "HTTP/1.0"))
        {
            await RespondAsync(network, 400, null, false, ct);
            return;
        }
        var headerChars = first.Length;
        while (true)
        {
            var line = await reader.ReadLineAsync(ct);
            if (line is null || line.Length == 0) break;
            headerChars += line.Length;
            if (headerChars > 8192) { await RespondAsync(network, 431, null, false, ct); return; }
        }
        string relative;
        try
        {
            var rawTarget = parts[1];
            if (!rawTarget.StartsWith('/') || rawTarget.Contains('#'))
                throw new InvalidDataException("Некорректный URL.");
            // PatchUpdateService sends ?v=<timestamp> on manifest.json / manifest.sig.
            // Allow only that cache-busting query; never use it as a filesystem path.
            var queryAt = rawTarget.IndexOf('?');
            if (queryAt >= 0)
            {
                var query = rawTarget[(queryAt + 1)..];
                if (!query.StartsWith("v=", StringComparison.Ordinal) || query.Length is < 3 or > 22 ||
                    !query[2..].All(char.IsAsciiDigit))
                    throw new InvalidDataException("Некорректные параметры URL.");
                rawTarget = rawTarget[..queryAt];
                if (rawTarget is not ("/manifest.json" or "/manifest.sig"))
                    throw new InvalidDataException("Параметры разрешены только для манифеста.");
            }
            relative = Uri.UnescapeDataString(rawTarget[1..]);
            if (relative.Contains('%') || relative.Contains('\\') || relative.Contains(':') ||
                relative.Any(char.IsControl))
                throw new InvalidDataException("Некорректное кодирование пути.");
            var segments = relative.Split('/');
            if (segments.Any(s => s.Length == 0 || s is "." or ".." || s.EndsWith('.') || s.EndsWith(' ')))
                throw new InvalidDataException("Недопустимый сегмент пути.");
            bool isManifest = relative is "manifest.json" or "manifest.sig";
            if (!isManifest && !(relative.StartsWith("files/mods/", StringComparison.Ordinal) && segments.Length >= 3))
                throw new InvalidDataException("Путь не входит в тестовый пакет.");
            if (relative.StartsWith("files/", StringComparison.Ordinal))
                PathSafety.ValidatePatchPath(relative[6..]);
        }
        catch
        {
            await RespondAsync(network, 400, null, false, ct);
            return;
        }
        var file = Path.GetFullPath(Path.Combine(root, relative.Replace('/', Path.DirectorySeparatorChar)));
        var allowedRoot = root.TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        if (!file.StartsWith(allowedRoot, StringComparison.OrdinalIgnoreCase) || !File.Exists(file))
        {
            await RespondAsync(network, 404, null, false, ct);
            return;
        }
        try
        {
            // Refuse symlink / junction / reparse point anywhere below the draft directory.
            var p = root;
            foreach (var segment in relative.Split('/').SkipLast(1))
            {
                p = Path.Combine(p, segment);
                PathSafety.CheckDirectory(p);
            }
            if ((File.GetAttributes(file) & FileAttributes.ReparsePoint) != 0)
                throw new InvalidDataException("Symlink blocked.");
            await RespondAsync(network, 200, file, parts[0] == "GET", ct);
        }
        catch (FileNotFoundException) { await RespondAsync(network, 404, null, false, ct); }
        catch (DirectoryNotFoundException) { await RespondAsync(network, 404, null, false, ct); }
        catch (InvalidDataException) { await RespondAsync(network, 403, null, false, ct); }
        catch (UnauthorizedAccessException) { await RespondAsync(network, 403, null, false, ct); }
    }

    private static async Task RespondAsync(NetworkStream network, int status, string? file, bool sendBody, CancellationToken ct)
    {
        var statusText = status switch { 200 => "OK", 400 => "Bad Request", 403 => "Forbidden",
            404 => "Not Found", 431 => "Request Header Fields Too Large", _ => "Internal Server Error" };
        long size = file is null ? 0 : new FileInfo(file).Length;
        var type = file?.EndsWith(".json", StringComparison.OrdinalIgnoreCase) == true
            ? "application/json; charset=utf-8" : "application/octet-stream";
        var head = $"HTTP/1.1 {status} {statusText}\r\nContent-Type: {type}\r\nContent-Length: {size}\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n";
        await network.WriteAsync(Encoding.ASCII.GetBytes(head), ct);
        if (sendBody && file is not null)
        {
            await using var stream = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.Read,
                64 * 1024, FileOptions.Asynchronous | FileOptions.SequentialScan);
            await stream.CopyToAsync(network, ct);
        }
        await network.FlushAsync(ct);
    }

    public void Dispose()
    {
        Stop();
        _lifetime?.Dispose();
    }
}
