using System.Globalization;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Nodes;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder.Services;

internal sealed record NewsSnapshot(List<NewsRecord> Items, JsonObject Root, string SourceHash);
internal sealed record NewsSaveResult(string BackupPath, int TotalItems, string CurrentHash);

/// <summary>Reads/writes the existing site's news.json without inventing a second news format.</summary>
internal static class NewsSiteService
{
    private static readonly JsonSerializerOptions Pretty = new()
    {
        WriteIndented = true,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };

    public static string GetNewsPath(string root) => Path.Combine(Path.GetFullPath(root), "site", "data", "news.json");
    private static string GetAssetPath(string root) => Path.Combine(Path.GetFullPath(root), "site", "assets", "news");
    public static string GetConfigPath(string root) => Path.Combine(Path.GetFullPath(root), "wrangler.jsonc");

    public static NewsSnapshot Load(string projectRoot)
    {
        var file = GetNewsPath(projectRoot);
        if (!File.Exists(file)) throw new FileNotFoundException("Не найден файл новостей сайта", file);
        EnsureNotLink(file);
        var bytes = File.ReadAllBytes(file);
        var root = JsonNode.Parse(bytes) as JsonObject
                   ?? throw new InvalidDataException("news.json должен содержать объект JSON");
        if (root["items"] is not JsonArray rows) throw new InvalidDataException("news.json не содержит массива items");
        var list = new List<NewsRecord>();
        foreach (var node in rows)
        {
            if (node is not JsonObject raw) throw new InvalidDataException("Элемент items должен быть JSON-объектом");
            var item = new NewsRecord
            {
                Extra = (JsonObject)raw.DeepClone(),
                Category = (string?)raw["category"] ?? "",
                Date = (string?)raw["date"] ?? "",
                Title = (string?)raw["title"] ?? "",
                Text = (string?)raw["text"] ?? "",
                Image = (string?)raw["image"] ?? ""
            };
            list.Add(item);
        }
        return new NewsSnapshot(list, root, Sha(bytes));
    }

    public static NewsSaveResult Save(string projectRoot, NewsSnapshot loaded, IReadOnlyList<NewsRecord> items)
    {
        var file = GetNewsPath(projectRoot);
        EnsureNotLink(file);
        if (Sha(File.ReadAllBytes(file)) != loaded.SourceHash)
            throw new IOException("news.json изменился вне Builder. Перезагрузи новости, чтобы не перезаписать чужие изменения.");
        if (items.Count > 100) throw new InvalidDataException("Максимум 100 новостей в файле.");
        foreach (var item in items) Validate(item);
        var newFiles = new List<string>();
        string? temp = null;
        bool committed = false;
        try
        {
            var dest = GetAssetPath(projectRoot);
            Directory.CreateDirectory(dest);
            EnsureNotLink(dest);
            var rows = new JsonArray();
            var imageUpdates = new Dictionary<NewsRecord, string>();
            foreach (var item in items)
            {
                var raw = (JsonObject)item.Extra.DeepClone();
                raw["category"] = item.Category.Trim();
                raw["date"] = item.Date.Trim();
                raw["title"] = item.Title.Trim();
                raw["text"] = item.Text.Trim();
                var image = item.Image;
                if (!string.IsNullOrWhiteSpace(item.PendingImage))
                {
                    var ext = CheckImage(item.PendingImage);
                    var fileName = Convert.ToHexString(RandomNumberGenerator.GetBytes(12)).ToLowerInvariant() + "." + ext;
                    var output = Path.Combine(dest, fileName);
                    // Fail rather than ever overwrite an existing news image.
                    using (var input = new FileStream(item.PendingImage, FileMode.Open, FileAccess.Read, FileShare.Read))
                    using (var outputStream = new FileStream(output, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                        input.CopyTo(outputStream);
                    newFiles.Add(output);
                    image = "/assets/news/" + fileName;
                    imageUpdates[item] = image;
                }
                if (string.IsNullOrWhiteSpace(image)) raw.Remove("image");
                else raw["image"] = image;
                rows.Add(raw);
            }
            var root = (JsonObject)loaded.Root.DeepClone();
            root["items"] = rows;
            root["updatedAt"] = DateTime.UtcNow.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
            var text = root.ToJsonString(Pretty) + "\n";
            var dir = Path.GetDirectoryName(file)!;
            temp = Path.Combine(dir, ".echo-news-" + Guid.NewGuid().ToString("N") + ".tmp");
            File.WriteAllText(temp, text, new UTF8Encoding(false));
            using var _ = JsonDocument.Parse(File.ReadAllText(temp));
            // Check for edits between initial read and write as well.
            if (Sha(File.ReadAllBytes(file)) != loaded.SourceHash)
                throw new IOException("news.json был изменён, пока ты редактировал. Ничего не перезаписано.");
            var backupDir = Path.Combine(Path.GetFullPath(projectRoot), "backups", "echo-news");
            Directory.CreateDirectory(backupDir);
            var backup = Path.Combine(backupDir, DateTime.UtcNow.ToString("yyyyMMdd-HHmmss-fff", CultureInfo.InvariantCulture)
                + "-" + Guid.NewGuid().ToString("N")[..6] + ".json");
            File.Copy(file, backup, overwrite: false);
            File.Move(temp, file, overwrite: true);
            committed = true;
            temp = null;
            foreach (var (item, path) in imageUpdates) { item.Image = path; item.PendingImage = ""; }
            return new NewsSaveResult(backup, items.Count, Sha(File.ReadAllBytes(file)));
        }
        catch
        {
            if (!committed)
                foreach (var created in newFiles) try { File.Delete(created); } catch { /* leave for manual cleanup */ }
            throw;
        }
        finally { if (temp != null) try { File.Delete(temp); } catch { } }
    }

    public static void Validate(NewsRecord item)
    {
        Test(item.Category, "Категория", 36);
        Test(item.Date, "Дата", 10);
        Test(item.Title, "Заголовок", 140);
        Test(item.Text, "Текст", 1600);
        if (!DateTime.TryParseExact(item.Date.Trim(), "dd.MM.yyyy", CultureInfo.InvariantCulture,
                DateTimeStyles.None, out _)) throw new InvalidDataException("Дата должна быть в формате ДД.ММ.ГГГГ: " + item.Title);
        if (!string.IsNullOrWhiteSpace(item.Image))
        {
            if (!System.Text.RegularExpressions.Regex.IsMatch(item.Image,
                @"^/assets/news/[A-Za-z0-9_-]+\.(jpg|png|webp)$", System.Text.RegularExpressions.RegexOptions.IgnoreCase))
                throw new InvalidDataException("Недопустимый путь изображения: " + item.Image);
        }
        if (!string.IsNullOrWhiteSpace(item.PendingImage)) CheckImage(item.PendingImage);
    }

    private static void Test(string? value, string field, int max)
    {
        var len = value?.Trim().Length ?? 0;
        if (len is < 1 || len > 1600 || len > max)
            throw new InvalidDataException($"{field}: требуется от 1 до {max} символов.");
    }

    public static string CheckImage(string file)
    {
        if (!File.Exists(file)) throw new FileNotFoundException("Изображение не найдено", file);
        EnsureNotLink(file);
        var size = new FileInfo(file).Length;
        if (size is < 1 or > (2 * 1024 * 1024))
            throw new InvalidDataException("Размер картинки должен быть от 1 байта до 2 МиБ.");
        var ext = Path.GetExtension(file).TrimStart('.').ToLowerInvariant();
        if (ext is not ("png" or "jpg" or "jpeg" or "webp"))
            throw new InvalidDataException("Поддерживаются только JPG, PNG и WEBP.");
        Span<byte> signature = stackalloc byte[12];
        signature.Clear();
        using (var stream = File.OpenRead(file)) { _ = stream.Read(signature); }
        var valid = ext switch
        {
            "png" => signature[..8].SequenceEqual(new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 }),
            "jpg" or "jpeg" => signature[0] == 255 && signature[1] == 216 && signature[2] == 255,
            _ => signature[..4].SequenceEqual("RIFF"u8) && signature[8..12].SequenceEqual("WEBP"u8)
        };
        if (!valid) throw new InvalidDataException("Расширение картинки не совпадает с содержимым файла.");
        return ext == "jpeg" ? "jpg" : ext;
    }

    public static string GetImageAbsolutePath(string projectRoot, string siteImage)
    {
        if (!System.Text.RegularExpressions.Regex.IsMatch(siteImage,
            @"^/assets/news/[A-Za-z0-9_-]+\.(jpg|png|webp)$", System.Text.RegularExpressions.RegexOptions.IgnoreCase)) return "";
        return Path.Combine(GetAssetPath(projectRoot), Path.GetFileName(siteImage));
    }

    public static void ValidateDeploymentProject(string root)
    {
        var cfg = GetConfigPath(root);
        if (!File.Exists(cfg)) throw new FileNotFoundException("Не найден wrangler.jsonc", cfg);
        if (!File.Exists(Path.Combine(root, "worker", "index.js")))
            throw new FileNotFoundException("Не найден worker/index.js");
        if (!File.Exists(GetNewsPath(root))) throw new FileNotFoundException("Не найден site/data/news.json");
        var json = JsonNode.Parse(File.ReadAllText(cfg), null,
            new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true }) as JsonObject;
        if (json?["assets"]?["directory"]?.GetValue<string>() != "./site" ||
            json?["main"]?.GetValue<string>() != "./worker/index.js")
            throw new InvalidDataException("Конфигурация Cloudflare отличается от проверенной структуры PROJECT ECHO.");
    }

    private static void EnsureNotLink(string path)
    {
        if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0)
            throw new IOException("Символическая ссылка или junction не допускается для редактируемых файлов: " + path);
    }
    private static string Sha(byte[] bytes) => Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
}
