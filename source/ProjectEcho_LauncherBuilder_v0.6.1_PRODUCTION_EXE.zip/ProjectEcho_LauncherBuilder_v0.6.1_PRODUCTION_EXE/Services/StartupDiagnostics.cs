using System;
using System.IO;
using System.Text;
using System.Windows;

namespace ProjectEcho.Builder.Services;

internal static class StartupDiagnostics
{
    private static readonly object Guard = new();

    public static string LogPath => Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "ProjectEcho", "Builder", "logs", "startup.log");

    public static void Write(string message, Exception? exception = null)
    {
        var entry = $"[{DateTimeOffset.Now:yyyy-MM-dd HH:mm:ss.fff zzz}] {message}{Environment.NewLine}";
        if (exception != null) entry += exception + Environment.NewLine;
        lock (Guard)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(LogPath)!);
                File.AppendAllText(LogPath, entry, Encoding.UTF8);
            }
            catch
            {
                // Never allow logging itself to block application startup.
            }
        }
    }

    public static void ShowFatal(string context, Exception ex)
    {
        Write(context, ex);
        try
        {
            MessageBox.Show(
                "PROJECT ECHO Launcher Builder could not start.\n\n" +
                context + "\n" + ex.GetType().Name + ": " + ex.Message +
                "\n\nDetailed error log:\n" + LogPath,
                "PROJECT ECHO — Startup error", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        catch
        {
            // Error dialogs can fail before the WPF dispatcher is ready; log remains on disk.
        }
    }
}
