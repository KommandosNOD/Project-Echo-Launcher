using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder.Services;

/// <summary>
/// Owner-only STAGING publisher. Writes a GitHub prerelease asset FIRST, then
/// publishes byte-exact ECDSA-signed launcher metadata to the isolated test branch.
/// Does NOT touch stable, main, Cloudflare, live launcher or mods.
/// </summary>
internal sealed class LauncherGitHubReleaseService
{
    private const string Repo = "KommandosNOD/Project-Echo-Launcher";
    private const string Branch = "project-echo-schema2-staging";
    private const string DirectoryOnBranch = "updates/launcher-staging";
    private const string Asset = "ProjectEchoLauncher_STAGING.exe";
    private readonly LauncherCandidateService _candidates = new();

    internal sealed record Result(string ReleaseUrl, string ManifestUrl, string Commit, string Tag, long Bytes);
    private sealed record CommandResult(int Code, string Out, string Error);

    private static async Task<CommandResult> CliAsync(string app, IEnumerable<string> args, string workingDirectory,
        CancellationToken ct, Action<string>? log = null)
    {
        Directory.CreateDirectory(workingDirectory);
        var psi = new ProcessStartInfo(app)
        {
            WorkingDirectory = workingDirectory,
            UseShellExecute = false,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            CreateNoWindow = true
        };
        foreach (var arg in args) psi.ArgumentList.Add(arg);
        using var process = new Process { StartInfo = psi };
        try { if (!process.Start()) throw new IOException("Не удалось запустить " + app); }
        catch (Win32Exception ex) { throw new InvalidOperationException(
            "Не найден " + app + ". Установи Git for Windows и GitHub CLI, перезапусти Builder.", ex); }
        var stdout = new StringBuilder();
        var stderr = new StringBuilder();
        async Task Drain(StreamReader reader, StringBuilder target, bool diagnostic)
        {
            while (await reader.ReadLineAsync(ct) is { } line)
            {
                if (target.Length < 256 * 1024) target.AppendLine(line);
                // Show safe progress only. Never log credentials or command arguments.
                if (diagnostic && !string.IsNullOrWhiteSpace(line) && line.Length < 512)
                    log?.Invoke(line);
            }
        }
        using var registration = ct.Register(() => { try { if (!process.HasExited) process.Kill(true); } catch { } });
        await Task.WhenAll(Drain(process.StandardOutput, stdout, false), Drain(process.StandardError, stderr, true),
            process.WaitForExitAsync(ct));
        return new CommandResult(process.ExitCode, stdout.ToString(), stderr.ToString());
    }

    private static async Task<string> MustAsync(string app, IEnumerable<string> args, string dir,
        CancellationToken ct, Action<string>? log = null)
    {
        var p = await CliAsync(app, args, dir, ct, log);
        if (p.Code != 0) throw new IOException(app + " завершился с ошибкой (" + p.Code + "):\n" +
                                         (p.Error.Length > 5000 ? p.Error[..5000] : p.Error));
        return p.Out.Trim();
    }

    private static string ExpectedAssetPath(LauncherCandidateService.CandidateInfo c) =>
        Path.Combine(c.Directory, Asset);

    private static void ValidateRelease(JsonElement release, LauncherCandidateService.CandidateInfo candidate,
        bool expectDraft)
    {
        if (release.GetProperty("tag_name").GetString() != candidate.Tag ||
            release.GetProperty("draft").GetBoolean() != expectDraft ||
            !release.GetProperty("prerelease").GetBoolean())
            throw new InvalidDataException("GitHub Release не является ожидаемым STAGING prerelease.");
        var assets = release.GetProperty("assets").EnumerateArray().ToArray();
        if (assets.Length != 1 || assets[0].GetProperty("name").GetString() != Asset ||
            assets[0].GetProperty("size").GetInt64() != candidate.Bytes)
            throw new InvalidDataException("GitHub Release содержит неожиданные вложения или неправильный размер EXE.");
        if (assets[0].TryGetProperty("digest", out var digest) && digest.ValueKind == JsonValueKind.String &&
            digest.GetString() is { Length: > 0 } sha &&
            !string.Equals(sha, "sha256:" + candidate.Sha256, StringComparison.OrdinalIgnoreCase))
            throw new CryptographicException("SHA-256 загруженного GitHub Release asset не совпадает.");
    }

    // A release DRAFT is not guaranteed to be discoverable through the /releases/tags/{tag}
    // endpoint; GitHub can return HTTP 404 although the draft (and its asset) exists.
    // The authenticated releases LIST endpoint also includes drafts for users with push access.
    // Do not rely on a failed tag lookup to decide that a release has not been created.
    private static async Task<JsonElement?> FindReleaseAsync(string tag, string dir, CancellationToken ct)
    {
        for (var page = 1; page <= 5; page++)
        {
            var response = await MustAsync("gh", new[] { "api", "--method", "GET",
                $"repos/{Repo}/releases?per_page=100&page={page}" }, dir, ct);
            using var doc = JsonDocument.Parse(response);
            if (doc.RootElement.ValueKind != JsonValueKind.Array)
                throw new InvalidDataException("GitHub не вернул список релизов.");
            foreach (var release in doc.RootElement.EnumerateArray())
                if (release.TryGetProperty("tag_name", out var candidateTag) &&
                    string.Equals(candidateTag.GetString(), tag, StringComparison.Ordinal))
                    return release.Clone();
            if (doc.RootElement.GetArrayLength() < 100) return null;
        }
        throw new InvalidOperationException(
            "GitHub содержит более 500 релизов; автоматическая проверка не может доказать, что тег отсутствует. " +
            "Публикация остановлена без изменения GitHub.");
    }

    private static async Task<JsonElement> WaitForDraftAsync(string tag, string dir, CancellationToken ct)
    {
        // Newly created drafts may not appear immediately. Do not re-upload on a 404.
        for (int attempt = 0; attempt < 6; attempt++)
        {
            var item = await FindReleaseAsync(tag, dir, ct);
            if (item.HasValue) return item.Value;
            await Task.Delay(TimeSpan.FromSeconds(2), ct);
        }
        throw new IOException("GitHub не показывает новый черновик Release в списке. " +
            "Проверь gh release list перед повтором; повторно загружать EXE нельзя.");
    }

    /// <summary>Always rechecks candidate on disk. No remote writes.</summary>
    internal async Task<LauncherCandidateService.CandidateInfo> PreflightAsync(
        string candidateDir, BuilderSettings settings, CancellationToken ct)
    {
        return await _candidates.VerifyAsync(candidateDir, settings, ct);
    }

    internal async Task<Result> PublishAsync(string candidateDir, BuilderSettings settings,
        Action<string> log, CancellationToken ct)
    {
        var candidate = await PreflightAsync(candidateDir, settings, ct);
        var workingRoot = Path.Combine(Path.GetFullPath(settings.OutputRoot), "github-launcher-staging-work");
        Directory.CreateDirectory(workingRoot);
        var login = (await MustAsync("gh", new[] { "api", "user", "--jq", ".login" }, workingRoot, ct)).Trim();
        if (!login.Equals("KommandosNOD", StringComparison.OrdinalIgnoreCase))
            throw new UnauthorizedAccessException("gh auth должен быть авторизован как KommandosNOD.");
        var repo = (await MustAsync("gh", new[] { "repo", "view", Repo, "--json", "nameWithOwner", "--jq", ".nameWithOwner" },
            workingRoot, ct)).Trim();
        if (!repo.Equals(Repo, StringComparison.OrdinalIgnoreCase))
            throw new InvalidDataException("Неверный GitHub-репозиторий.");
        var remote = "https://github.com/" + Repo + ".git";
        var branchRef = "refs/heads/" + Branch;
        var current = (await MustAsync("git", new[] { "ls-remote", "--heads", remote, branchRef },
            workingRoot, ct)).Trim();
        if (current.Length == 0) throw new InvalidDataException("Отсутствует отдельная тестовая ветка GitHub.");
        log("GitHub STAGING: проверяем существующие Releases, включая черновики.");
        // Check authenticated GitHub push rights, not just read access to the repository.
        var push = (await MustAsync("gh", new[] { "api", $"repos/{Repo}",
            "--jq", ".permissions.push" }, workingRoot, ct)).Trim();
        if (!string.Equals(push, "true", StringComparison.OrdinalIgnoreCase))
            throw new UnauthorizedAccessException("У авторизованного GitHub-аккаунта нет права push в " + Repo +
                ". Проверь gh auth status и разрешения репозитория. Публикация отменена.");
        var existingTag = (await MustAsync("git", new[] { "ls-remote", "--tags", remote,
            "refs/tags/" + candidate.Tag }, workingRoot, ct)).Trim();
        var found = await FindReleaseAsync(candidate.Tag, workingRoot, ct);
        if (found.HasValue && !found.Value.GetProperty("draft").GetBoolean())
            throw new InvalidOperationException("Release " + candidate.Tag +
                " уже опубликован. Повторная публикация с тем же тегом запрещена.");
        if (!found.HasValue && existingTag.Length > 0)
            throw new InvalidOperationException("Тег " + candidate.Tag +
                " уже существует без подходящего черновика. Нельзя менять этот тег.");

        if (found.HasValue)
        {
            log("Найден ранее созданный черновик " + candidate.Tag +
                ". Повторная загрузка EXE не производится.");
        }
        else
        {
            log("Этап 1/4: создаём GitHub Release DRAFT и загружаем подписанный EXE.");
            var exePath = ExpectedAssetPath(candidate);
            var create = new[] { "release", "create", candidate.Tag, exePath,
                "--repo", Repo, "--target", Branch, "--draft", "--prerelease", "--latest=false",
                "--title", "PROJECT ECHO STAGING Launcher " + candidate.Version,
                "--notes", "STAGING ONLY: signed test client. Not for production players." };
            try { await MustAsync("gh", create, workingRoot, ct, log); }
            catch (Exception ex)
            {
                throw new IOException("Этап 1/4 — gh release create. GitHub не завершил создание/загрузку Release. " +
                    "Проверь через gh release list --repo " + Repo +
                    " --json tagName,isDraft,isPrerelease перед повтором. Исходная ошибка: " + ex.Message, ex);
            }
        }
        // Authenticated release listing is used instead of /releases/tags (404 for some drafts).
        log("Этап 2/4: проверяем черновик и его загруженный EXE через GitHub API.");
        var draft = await WaitForDraftAsync(candidate.Tag, workingRoot, ct);
        ValidateRelease(draft, candidate, expectDraft: true);
        // Ensure local artifact cannot be modified after upload without detection.
        candidate = await PreflightAsync(candidateDir, settings, ct);
        log("Этап 3/4: GitHub asset подтверждён. Публикуем только PRERELEASE, не Latest.");
        try
        {
            await MustAsync("gh", new[] { "release", "edit", candidate.Tag, "--repo", Repo,
                "--draft=false", "--prerelease", "--latest=false" }, workingRoot, ct, log);
        }
        catch (Exception ex)
        {
            throw new IOException("Этап 3/4 — gh release edit. Черновик мог остаться на GitHub; " +
                "его можно безопасно проверить и продолжить в Builder. Ошибка: " + ex.Message, ex);
        }
        var publishedOpt = await FindReleaseAsync(candidate.Tag, workingRoot, ct);
        if (!publishedOpt.HasValue)
            throw new IOException("GitHub не показывает опубликованный Prerelease; не публикуем канал обновлений.");
        ValidateRelease(publishedOpt.Value, candidate, expectDraft: false);
        var download = "https://github.com/" + Repo + "/releases/download/" + candidate.Tag + "/" + Asset;
        log("EXE prerelease опубликован: " + download);
        log("Этап 4/4: публикуем подписанные launcher.json и launcher.sig в STAGING-ветку.");

        // ONLY NOW advertise the signed release to the STAGING updater.
        var checkout = Path.Combine(workingRoot, "checkout-" + Guid.NewGuid().ToString("N"));
        try
        {
            await MustAsync("git", new[] { "clone", "--depth", "1", "--single-branch", "--branch", Branch,
                remote, checkout }, workingRoot, ct, log);
            var actual = (await MustAsync("git", new[] { "branch", "--show-current" }, checkout, ct)).Trim();
            if (actual != Branch) throw new InvalidDataException("Checkout не находится в безопасной тестовой ветке.");
            var destination = Path.Combine(checkout, "updates", "launcher-staging");
            Directory.CreateDirectory(destination);
            var existingManifest = Path.Combine(destination, "launcher.json");
            if (File.Exists(existingManifest))
            {
                using var old = JsonDocument.Parse(await File.ReadAllBytesAsync(existingManifest, ct));
                var version = old.RootElement.GetProperty("version").GetString();
                if (!Version.TryParse(version, out var previous) || !Version.TryParse(candidate.Version, out var next) ||
                    next <= previous)
                    throw new InvalidOperationException("Нельзя публиковать устаревшую или повторную версию EXE.");
            }
            var paths = new[] { "launcher.json", "launcher.sig" };
            foreach (var path in paths)
                File.Copy(Path.Combine(candidate.Directory, path), Path.Combine(destination, path), true);
            await File.WriteAllTextAsync(Path.Combine(destination, ".gitattributes"),
                "# ECDSA signed bytes: no Git line ending conversion.\n* -text\n",
                new UTF8Encoding(false), ct);
            await MustAsync("git", new[] { "add", "--", DirectoryOnBranch }, checkout, ct);
            foreach (var path in paths)
            {
                var gitPath = DirectoryOnBranch + "/" + path;
                var indexed = (await MustAsync("git", new[] { "rev-parse", ":" + gitPath }, checkout, ct)).Trim();
                var disk = (await MustAsync("git", new[] { "hash-object", "--no-filters",
                    Path.Combine(destination, path) }, checkout, ct)).Trim();
                if (!indexed.Equals(disk, StringComparison.OrdinalIgnoreCase))
                    throw new CryptographicException("Git преобразовал байты подписанного файла: " + path);
            }
            var staged = (await MustAsync("git", new[] { "diff", "--cached", "--name-only" }, checkout, ct))
                .Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            if (staged.Length == 0 || staged.Any(path => !path.StartsWith(DirectoryOnBranch + "/", StringComparison.Ordinal)))
                throw new InvalidOperationException("Git готовит не только изменения STAGING EXE; публикация запрещена.");
            candidate = await PreflightAsync(candidateDir, settings, ct);
            await MustAsync("git", new[] { "-c", "user.name=PROJECT ECHO STAGING",
                "-c", "user.email=project-echo@users.noreply.github.com", "commit", "-m",
                "test: signed STAGING launcher " + candidate.Version }, checkout, ct, log);
            var head = (await MustAsync("git", new[] { "rev-parse", "HEAD" }, checkout, ct)).Trim();
            foreach (var path in paths)
            {
                var gitPath = DirectoryOnBranch + "/" + path;
                var committed = (await MustAsync("git", new[] { "rev-parse", "HEAD:" + gitPath }, checkout, ct)).Trim();
                var disk = (await MustAsync("git", new[] { "hash-object", "--no-filters",
                    Path.Combine(destination, path) }, checkout, ct)).Trim();
                if (!committed.Equals(disk, StringComparison.OrdinalIgnoreCase))
                    throw new CryptographicException("После коммита байты подписи изменились: " + path);
            }
            await MustAsync("git", new[] { "push", "origin", "HEAD:" + branchRef }, checkout, ct, log);
            var reference = (await MustAsync("git", new[] { "ls-remote", "origin", branchRef }, checkout, ct)).Trim();
            if (!reference.StartsWith(head + "\t", StringComparison.OrdinalIgnoreCase))
                throw new IOException("Удалённый STAGING-коммит не совпадает с опубликованным.");
            var manifestUrl = "https://raw.githubusercontent.com/" + Repo + "/" + head + "/" + DirectoryOnBranch + "/launcher.json";
            log("Подписанный EXE-канал GitHub STAGING: " + manifestUrl);
            return new Result("https://github.com/" + Repo + "/releases/tag/" + candidate.Tag,
                manifestUrl, head, candidate.Tag, candidate.Bytes);
        }
        finally
        {
            try { if (Directory.Exists(checkout)) Directory.Delete(checkout, recursive: true); }
            catch (Exception ex) { log("Не удалось удалить временный checkout: " + ex.Message); }
        }
    }
}
