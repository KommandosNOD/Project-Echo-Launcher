using System;
using System.Diagnostics;
using System.IO;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.RegularExpressions;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder.Services;

// EXE files are NOT recompiled, modified or signed as Authenticode.
// Only a byte-for-byte SHA-256 of the built EXE is signed in launcher.json.
internal sealed class ProductionExeCandidateService
{
    internal const string Asset = "ProjectEchoLauncher.exe";
    internal sealed record CandidateInfo(string Directory, string Version, string Tag, long Bytes, string Sha256);
    private sealed record LauncherManifest(int schema, string kind, string channel,
        string version, string tag, string asset, long size, string sha256, string createdUtc);
    private const long MinSize = 1048576;
    private const long MaxSize = 600L * 1024 * 1024;

    internal static string Root(BuilderSettings s) => Path.Combine(Path.GetFullPath(s.OutputRoot), "launcher-production-candidates");
    private static string VersionValue(string version)
    {
        var v = version.Trim();
        if (!Regex.IsMatch(v, @"^\d+\.\d+\.\d+$") || !Version.TryParse(v, out _))
            throw new InvalidDataException("Укажи версию формата 0.8.1.");
        return v;
    }
    private static (string Private, string Public) Keys(BuilderSettings settings)
    {
        var root = Path.GetFullPath(settings.ProjectRoot);
        var secret = Path.Combine(root, "secrets", "release-private.pem");
        var pub = Path.Combine(root, "launcher", "TrustedReleasePublicKey.pem");
        if (!File.Exists(secret) || !File.Exists(pub))
            throw new FileNotFoundException("Нет оригинальных release-private.pem / TrustedReleasePublicKey.pem в pzportal2. Новый ключ создавать нельзя.");
        foreach (var path in new[]{secret,pub})
            if ((File.GetAttributes(path)&FileAttributes.ReparsePoint)!=0)
                throw new InvalidDataException("Ключи не должны быть ссылками.");
        return (secret, pub);
    }
    private static void CheckExe(string path,string version)
    {
        if (Path.GetFileName(path) != Asset) throw new InvalidDataException("Выбери именно ProjectEchoLauncher.exe.");
        if (!File.Exists(path) || (File.GetAttributes(path)&FileAttributes.ReparsePoint)!=0)
            throw new FileNotFoundException("EXE не существует или является ссылкой.",path);
        var bytes = new FileInfo(path).Length;
        if (bytes is < MinSize or > MaxSize) throw new InvalidDataException("Размер EXE вне допустимого диапазона (1–600 МиБ).");
        var info=FileVersionInfo.GetVersionInfo(path);
        if (info.FileMajorPart<0 || info.FileMinorPart<0 || info.FileBuildPart<0 ||
            $"{info.FileMajorPart}.{info.FileMinorPart}.{info.FileBuildPart}" != version)
            throw new InvalidDataException($"Версия ресурса EXE не совпадает с {version}. Файл: {info.FileVersion}");
    }
    internal async Task<CandidateInfo> CreateAsync(string exe, string versionInput, BuilderSettings settings,CancellationToken ct)
    {
        var version=VersionValue(versionInput);
        var source=Path.GetFullPath(exe.Trim().Trim('"'));
        CheckExe(source,version);
        var path=Path.Combine(Root(settings),"v"+version);
        if (Directory.Exists(path)) throw new IOException("Кандидат v"+version+" уже существует. Его нельзя перезаписывать.");
        var keys=Keys(settings);
        using var privateKey=ECDsa.Create();
        using var publicKey=ECDsa.Create();
        privateKey.ImportFromPem(await File.ReadAllTextAsync(keys.Private,ct));
        publicKey.ImportFromPem(await File.ReadAllTextAsync(keys.Public,ct));
        if (!privateKey.ExportSubjectPublicKeyInfo().AsSpan().SequenceEqual(publicKey.ExportSubjectPublicKeyInfo()))
            throw new CryptographicException("Приватный ключ и публичный ключ не соответствуют друг другу.");
        Directory.CreateDirectory(Root(settings));
        Directory.CreateDirectory(path);
        try
        {
            var dst=Path.Combine(path,Asset);
            File.Copy(source,dst,false);
            CheckExe(dst,version);
            await using var input=File.OpenRead(dst);
            var hash=Convert.ToHexString(await SHA256.HashDataAsync(input,ct)).ToLowerInvariant();
            var meta=new LauncherManifest(1,"PROJECT_ECHO_LAUNCHER","production",version,
                "echo-launcher-v"+version,Asset,new FileInfo(dst).Length,hash,DateTimeOffset.UtcNow.ToString("O"));
            var json=JsonSerializer.SerializeToUtf8Bytes(meta,new JsonSerializerOptions{WriteIndented=true});
            var sig=privateKey.SignData(json,HashAlgorithmName.SHA256,DSASignatureFormat.Rfc3279DerSequence);
            if (!publicKey.VerifyData(json,sig,HashAlgorithmName.SHA256,DSASignatureFormat.Rfc3279DerSequence))
                throw new CryptographicException("Подпись EXE-манифеста не прошла самопроверку.");
            await File.WriteAllBytesAsync(Path.Combine(path,"launcher.json"),json,ct);
            await File.WriteAllBytesAsync(Path.Combine(path,"launcher.sig"),sig,ct);
            await File.WriteAllTextAsync(Path.Combine(path,"SHA256SUMS.txt"),hash+"  "+Asset+"\n",ct);
            return await VerifyAsync(path,settings,ct);
        }
        catch {try{Directory.Delete(path,true);}catch{} throw;}
    }
    internal async Task<CandidateInfo> VerifyAsync(string candidatePath,BuilderSettings settings,CancellationToken ct)
    {
        var path=Path.GetFullPath(candidatePath.Trim().Trim('"'));
        var root=Path.GetFullPath(Root(settings)).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar;
        if (!path.StartsWith(root,StringComparison.OrdinalIgnoreCase) || !Directory.Exists(path) ||
            (File.GetAttributes(path)&FileAttributes.ReparsePoint)!=0)
            throw new InvalidDataException("Кандидат должен быть в отдельной папке launcher-production-candidates.");
        var jsonFile=Path.Combine(path,"launcher.json");
        var sigFile=Path.Combine(path,"launcher.sig");
        var exe=Path.Combine(path,Asset);
        foreach(var p in new[]{jsonFile,sigFile,exe})
            if(!File.Exists(p)||(File.GetAttributes(p)&FileAttributes.ReparsePoint)!=0) throw new FileNotFoundException("Файл отсутствует или ссылка: "+p);
        if(new FileInfo(jsonFile).Length>4096||new FileInfo(sigFile).Length is <16 or >256)
            throw new InvalidDataException("Неверный размер манифеста или подписи.");
        var json=await File.ReadAllBytesAsync(jsonFile,ct);
        var meta=JsonSerializer.Deserialize<LauncherManifest>(json) ?? throw new InvalidDataException("Пустой JSON.");
        var version=VersionValue(meta.version);
        if(meta.schema!=1||meta.kind!="PROJECT_ECHO_LAUNCHER"||meta.channel!="production"||
            meta.asset!=Asset||meta.tag!="echo-launcher-v"+version||
            meta.size is <MinSize or >MaxSize||!Regex.IsMatch(meta.sha256??"","^[a-f0-9]{64}$")||
            Path.GetFileName(path)!="v"+version)
            throw new InvalidDataException("Некорректный подписанный production-манифест.");
        using var key=ECDsa.Create();
        key.ImportFromPem(await File.ReadAllTextAsync(Keys(settings).Public,ct));
        if(!key.VerifyData(json,await File.ReadAllBytesAsync(sigFile,ct),HashAlgorithmName.SHA256,DSASignatureFormat.Rfc3279DerSequence))
            throw new CryptographicException("ECDSA-подпись НЕ совпадает.");
        CheckExe(exe,version);
        if(new FileInfo(exe).Length!=meta.size)throw new CryptographicException("Размер EXE изменился.");
        await using var input=File.OpenRead(exe);
        var hash=Convert.ToHexString(await SHA256.HashDataAsync(input,ct)).ToLowerInvariant();
        if(hash!=meta.sha256)throw new CryptographicException("SHA-256 EXE изменился.");
        return new CandidateInfo(path,version,meta.tag,meta.size,meta.sha256);
    }
}
