using System.Collections.Generic;
using System.Linq;
using System.Windows;
using ProjectEcho.Builder.Models;

namespace ProjectEcho.Builder;

public partial class RetiredReviewDialog : Window
{
    public RetiredReviewDialog(IEnumerable<FileChange> candidates)
    {
        InitializeComponent();
        var names = candidates.Select(x => x.Path).OrderBy(x => x, System.StringComparer.OrdinalIgnoreCase).ToList();
        Heading.Text = $"{names.Count} файлов были в предыдущем манифесте, но отсутствуют в выбранном пакете.";
        CandidateList.ItemsSource = names;
    }

    private void Continue_Click(object sender, RoutedEventArgs e) => DialogResult = true;
    private void Cancel_Click(object sender, RoutedEventArgs e) => DialogResult = false;
}
