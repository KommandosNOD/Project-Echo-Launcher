using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text.Json.Nodes;

namespace ProjectEcho.Builder.Models;

public sealed class NewsRecord : INotifyPropertyChanged
{
    public JsonObject Extra { get; init; } = new();
    private string _category = "ОБНОВЛЕНИЕ", _date = DateTime.Today.ToString("dd.MM.yyyy"),
        _title = "", _text = "", _image = "", _pendingImage = "";

    public string Category { get => _category; set => Set(ref _category, value); }
    public string Date { get => _date; set => Set(ref _date, value); }
    public string Title { get => _title; set => Set(ref _title, value); }
    public string Text { get => _text; set => Set(ref _text, value); }
    public string Image { get => _image; set => Set(ref _image, value); }
    // A newly selected image is copied into site/assets/news only on Save, not on selection.
    public string PendingImage { get => _pendingImage; set => Set(ref _pendingImage, value); }
    public string ListTitle => $"{Date}   {Title}";
    public event PropertyChangedEventHandler? PropertyChanged;

    private void Set(ref string field, string? value, [CallerMemberName] string? property = null)
    {
        value ??= "";
        if (field == value) return;
        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(property));
        if (property is nameof(Title) or nameof(Date))
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(ListTitle)));
    }
}
