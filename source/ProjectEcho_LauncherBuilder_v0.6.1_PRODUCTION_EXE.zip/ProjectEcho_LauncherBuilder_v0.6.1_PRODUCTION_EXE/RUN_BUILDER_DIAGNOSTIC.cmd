@echo off
setlocal
cd /d "%~dp0"
set "EXE=%~dp0dist\ProjectEcho.Builder.exe"
set "LOG=%LOCALAPPDATA%\ProjectEcho\Builder\logs\startup.log"
echo PROJECT ECHO Builder v0.1.3 - Startup Diagnostic
echo.
if not exist "%EXE%" (
 echo [ERROR] EXE not found: "%EXE%"
 echo Run BUILD_BUILDER.cmd first.
 pause
 exit /b 1
)
echo Starting: "%EXE%"
echo Please keep the dist folder intact (EXE and accompanying files).
echo.
start "" /wait "%EXE%"
set "EXITCODE=%errorlevel%"
echo.
echo Application exited. Exit code: %EXITCODE%
if exist "%LOG%" (
 echo.
 echo Startup log: "%LOG%"
 powershell -NoProfile -Command "Get-Content -LiteralPath $env:LOCALAPPDATA\ProjectEcho\Builder\logs\startup.log -Tail 65"
) else (
 echo [WARNING] Startup log not created. The process may be blocked before .NET starts.
 echo Inspect Windows Event Viewer - Windows Logs - Application.
)
echo.
pause
exit /b %EXITCODE%
