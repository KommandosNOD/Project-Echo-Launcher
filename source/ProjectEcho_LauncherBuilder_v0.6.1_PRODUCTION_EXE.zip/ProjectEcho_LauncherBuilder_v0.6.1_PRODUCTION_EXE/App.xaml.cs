using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using ProjectEcho.Builder.Services;

namespace ProjectEcho.Builder;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        // Register diagnostics before loading MainWindow.xaml (XAML can fail in the constructor).
        StartupDiagnostics.Write("START: Builder v0.1.4; framework=" + Environment.Version + "; args=" + string.Join(" ", e.Args));
        DispatcherUnhandledException += OnUiUnhandledException;
        AppDomain.CurrentDomain.UnhandledException += (_, args) =>
            StartupDiagnostics.Write("FATAL AppDomain exception", args.ExceptionObject as Exception);
        TaskScheduler.UnobservedTaskException += (_, args) =>
        {
            StartupDiagnostics.Write("Unobserved task exception", args.Exception);
            args.SetObserved();
        };

        try
        {
            base.OnStartup(e);
            StartupDiagnostics.Write("Creating main window");
            var window = new MainWindow();
            MainWindow = window;
            StartupDiagnostics.Write("Main window initialized");
            window.Show();
            StartupDiagnostics.Write("Main window shown");
        }
        catch (Exception ex)
        {
            StartupDiagnostics.ShowFatal("Failed to start the Builder window", ex);
            Shutdown(1);
        }
    }

    private void OnUiUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        StartupDiagnostics.ShowFatal("Unhandled user interface error", e.Exception);
        e.Handled = true;
        Shutdown(1);
    }

    protected override void OnExit(ExitEventArgs e)
    {
        StartupDiagnostics.Write("EXIT: " + e.ApplicationExitCode);
        base.OnExit(e);
    }
}
