@echo off
setlocal
cd /d "%~dp0"
echo PROJECT ECHO - LAUNCHER BUILDER 0.6.1
echo.
where dotnet >nul 2>nul
if errorlevel 1 (
  echo [ERROR] dotnet not found. Install .NET 10 SDK from https://dotnet.microsoft.com/download/dotnet/10.0
  pause
  exit /b 1
)
rem Full publish folder deliberately used for startup troubleshooting and reliable WPF dependencies.
rem NuGetAudit=false avoids network timeout on NuGet vulnerability metadata.
rem Run regular NuGet audits separately when network is accessible.
dotnet publish "ProjectEcho.Builder.csproj" -c Release -r win-x64 --self-contained true -p:PublishSingleFile=false -p:PublishTrimmed=false -p:NuGetAudit=false -o "dist"
if errorlevel 1 (
  echo [FAILED] See errors above.
  pause
  exit /b 1
)
echo.
echo EXE: %~dp0dist\ProjectEcho.Builder.exe
echo IMPORTANT: Keep all files in dist together.
echo For startup diagnostics run RUN_BUILDER_DIAGNOSTIC.cmd
pause
