using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using Microsoft.Win32;
using ProjectEcho.Builder.Models;
using ProjectEcho.Builder.Services;

namespace ProjectEcho.Builder;

public partial class MainWindow
{
    public ObservableCollection<NewsRecord> NewsItems { get; } = new();
    private NewsSnapshot? _newsSnapshot;
    private string _newsLoadedRoot = "";
    private bool _newsDirty, _newsLoading, _siteDeploying;

    private void Tabs_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (e.Source != Tabs || _newsSnapshot != null) return;
        if (Tabs.SelectedItem is TabItem tab && (string?)tab.Header == "НОВОСТИ И САЙТ")
            NewsLoad_Click(sender, e);
    }

    private string CurrentNewsProjectRoot() => Path.GetFullPath(
        Environment.ExpandEnvironmentVariables(ProjectRootBox.Text.Trim().Trim('"')));

    private bool GuardNewsUnsaved()
    {
        if (!_newsDirty) return true;
        return MessageBox.Show(this, "Есть несохранённые изменения новостей. Отменить их и загрузить исходный файл?",
            "PROJECT ECHO — Новости", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes;
    }

    private void NewsLoad_Click(object sender, RoutedEventArgs e)
    {
        if (!GuardNewsUnsaved()) return;
        try
        {
            var root = CurrentNewsProjectRoot();
            var snapshot = NewsSiteService.Load(root);
            _newsLoading = true;
            try
            {
                NewsItems.Clear();
                foreach (var item in snapshot.Items)
                {
                    item.PropertyChanged += NewsItem_PropertyChanged;
                    NewsItems.Add(item);
                }
                _newsSnapshot = snapshot;
                _newsLoadedRoot = root;
                NewsList.SelectedIndex = NewsItems.Count == 0 ? -1 : 0;
                _newsDirty = false;
                NewsStatusText.Text = $"Загружено новостей: {NewsItems.Count} · site/data/news.json";
                NewsSaveState.Text = "Нет несохранённых изменений";
                NewsSiteRootText.Text = "Проект: " + root;
                Trace("Новости загружены из " + NewsSiteService.GetNewsPath(root));
            }
            finally { _newsLoading = false; }
            UpdateNewsImagePreview();
        }
        catch (Exception ex)
        {
            Trace("Ошибка чтения новостей: " + ex);
            MessageBox.Show(this, ex.Message, "Новости — ошибка чтения", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void NewsItem_PropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (_newsLoading) return;
        NewsMarkDirty();
        if (e.PropertyName is nameof(NewsRecord.Image) or nameof(NewsRecord.PendingImage))
            UpdateNewsImagePreview();
    }

    private void NewsMarkDirty()
    {
        _newsDirty = true;
        NewsSaveState.Text = "Есть несохранённые изменения";
    }

    private void NewsList_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        UpdateNewsImagePreview();
    }

    private NewsRecord? SelectedNews() => NewsList.SelectedItem as NewsRecord;

    private void NewsCreate_Click(object sender, RoutedEventArgs e)
    {
        if (_newsSnapshot == null)
        {
            MessageBox.Show(this, "Сначала нажми «Загрузить новости».");
            return;
        }
        var item = new NewsRecord { Title = "Новая публикация", Text = "Введите текст новости..." };
        item.PropertyChanged += NewsItem_PropertyChanged;
        NewsItems.Insert(0, item);
        NewsList.SelectedItem = item;
        NewsMarkDirty();
    }

    private void NewsDelete_Click(object sender, RoutedEventArgs e)
    {
        var item = SelectedNews();
        if (item == null) return;
        if (MessageBox.Show(this, $"Убрать новость «{item.Title}» из ленты? Изменения вступят в силу только после сохранения.",
                "Удаление новости", MessageBoxButton.YesNo, MessageBoxImage.Warning) != MessageBoxResult.Yes) return;
        var old = NewsList.SelectedIndex;
        item.PropertyChanged -= NewsItem_PropertyChanged;
        NewsItems.Remove(item);
        NewsList.SelectedIndex = NewsItems.Count == 0 ? -1 : Math.Min(old, NewsItems.Count - 1);
        NewsMarkDirty();
    }

    private void NewsMoveUp_Click(object sender, RoutedEventArgs e) => MoveNews(-1);
    private void NewsMoveDown_Click(object sender, RoutedEventArgs e) => MoveNews(+1);

    private void MoveNews(int direction)
    {
        var idx = NewsList.SelectedIndex;
        if (idx < 0 || idx + direction < 0 || idx + direction >= NewsItems.Count) return;
        NewsItems.Move(idx, idx + direction);
        NewsList.SelectedIndex = idx + direction;
        NewsMarkDirty();
    }

    private void NewsPickImage_Click(object sender, RoutedEventArgs e)
    {
        var item = SelectedNews();
        if (item == null) return;
        var dialog = new OpenFileDialog
        {
            Title = "Выбери изображение новости (макс. 2 МиБ)",
            Filter = "Изображения PNG, JPG, WEBP|*.png;*.jpg;*.jpeg;*.webp",
            CheckFileExists = true
        };
        if (dialog.ShowDialog(this) != true) return;
        try
        {
            NewsSiteService.CheckImage(dialog.FileName);
            item.PendingImage = dialog.FileName;
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Изображение", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private void NewsClearImage_Click(object sender, RoutedEventArgs e)
    {
        var item = SelectedNews();
        if (item == null) return;
        item.PendingImage = "";
        item.Image = "";
    }

    private void UpdateNewsImagePreview()
    {
        if (NewsPreviewImage == null || NewsImageHint == null) return;
        NewsPreviewImage.Source = null;
        var item = SelectedNews();
        NewsImageHint.Text = "Изображение не выбрано";
        if (item == null) return;
        var candidate = !string.IsNullOrWhiteSpace(item.PendingImage)
            ? item.PendingImage : NewsSiteService.GetImageAbsolutePath(
                string.IsNullOrEmpty(_newsLoadedRoot) ? CurrentNewsProjectRoot() : _newsLoadedRoot, item.Image);
        if (string.IsNullOrWhiteSpace(candidate)) return;
        try
        {
            if (!File.Exists(candidate)) { NewsImageHint.Text = "Файл изображения отсутствует: " + candidate; return; }
            var bmp = new BitmapImage();
            bmp.BeginInit();
            bmp.CacheOption = BitmapCacheOption.OnLoad;
            bmp.UriSource = new Uri(candidate, UriKind.Absolute);
            bmp.EndInit();
            bmp.Freeze();
            NewsPreviewImage.Source = bmp;
            NewsImageHint.Text = Path.GetFileName(candidate);
        }
        catch (Exception ex) { NewsImageHint.Text = "Не удалось показать изображение: " + ex.Message; }
    }

    private void NewsSave_Click(object sender, RoutedEventArgs e)
    {
        if (_newsSnapshot == null) { MessageBox.Show(this, "Сначала загрузи новости."); return; }
        if (_siteDeploying) return;
        try
        {
            var root = CurrentNewsProjectRoot();
            if (!root.Equals(_newsLoadedRoot, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Путь к проекту изменился. Заново загрузи новости из нового проекта.");
            var result = NewsSiteService.Save(root, _newsSnapshot, NewsItems.ToList());
            // Reload to fix the baseline checksum and resolve newly copied image paths.
            var selectedTitle = SelectedNews()?.Title;
            var snapshot = NewsSiteService.Load(root);
            _newsLoading = true;
            try
            {
                NewsItems.Clear();
                foreach (var item in snapshot.Items) { item.PropertyChanged += NewsItem_PropertyChanged; NewsItems.Add(item); }
                _newsSnapshot = snapshot;
                _newsDirty = false;
                var selected = NewsItems.FirstOrDefault(n => n.Title == selectedTitle);
                NewsList.SelectedItem = selected ?? NewsItems.FirstOrDefault();
                NewsSaveState.Text = "Сохранено локально ✓  ·  сайт ещё не опубликован";
                NewsStatusText.Text = $"Сохранено {result.TotalItems} новостей. Резервная копия: {result.BackupPath}";
            }
            finally { _newsLoading = false; }
            UpdateNewsImagePreview();
            Trace("Локальные новости сохранены. Бэкап: " + result.BackupPath);
            MessageBox.Show(this, "Новости сохранены в site/data/news.json. Сайт и лаунчер получат изменения после публикации Cloudflare.",
                "PROJECT ECHO — сохранено локально", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            Trace("Ошибка записи новостей: " + ex);
            MessageBox.Show(this, ex.Message, "Новости — сохранение не выполнено", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void NewsOpenPublicSite_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            Process.Start(new ProcessStartInfo("https://no-signal-pz.komanndosnod.workers.dev/")
                { UseShellExecute = true });
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Открыть сайт", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private void NewsOpenProject_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            var path = Path.GetDirectoryName(NewsSiteService.GetNewsPath(CurrentNewsProjectRoot()))!;
            if (!Directory.Exists(path)) throw new DirectoryNotFoundException(path);
            Process.Start(new ProcessStartInfo("explorer.exe", path) { UseShellExecute = true });
        }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Открыть папку", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private async void NewsDeploySite_Click(object sender, RoutedEventArgs e)
    {
        if (_siteDeploying) return;
        if (_newsSnapshot == null) { MessageBox.Show(this, "Сначала загрузи новости."); return; }
        if (_newsDirty) { MessageBox.Show(this, "Сначала сохрани новости локально."); return; }
        if (NewsDeployConfirmBox.Text.Trim() != "DEPLOY-SITE")
        {
            MessageBox.Show(this, "Чтобы подтвердить публикацию, введи DEPLOY-SITE.");
            return;
        }
        try
        {
            var root = CurrentNewsProjectRoot();
            if (!root.Equals(_newsLoadedRoot, StringComparison.OrdinalIgnoreCase))
                throw new IOException("Путь к проекту поменялся после загрузки новостей.");
            NewsSiteService.ValidateDeploymentProject(root);
            var now = NewsSiteService.Load(root);
            if (!now.SourceHash.Equals(_newsSnapshot.SourceHash, StringComparison.OrdinalIgnoreCase))
                throw new IOException("news.json изменился после сохранения. Перезагрузи и проверь изменения.");
            var answer = MessageBox.Show(this,
                "Опубликовать сайт через Cloudflare Wrangler?\n\nЭто развёртывание ВСЕГО сайта и Worker из текущей папки pzportal2, " +
                "а не только news.json. Оно может включать другие локальные изменения.\n\n" +
                "Убедись, что в site/, worker/ и wrangler.jsonc нет непроверенных изменений.\n\n" +
                "Рабочий домен будет затронут. Продолжить?",
                "PROJECT ECHO — публикация сайта", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            if (answer != MessageBoxResult.Yes) return;
            _siteDeploying = true;
            NewsDeployButton.IsEnabled = false;
            NewsDeployState.Text = "Cloudflare: публикация выполняется...";
            Trace("Сайт: запуск npx wrangler deploy из " + root);
            var (exit, output) = await Task.Run(() => DeploySite(root));
            Trace("Cloudflare Wrangler:\n" + output);
            NewsDeployState.Text = exit == 0
                ? "Cloudflare: Wrangler сообщил об успешном развёртывании ✓"
                : $"Cloudflare: ошибка {exit}. Открой ЖУРНАЛ.";
            MessageBox.Show(this,
                exit == 0 ? "Wrangler завершил развёртывание без ошибок. Проверь новости в браузере и в лаунчере после обновления страницы."
                          : "Cloudflare Wrangler завершился с ошибкой. Открой вкладку ЖУРНАЛ и пришли текст ошибки.",
                "PROJECT ECHO — Cloudflare", MessageBoxButton.OK,
                exit == 0 ? MessageBoxImage.Information : MessageBoxImage.Error);
        }
        catch (Exception ex)
        {
            Trace("Ошибка публикации сайта: " + ex);
            NewsDeployState.Text = "Cloudflare: публикация не выполнена";
            MessageBox.Show(this, ex.Message, "Cloudflare — ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally { _siteDeploying = false; NewsDeployButton.IsEnabled = true; NewsDeployConfirmBox.Text = ""; }
    }

    private static (int ExitCode, string Output) DeploySite(string root)
    {
        // npx is a .cmd on Windows. Fixed arguments; only WorkingDirectory is configurable.
        var info = new ProcessStartInfo("cmd.exe")
        {
            WorkingDirectory = root,
            UseShellExecute = false,
            CreateNoWindow = true,
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            StandardOutputEncoding = System.Text.Encoding.UTF8,
            StandardErrorEncoding = System.Text.Encoding.UTF8
        };
        info.ArgumentList.Add("/d");
        info.ArgumentList.Add("/c");
        info.ArgumentList.Add("npx --yes wrangler@latest deploy --config wrangler.jsonc");
        using var p = Process.Start(info) ?? throw new IOException("Не удалось запустить cmd.exe");
        var stdout = p.StandardOutput.ReadToEndAsync();
        var stderr = p.StandardError.ReadToEndAsync();
        p.WaitForExit();
        Task.WaitAll(stdout, stderr);
        return (p.ExitCode, stdout.Result + "\n" + stderr.Result);
    }
}
